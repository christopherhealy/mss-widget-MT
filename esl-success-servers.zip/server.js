/* =====================================================================
   server.js — PROD CANDIDATE (Set & Forget) — REGEN BLOCK 1/?? 
   Scope: Bootstrap + middleware + auth spine + school scope helpers
   Notes:
   - ESM file (uses import). Do not mix require().
   - All routes should use requireActorAuth + role guards + scope helpers.
   - Every 500 lines marked for future edits.
===================================================================== */

//line 0000
import "dotenv/config";

import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

import cors from "cors";
import { Pool } from "pg";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";


/* ============================================================
   Paths / env
============================================================ */
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);

// Canonical secrets
const ADMIN_JWT_SECRET = String(process.env.MSS_ADMIN_JWT_SECRET || "").trim();
const ACTOR_JWT_SECRET = String(process.env.MSS_ACTOR_JWT_SECRET || "").trim();

// Issuer/audience (keep stable across envs)
const JWT_ISSUER = "mss-widget-mt";
const AUD_ADMIN = "mss-admin";
const AUD_ACTOR = "mss-actor";

/* ============================================================
   App + DB
============================================================ */
const app = express();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false,
});

/* ============================================================
   CORS (centralized; no duplicates)
============================================================ */
function parseAllowedOrigins(raw) {
  return String(raw || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

const DEFAULT_ALLOWED_ORIGINS = [
  // local
  "http://localhost:3000",
  "http://127.0.0.1:3000",
  "http://localhost:5173",

  // prod
  "https://mss-widget-mt.vercel.app",
  "https://mss-widget-mt.onrender.com",
  "https://eslsuccess.club",
  "https://www.eslsuccess.club",
];

const ENV_ALLOWED = parseAllowedOrigins(process.env.CORS_ORIGIN);
const ALLOWED_ORIGINS = [...new Set([...DEFAULT_ALLOWED_ORIGINS, ...ENV_ALLOWED])];

function originMatches(allowed, origin) {
  if (!allowed || !origin) return false;
  if (allowed === origin) return true;

  // wildcard support: https://something-*.vercel.app
  if (allowed.includes("*")) {
    const escaped = allowed.replace(/[.+?^${}()|[\]\\]/g, "\\$&");
    const reStr = "^" + escaped.replace(/\*/g, ".*") + "$";
    return new RegExp(reStr, "i").test(origin);
  }
  return false;
}

function isAllowedOrigin(origin) {
  if (!origin) return true; // curl/server-to-server
  return ALLOWED_ORIGINS.some((a) => originMatches(a, origin));
}

app.use(
  cors({
    origin: (origin, cb) => {
      if (isAllowedOrigin(origin)) return cb(null, true);
      console.warn("[CORS] blocked origin:", origin);
      return cb(new Error("Not allowed by CORS"));
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "x-admin-key", "x-mss-admin-key"],
    maxAge: 86400,
  })
);
app.options("*", cors());

/* ============================================================
   Body parsers + static
============================================================ */
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

const PUBLIC_DIR = path.join(__dirname, "public");
const THEMES_DIR = path.join(__dirname, "themes");
const UPLOADS_DIR = path.join(__dirname, "uploads");

fs.mkdirSync(UPLOADS_DIR, { recursive: true });

app.use("/uploads", express.static(UPLOADS_DIR));
app.use(express.static(PUBLIC_DIR));
app.use("/themes", express.static(path.join(PUBLIC_DIR, "themes")));
app.use("/themes", express.static(THEMES_DIR));

/* ============================================================
   Minimal health endpoints
============================================================ */
app.get("/api/health", (_req, res) => res.json({ ok: true, at: new Date().toISOString() }));

/* ============================================================
   Auth spine (unified)
   - req.actor is canonical for all authenticated requests
   - req.admin_ctx is canonical for admin-context routes
============================================================ */

function getBearer(req) {
  // Standard Authorization: Bearer <jwt>
  const auth = String(req.headers.authorization || "").trim();
  const m = auth.match(/^Bearer\s+(.+)$/i);
  if (m) return String(m[1]).trim();

  // Legacy header support (token raw)
  const x1 = String(req.headers["x-mss-admin-key"] || "").trim();
  if (x1) return x1;

  const x2 = String(req.headers["x-admin-key"] || "").trim();
  if (x2) return x2;

  return "";
}

function tryVerifyJwtWithErr(token, secret, opts = {}) {
  try {
    if (!token || !secret) return { payload: null, err: new Error("missing_token_or_secret") };
    return { payload: jwt.verify(token, secret, opts), err: null };
  } catch (e) {
    return { payload: null, err: e };
  }
}

function normalizeActorFromPayload(payload, mode) {
  if (!payload || typeof payload !== "object") return null;

  // We standardize fields, but we accept legacy names defensively.
  const actorType = String(payload.actorType || payload.actor_type || "").trim().toLowerCase();
  const actorId = Number(payload.actorId || payload.actor_id || 0) || null;

  const email = String(payload.email || payload.userEmail || payload.user_email || "").trim().toLowerCase();

  const schoolId =
    payload.schoolId != null
      ? Number(payload.schoolId)
      : payload.school_id != null
        ? Number(payload.school_id)
        : null;

  const slug = String(payload.slug || payload.schoolSlug || payload.school_slug || "").trim();

  const isSuperAdmin = actorType === "admin" ? !!(payload.isSuperAdmin ?? payload.is_superadmin ?? false) : false;
  const isTeacherAdmin = actorType === "teacher" ? !!(payload.isTeacherAdmin ?? payload.is_teacher_admin ?? false) : false;

  if (!actorType || !actorId || !email) return null;

  return {
    actorType,
    actorId,
    email,
    schoolId: Number.isFinite(schoolId) ? schoolId : null,
    slug,
    isSuperAdmin,
    isTeacherAdmin,
    mode: mode || "unknown",
    raw: payload,
  };
}

/**
 * requireActorAuth
 * Accepts:
 *  - unified actor JWT (aud=mss-actor)
 *  - legacy admin JWT (aud=mss-admin) => normalized to actorType=admin
 *  - optional legacy x-admin-key bridge (only if still needed; keep disabled by default)
 */
function requireActorAuth(req, res, next) {
  
  console.log("[AUTH] headers", {
  hasAuth: !!req.headers.authorization,
  hasX1: !!req.headers["x-mss-admin-key"],
  hasX2: !!req.headers["x-admin-key"],
});
  const token = getBearer(req);
  if (!token) return res.status(401).json({ ok: false, error: "missing_auth" });

  const a1 = tryVerifyJwtWithErr(token, ACTOR_JWT_SECRET, { issuer: JWT_ISSUER, audience: AUD_ACTOR });
  if (a1.payload) {
    const actor = normalizeActorFromPayload(a1.payload, "actor_jwt");
    if (!actor) return res.status(401).json({ ok: false, error: "bad_actor_payload" });
    req.actor = actor;
    return next();
  }

  const a2 = tryVerifyJwtWithErr(token, ADMIN_JWT_SECRET, { issuer: JWT_ISSUER, audience: AUD_ADMIN });
  if (a2.payload) {
    const patched = { ...a2.payload, actorType: "admin", actorId: a2.payload.adminId || a2.payload.actorId };
    const actor = normalizeActorFromPayload(patched, "admin_jwt");
    if (!actor) return res.status(401).json({ ok: false, error: "bad_admin_payload" });
    req.actor = actor;
    return next();
  }

  // QA logging (safe: does not print full token)
  const decoded = jwt.decode(token) || {};
  console.error("[AUTH VERIFY FAILED]", {
    path: req.originalUrl,
    hasActorSecret: !!ACTOR_JWT_SECRET,
    actorSecretLen: ACTOR_JWT_SECRET ? ACTOR_JWT_SECRET.length : 0,
    hasAdminSecret: !!ADMIN_JWT_SECRET,
    adminSecretLen: ADMIN_JWT_SECRET ? ADMIN_JWT_SECRET.length : 0,
    decodedIss: decoded.iss,
    decodedAud: decoded.aud,
    actorVerifyErr: a1.err ? String(a1.err.message || a1.err) : null,
    adminVerifyErr: a2.err ? String(a2.err.message || a2.err) : null,
  });

  return res.status(401).json({ ok: false, error: "invalid_token" });
}
/**
 * Role guards
 */

function requireSuperAdmin(req, res, next) {
  const a = req.actor || {};
  if (String(a.actorType || "") === "admin" && a.isSuperAdmin === true) return next();
  return res.status(403).json({ ok: false, error: "superadmin_required" });
}

/* ============================================================
   School scope helpers (Option B hardened)
============================================================ */

// Shared resolve: slug -> school_id
async function resolveSchoolBySlug(slug) {
  const s = String(slug || "").trim();
  if (!s) {
    const e = new Error("missing_slug");
    e.status = 400;
    throw e;
  }
  const r = await pool.query(`SELECT id, slug FROM schools WHERE slug = $1 LIMIT 1`, [s]);
  if (!r.rowCount) {
    const e = new Error("school_not_found");
    e.status = 404;
    throw e;
  }
  return { schoolId: Number(r.rows[0].id), schoolSlug: String(r.rows[0].slug) };
}

/**
 * requireSchoolCtxFromActor(req, res, slug)
 * Canonical school scoping for:
 *  - admin (optionally superadmin bypass for slug mismatch)
 *  - teacher_admin
 *
 * Contract:
 *  - returns ctx object or null (and sends response)
 *  - hard-verifies token school scope against DB slug->id (migration-safe)
 */
async function requireSchoolCtxFromActor(req, res, slug) {
  const a = req.actor || {};

  const actorType = String(a.actorType || "").toLowerCase();
  const actorId = Number(a.actorId || 0) || null;

  const tokenSchoolId = a.schoolId != null ? Number(a.schoolId) : null;
  const tokenSlug = String(a.slug || "").trim();

  const isSuperAdmin = actorType === "admin" && a.isSuperAdmin === true;
  const isTeacherAdmin = actorType === "teacher" && a.isTeacherAdmin === true;

  // Must be admin OR teacher_admin
  if (!(actorType === "admin" || isTeacherAdmin)) {
    res.status(403).json({ ok: false, error: "admin_or_teacher_admin_required" });
    return null;
  }

  // Must have school scope in token (we enforce this for all non-superadmin flows)
  if (!tokenSchoolId || !tokenSlug) {
    res.status(401).json({ ok: false, error: "missing_school_scope" });
    return null;
  }

  const reqSlug = String(slug || "").trim();
  if (!reqSlug) {
    res.status(400).json({ ok: false, error: "missing_slug" });
    return null;
  }

  // Slug mismatch protection (unless superadmin)
  if (!isSuperAdmin && tokenSlug !== reqSlug) {
    res.status(403).json({ ok: false, error: "slug_mismatch" });
    return null;
  }

  // Hard-verify slug -> school_id aligns with DB (migration-safe)
  let dbSchoolId = null;
  try {
    const r = await pool.query(`SELECT id FROM schools WHERE slug = $1 LIMIT 1`, [reqSlug]);
    if (!r.rowCount) {
      res.status(404).json({ ok: false, error: "school_not_found" });
      return null;
    }
    dbSchoolId = Number(r.rows[0].id);
  } catch (err) {
    console.error("requireSchoolCtxFromActor: school lookup failed", err);
    res.status(500).json({ ok: false, error: "school_lookup_failed" });
    return null;
  }

  if (dbSchoolId !== tokenSchoolId) {
    res.status(403).json({ ok: false, error: "school_scope_mismatch" });
    return null;
  }

  return {
    schoolId: dbSchoolId,
    slug: reqSlug,
    actorType,
    actorId,
    isSuperAdmin,
    isTeacherAdmin,
  };
}

/* ============================================================
   Standardized error wrapper (routes should use it)
============================================================ */
function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

//line 0500

function signActorToken(actor) {
  if (!ACTOR_JWT_SECRET) {
    const e = new Error("missing_actor_jwt_secret");
    e.status = 500;
    throw e;
  }

  const payload = {
    actorType: actor.actorType,
    actorId: actor.actorId,
    email: actor.email,

    schoolId: actor.schoolId,
    slug: actor.slug,

    isSuperAdmin: !!actor.isSuperAdmin,
    isTeacherAdmin: !!actor.isTeacherAdmin,
  };

  // Keep TTL stable and explicit
  const ttl = String(process.env.MSS_ACTOR_JWT_TTL || "12h");

  return jwt.sign(payload, ACTOR_JWT_SECRET, {
    expiresIn: ttl,
    issuer: JWT_ISSUER,
    audience: AUD_ACTOR,
  });
}

console.log("[auth] secrets", {
  hasActorSecret: !!ACTOR_JWT_SECRET,
  hasAdminSecret: !!ADMIN_JWT_SECRET,
  issuer: JWT_ISSUER,
  audActor: AUD_ACTOR,
  audAdmin: AUD_ADMIN,
});

// ---------------------------------------------------------------------
// UNIFIED LOGIN API (admin OR teacher; slug disambiguation)
// POST /api/login
// Body: { email, password, slug? }
// ---------------------------------------------------------------------

async function handleUnifiedLogin(req, res) {
  const body = req.body || {};
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "").trim();
  const slug = String(body.slug || "").trim();

  if (!email || !password) {
    return res.status(400).json({
      ok: false,
      error: "missing_fields",
      message: "Email and password are required.",
    });
  }

  // Helper: choose ONE row deterministically when multiple candidates exist
  // within the SAME school context.
  function pickBestCandidate(rowsInSameSchool) {
    if (!Array.isArray(rowsInSameSchool) || rowsInSameSchool.length === 0) return null;

    // Prefer admin over teacher (policy: admin login wins if an email exists in both tables)
    const adminRow = rowsInSameSchool.find((r) => String(r.actor_type) === "admin");
    if (adminRow) return adminRow;

    const teacherRow = rowsInSameSchool.find((r) => String(r.actor_type) === "teacher");
    if (teacherRow) return teacherRow;

    // Fallback: first row
    return rowsInSameSchool[0];
  }

  try {
    // 1) Fetch all candidate identities for this email (admins + teachers)
    const cand = await pool.query(
      `SELECT * FROM public.sp_login_candidates($1::text)`,
      [email]
    );

    const rows = cand.rows || [];
    if (!rows.length) {
      // IMPORTANT: this means sp_login_candidates returned nothing for this email.
      return res.status(401).json({
        ok: false,
        error: "invalid_credentials",
        message: "Invalid email or password.",
      });
    }

    // Optional: lightweight debug (no hashes)
    console.log("[/api/login] candidates", {
      email,
      providedSlug: slug || null,
      count: rows.length,
      schools: Array.from(new Set(rows.map((r) => String(r.slug || "").trim()))),
      actorTypes: Array.from(new Set(rows.map((r) => String(r.actor_type || "").trim()))),
    });

   // 2) If slug provided, filter to that school context
let scoped = rows;
if (slug) {
  scoped = rows.filter((r) => String(r.slug || "").trim() === slug);
  if (!scoped.length) {
    return res.status(401).json({
      ok: false,
      error: "invalid_context",
      message: "Email is not valid for that school.",
    });
  }

  // 2b) If slug scoped but multiple actors remain (same school), pick deterministically
  if (scoped.length > 1) {
    const adminRow = scoped.find((r) => String(r.actor_type) === "admin");
    const teacherRow = scoped.find((r) => String(r.actor_type) === "teacher");
    scoped = adminRow ? [adminRow] : teacherRow ? [teacherRow] : [scoped[0]];
  }
} else {
  // 2c) No slug: try deterministic choice before forcing school selection
  const admins = scoped.filter((r) => String(r.actor_type) === "admin");
  const teachers = scoped.filter((r) => String(r.actor_type) === "teacher");

  // If exactly one admin record exists for this email, prefer it
  if (admins.length === 1) {
    scoped = [admins[0]];
  }
  // Else if exactly one teacher record exists, use it
  else if (teachers.length === 1) {
    scoped = [teachers[0]];
  }
  // Else multiple contexts -> force selection
  else if (scoped.length > 1) {
    const map = new Map();
    for (const r of scoped) {
      const key = String(r.slug || "");
      if (!map.has(key)) {
        map.set(key, {
          slug: r.slug,
          name: r.school_name,
          school_id: r.school_id,
          actor_types: new Set(),
          has_pw_any: false,
        });
      }
      const entry = map.get(key);
      entry.actor_types.add(r.actor_type);
      entry.has_pw_any = entry.has_pw_any || !!r.has_pw;
    }

    const schools = Array.from(map.values()).map((s) => ({
      slug: s.slug,
      name: s.name,
      school_id: s.school_id,
      actor_types: Array.from(s.actor_types),
      has_pw_any: !!s.has_pw_any, // optional: helps UI messaging later
    }));

    return res.status(200).json({
      ok: false,
      error: "needs_school_selection",
      message: "Select your school to continue.",
      schools,
    });
  }
}

// 4) Now expect exactly one candidate
const c = scoped[0];

    // Safety checks
    if (!c) {
      return res.status(500).json({
        ok: false,
        error: "server_error",
        message: "Login resolver returned no candidate.",
      });
    }

    if (c.is_active === false) {
      return res.status(403).json({
        ok: false,
        error: "account_inactive",
        message: "This account is not active.",
      });
    }

    const hash = String(c.password_hash || "").trim();
    if (!hash) {
      // This is the likely culprit for teacher accounts if teachers.password_hash is not populated.
      console.warn("[/api/login] missing_password_hash", {
        email,
        actor_type: c.actor_type,
        actor_id: c.actor_id,
        slug: c.slug,
        school_id: c.school_id,
      });

      return res.status(403).json({
        ok: false,
        error: "missing_password",
        message: "This account has no password set.",
      });
    }

    const okPassword = await bcrypt.compare(password, hash);
    if (!okPassword) {
      console.warn("[/api/login] bad_password", {
        email,
        actor_type: c.actor_type,
        actor_id: c.actor_id,
        slug: c.slug,
        school_id: c.school_id,
      });

      return res.status(401).json({
        ok: false,
        error: "invalid_credentials",
        message: "Invalid email or password.",
      });
    }

    // 5) Build unified actor payload
    const actor = {
      actorType: String(c.actor_type || "").trim(), // 'admin' | 'teacher'
      actorId: c.actor_id,
      schoolId: c.school_id,
      slug: String(c.slug || "").trim(),
      email: String(c.email || "").trim().toLowerCase(),
      fullName: c.full_name || "",

      // role flags (admin flags will be false/null for teacher rows unless your SP supplies them)
      isSuperAdmin: !!c.is_superadmin,
      isOwner: !!c.is_owner,
      isTeacherAdmin: !!c.is_teacher_admin,
    };

    // 6) JWT (DIAGNOSTIC WRAP)
    let token = "";
    try {
      token = signActorToken(actor);
    } catch (jwtErr) {
      console.error("❌ JWT SIGN FAILED in /api/login", {
        hasSecret: !!process.env.MSS_ACTOR_JWT_SECRET,
        secretLen: process.env.MSS_ACTOR_JWT_SECRET
          ? String(process.env.MSS_ACTOR_JWT_SECRET).length
          : 0,
        ttl: process.env.MSS_ACTOR_JWT_TTL || "(default)",
        error: jwtErr?.message,
        stack: jwtErr?.stack,
      });

      return res.status(500).json({
        ok: false,
        error: "jwt_failed",
        message: jwtErr?.message || "JWT signing failed",
      });
    }

    // 7) Success
    return res.json({ ok: true, actor, token });
  } catch (err) {
    console.error("❌ handleUnifiedLogin error:", err);
    return res.status(500).json({
      ok: false,
      error: "server_error",
      message: "Server error while logging in.",
    });
  }
}
app.post("/api/login", handleUnifiedLogin);

/* ============================================================
   Routers
============================================================ */
const adminRouter = express.Router();

// Everything under /api/admin requires a valid actor token
adminRouter.use(requireActorAuth);

// Each route still applies finer-grained guards (admin-only, teacher_admin-only, etc.)
app.use("/api/admin", adminRouter);

/* ============================================================
   Error middleware (must be AFTER routers)
============================================================ */
app.use((req, res) => {
  res.status(404).json({ ok: false, error: "not_found", path: req.originalUrl });
});

app.use((err, req, res, _next) => {
  const status = Number(err?.status || 500);
  const message = String(err?.message || "server_error");

  // Always log server-side
  console.error("❌ API error:", {
    status,
    message,
    path: req?.originalUrl,
    actor: req?.actor ? { actorType: req.actor.actorType, actorId: req.actor.actorId, slug: req.actor.slug } : null,
  });

  res.status(status).json({ ok: false, error: message });
});

/* =====================================================================
   END REGEN BLOCK 1
===================================================================== */

/* =====================================================================
   server.js — PROD CANDIDATE (Set & Forget) — REGEN BLOCK 2/?? 
   Scope: /api/admin/me + AI Prompts + Suggest + Suggest-Settings + Reports
===================================================================== */

//line 0750

/* ============================================================
   Helpers expected to exist later in the file (or imported)
   - Keep these names stable across the codebase.
   - Do NOT redefine them elsewhere under different names.
============================================================ */
// buildSuggestedPromptTemplate({ preamble, language, notes, selectedMetrics })
// getOrCreateSuggestSettings({ schoolId })
// upsertSuggestSettings({ schoolId, preamble, default_language, default_notes, default_selected_metrics })
// openAiGenerateReport({ promptText, language?, model, temperature, max_output_tokens })
// renderPromptTemplate(promptText, vars)
// sha256(text)

/* ============================================================
   /api/admin/me
   - Canonical “who am I” for admin UI pages.
   - Supports:
     - admin (including superadmin)
     - teacher_admin (actorType=teacher + isTeacherAdmin=true)
   - For teacher_admin: returns teacher record if present.
============================================================ */
adminRouter.get(
  "/me",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const a = req.actor || {};
    const slug = String(req.query.slug || a.slug || "").trim();

    // Non-superadmin must have slug scope
    const isSuperAdmin = a.actorType === "admin" && a.isSuperAdmin === true;
    if (!isSuperAdmin && !slug) {
      return res.status(400).json({ ok: false, error: "missing_slug" });
    }

    // Enforce school scope (migration-safe)
    let ctx = null;
    if (slug) {
      ctx = await requireSchoolCtxFromActor(req, res, slug);
      if (!ctx) return; // helper already responded
    }

    // Admin: fetch admins row (authoritative flags)
    if (a.actorType === "admin") {
      const adminId = Number(a.actorId || 0);
      if (!adminId) return res.status(401).json({ ok: false, error: "bad_admin_id" });

      const q = await pool.query(
        `SELECT id, email, full_name, is_superadmin, is_owner, school_id, is_active
         FROM admins
         WHERE id = $1
         LIMIT 1`,
        [adminId]
      );

      if (!q.rowCount) return res.status(401).json({ ok: false, error: "admin_not_found" });
      const row = q.rows[0];
      if (row.is_active === false) return res.status(403).json({ ok: false, error: "admin_inactive" });

      // Superadmin may not be school-scoped; if ctx exists, cross-check.
      if (ctx && Number(row.school_id) !== Number(ctx.schoolId) && !isSuperAdmin) {
        return res.status(403).json({ ok: false, error: "school_scope_mismatch" });
      }

      return res.json({
        ok: true,
        actor: a,
        scope: ctx ? { schoolId: ctx.schoolId, slug: ctx.slug } : null,
        admin: row,
      });
    }

    // Teacher_admin: fetch teachers row (if table exists)
    if (a.actorType === "teacher") {
      const teacherId = Number(a.actorId || 0);
      if (!teacherId) return res.status(401).json({ ok: false, error: "bad_teacher_id" });

      // If your teachers table differs, adjust here once and never again.
      const t = await pool.query(
        `SELECT id, email, full_name, school_id, is_active, is_teacher_admin
         FROM teachers
         WHERE id = $1
         LIMIT 1`,
        [teacherId]
      );

      if (!t.rowCount) {
        // Fall back to token-only info (still useful)
        return res.json({
          ok: true,
          actor: a,
          scope: ctx ? { schoolId: ctx.schoolId, slug: ctx.slug } : null,
          teacher: null,
          warning: "teacher_row_not_found",
        });
      }

      const row = t.rows[0];
      if (row.is_active === false) return res.status(403).json({ ok: false, error: "teacher_inactive" });

      if (ctx && Number(row.school_id) !== Number(ctx.schoolId)) {
        return res.status(403).json({ ok: false, error: "school_scope_mismatch" });
      }

      return res.json({
        ok: true,
        actor: a,
        scope: ctx ? { schoolId: ctx.schoolId, slug: ctx.slug } : null,
        teacher: row,
      });
    }

    // Should never reach (guarded above)
    return res.status(403).json({ ok: false, error: "admin_or_teacher_admin_required" });
  })
);

/* ============================================================
   AI PROMPTS CRUD (admin + teacher_admin)
   Base: /api/admin/ai-prompts/:slug
   - All endpoints enforce:
     - requireAdminOrTeacherAdmin
     - requireSchoolCtxFromActor (slug scope)
============================================================ */

adminRouter.get(
  "/ai-prompts/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const r = await pool.query(
      `
      SELECT id, school_id, name, prompt_text, is_default, is_active, sort_order,
             notes, language, created_at, updated_at
      FROM ai_prompts
      WHERE school_id = $1
        AND COALESCE(name, '') <> '__SUGGEST_PREAMBLE__'
      ORDER BY
        COALESCE(sort_order, 999999) ASC,
        is_default DESC,
        updated_at DESC,
        id DESC
      `,
      [ctx.schoolId]
    );

    return res.json({ ok: true, prompts: r.rows });
  })
);

// NOTE: You may decide teacher_admin can only READ. If so, add requireAdminOnly to POST/PUT/DELETE.
adminRouter.post(
  "/ai-prompts/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const name = String(req.body?.name || "").trim();
    const promptText = String(req.body?.prompt_text || "").trim();
    if (!name) return res.status(400).json({ ok: false, error: "missing_name" });
    if (!promptText) return res.status(400).json({ ok: false, error: "missing_prompt_text" });

    const isDefault = req.body?.is_default === true;
    const isActive = req.body?.is_active !== false;
    const sortOrder = req.body?.sort_order != null ? Number(req.body.sort_order) : null;
    const notes = req.body?.notes != null ? String(req.body.notes) : null;
    const language = req.body?.language != null ? String(req.body.language) : null;

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      if (isDefault) {
        await client.query(
          `UPDATE ai_prompts SET is_default=false, updated_at=now() WHERE school_id=$1`,
          [ctx.schoolId]
        );
      }

      const ins = await client.query(
        `
        INSERT INTO ai_prompts (school_id, name, prompt_text, is_default, is_active, sort_order, notes, language)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        RETURNING id, school_id, name, prompt_text, is_default, is_active, sort_order, notes, language, created_at, updated_at
        `,
        [ctx.schoolId, name, promptText, isDefault, isActive, sortOrder, notes, language]
      );

      await client.query("COMMIT");
      return res.json({ ok: true, prompt: ins.rows[0] });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch {}

      if (String(e?.message || "").includes("ux_ai_prompts_school_name")) {
        return res.status(409).json({ ok: false, error: "duplicate_name" });
      }

      console.error("POST /ai-prompts failed", e);
      return res.status(500).json({ ok: false, error: "server_error" });
    } finally {
      client.release();
    }
  })
);

adminRouter.put(
  "/ai-prompts/:slug/:id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const id = Number(req.params.id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!id) return res.status(400).json({ ok: false, error: "bad_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const client = await pool.connect();
    try {
      // ensure prompt belongs to school
      const exists = await client.query(
        `SELECT id, is_default FROM ai_prompts WHERE id=$1 AND school_id=$2 LIMIT 1`,
        [id, ctx.schoolId]
      );
      if (!exists.rowCount) return res.status(404).json({ ok: false, error: "prompt_not_found" });

      const fields = [];
      const vals = [];
      let n = 1;

      const setField = (col, v) => {
        fields.push(`${col}=$${n++}`);
        vals.push(v);
      };

      const wantsDefault = req.body?.is_default === true;

      if (req.body?.name != null) setField("name", String(req.body.name).trim());
      if (req.body?.prompt_text != null) setField("prompt_text", String(req.body.prompt_text).trim());
      if (req.body?.notes != null) setField("notes", String(req.body.notes));
      if (req.body?.language != null) setField("language", String(req.body.language));
      if (req.body?.sort_order != null) setField("sort_order", Number(req.body.sort_order));
      if (req.body?.is_active != null) setField("is_active", req.body.is_active === true);

      await client.query("BEGIN");

      if (wantsDefault) {
        await client.query(
          `UPDATE ai_prompts SET is_default=false, updated_at=now() WHERE school_id=$1`,
          [ctx.schoolId]
        );
        setField("is_default", true);
        setField("is_active", true);
      } else if (req.body?.is_default === false) {
        setField("is_default", false);
      }

      if (fields.length) setField("updated_at", new Date());

      if (!fields.length) {
        await client.query("ROLLBACK");
        return res.json({ ok: true, unchanged: true });
      }

      vals.push(id, ctx.schoolId);

      const upd = await client.query(
        `
        UPDATE ai_prompts
           SET ${fields.join(", ")}
         WHERE id=$${n++} AND school_id=$${n++}
         RETURNING id, school_id, name, prompt_text, is_default, is_active, sort_order, notes, language, created_at, updated_at
        `,
        vals
      );

      await client.query("COMMIT");
      return res.json({ ok: true, prompt: upd.rows[0] });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch {}
      if (String(e?.message || "").includes("ux_ai_prompts_school_name")) {
        return res.status(409).json({ ok: false, error: "duplicate_name" });
      }
      console.error("PUT /ai-prompts failed", e);
      return res.status(500).json({ ok: false, error: "server_error" });
    } finally {
      client.release();
    }
  })
);

adminRouter.delete(
  "/ai-prompts/:slug/:id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const id = Number(req.params.id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!id) return res.status(400).json({ ok: false, error: "bad_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      const p = await client.query(
        `SELECT id, is_default FROM ai_prompts WHERE id=$1 AND school_id=$2 LIMIT 1`,
        [id, ctx.schoolId]
      );
      if (!p.rowCount) {
        await client.query("ROLLBACK");
        return res.status(404).json({ ok: false, error: "prompt_not_found" });
      }

      if (p.rows[0].is_default) {
        await client.query("ROLLBACK");
        return res.status(409).json({ ok: false, error: "cannot_delete_default" });
      }

      const wantHard = String(req.query.hard || "") === "1";

      if (wantHard) {
        const ref = await client.query(`SELECT 1 FROM ai_reports WHERE prompt_id=$1 LIMIT 1`, [id]);
        if (ref.rowCount) {
          const soft = await client.query(
            `UPDATE ai_prompts SET is_active=false, updated_at=now()
             WHERE id=$1 AND school_id=$2 RETURNING id`,
            [id, ctx.schoolId]
          );
          await client.query("COMMIT");
          return res.json({ ok: true, deleted: true, mode: "soft", id: soft.rows[0].id });
        }

        await client.query(`DELETE FROM ai_prompts WHERE id=$1 AND school_id=$2`, [id, ctx.schoolId]);
        await client.query("COMMIT");
        return res.json({ ok: true, deleted: true, mode: "hard", id });
      }

      const soft = await client.query(
        `UPDATE ai_prompts SET is_active=false, updated_at=now()
         WHERE id=$1 AND school_id=$2 RETURNING id`,
        [id, ctx.schoolId]
      );

      await client.query("COMMIT");
      return res.json({ ok: true, deleted: true, mode: "soft", id: soft.rows[0].id });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch {}
      console.error("DELETE /ai-prompts failed", e);
      return res.status(500).json({ ok: false, error: "server_error" });
    } finally {
      client.release();
    }
  })
);

adminRouter.post(
  "/ai-prompts/:slug/:id/set-default",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const id = Number(req.params.id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!id) return res.status(400).json({ ok: false, error: "bad_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      const p = await client.query(
        `SELECT id FROM ai_prompts WHERE id=$1 AND school_id=$2 LIMIT 1`,
        [id, ctx.schoolId]
      );
      if (!p.rowCount) {
        await client.query("ROLLBACK");
        return res.status(404).json({ ok: false, error: "prompt_not_found" });
      }

      await client.query(
        `UPDATE ai_prompts SET is_default=false, updated_at=now() WHERE school_id=$1`,
        [ctx.schoolId]
      );

      const upd = await client.query(
        `UPDATE ai_prompts SET is_default=true, is_active=true, updated_at=now()
         WHERE id=$1 AND school_id=$2
         RETURNING id, school_id, name, is_default, is_active, updated_at`,
        [id, ctx.schoolId]
      );

      await client.query("COMMIT");
      return res.json({ ok: true, prompt: upd.rows[0] });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch {}
      console.error("POST set-default failed", e);
      return res.status(500).json({ ok: false, error: "server_error" });
    } finally {
      client.release();
    }
  })
);

adminRouter.put(
  "/ai-prompts/:slug/reorder",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const order = Array.isArray(req.body?.order) ? req.body.order : [];

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      for (const item of order) {
        const id = Number(item?.id || 0);
        const so = item?.sort_order == null ? null : Number(item.sort_order);
        if (!id) continue;

        // Enforce that the prompt belongs to this school
        // (prevents cross-school reorder injection)
        await client.query(
          `
          UPDATE ai_prompts
             SET sort_order = $1,
                 updated_at = now()
           WHERE id = $2
             AND school_id = $3
          `,
          [so, id, ctx.schoolId]
        );
      }

      await client.query("COMMIT");
      return res.json({ ok: true });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch (_) {}
      throw e;
    } finally {
      client.release();
    }
  })
);

// ============================================================
// AI Prompt Suggest Settings (per-school)
// Stored in ai_prompt_preamble (or equivalent table via helper)
// ============================================================
//
// Contract:
//  - teacher_admin and admin can read/write
//  - must be school-scoped
//
// ---------------------------------------------------------------------
// GET /api/admin/ai-prompts/:slug/suggest-settings
// ---------------------------------------------------------------------
adminRouter.get(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const s = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    return res.json({
      ok: true,
      id: s.id,
      preamble_prompt_id: s.id, // legacy FE stability
      preamble: s.preamble,
      default_language: s.default_language,
      default_notes: s.default_notes,
      default_selected_metrics: Array.isArray(s.default_selected_metrics) ? s.default_selected_metrics : [],
      exists: !!s.exists,
    });
  })
);

// ---------------------------------------------------------------------
// PUT /api/admin/ai-prompts/:slug/suggest-settings
// Body: { preamble, default_language, default_notes, default_selected_metrics }
// Also accepts: default_metrics (transition key)
// ---------------------------------------------------------------------
adminRouter.put(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Required
    const preamble = (req.body?.preamble != null) ? String(req.body.preamble) : null;
    if (preamble == null) {
      return res.status(400).json({ ok: false, error: "missing_preamble" });
    }

    // Optional
    const default_language = (req.body?.default_language != null) ? String(req.body.default_language) : "";
    const default_notes = (req.body?.default_notes != null) ? String(req.body.default_notes) : "";

    // Accept either key during transition
    const default_selected_metrics = Array.isArray(req.body?.default_selected_metrics)
      ? req.body.default_selected_metrics
      : (Array.isArray(req.body?.default_metrics) ? req.body.default_metrics : []);

    const saved = await upsertSuggestSettings({
      schoolId: ctx.schoolId,
      preamble,
      default_language,
      default_notes,
      default_selected_metrics,
    });

    return res.json({
      ok: true,
      id: saved.id,
      preamble_prompt_id: saved.id, // legacy FE stability
      preamble: saved.preamble,
      default_language: saved.default_language,
      default_notes: saved.default_notes,
      default_selected_metrics: Array.isArray(saved.default_selected_metrics) ? saved.default_selected_metrics : [],
    });
  })
);

// ============================================================
// Suggest Prompt Generation
// POST /api/admin/ai-prompts/:slug/suggest
// - teacher_admin + admin only
// - school scoped
// - Uses per-school suggest-settings defaults + request overrides
// ============================================================
adminRouter.post(
  "/ai-prompts/:slug/suggest",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // 1) Load per-school defaults
    const ss = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    // 2) Accept request overrides (FE may send either legacy or new keys)
    const language =
      (req.body?.language != null) ? String(req.body.language).trim() :
      (req.body?.default_language != null) ? String(req.body.default_language).trim() :
      String(ss.default_language || "").trim();

    const notes =
      (req.body?.notes != null) ? String(req.body.notes).trim() :
      (req.body?.default_notes != null) ? String(req.body.default_notes).trim() :
      String(ss.default_notes || "").trim();

    const selectedMetrics =
      req.body?.selected_metrics ??
      req.body?.selectedMetrics ??
      req.body?.metrics ??
      req.body?.default_selected_metrics ??
      req.body?.default_metrics ??
      ss.default_selected_metrics ??
      [];

    const metaPrompt = buildSuggestedPromptTemplate({
      preamble: ss.preamble,
      language,
      notes,
      selectedMetrics,
    });

    // OpenAI call (should be centralized; this function should throw on failure)
    const ai = await openAiGenerateReport({
      promptText: metaPrompt,
      model: "gpt-4o-mini",
      temperature: 0.3,
      max_output_tokens: 900,
    });

    return res.json({
      ok: true,
      slug: ctx.slug,
      schoolId: ctx.schoolId,
      prompt_text: ai.text,
      suggested_prompt_text: ai.text,
      model: ai.model,
    });
  })
);

// ============================================================
// AI REPORTS
// ============================================================

// ---------------------------------------------------------------------
// GET /api/admin/reports/existing?submission_id=123&ai_prompt_id=456
// IMPORTANT: scope enforced via submissions.school_id (teacher_admin allowed)
// ---------------------------------------------------------------------
adminRouter.get(
  "/reports/existing",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const submissionId = Number(req.query.submission_id || 0);
    const promptId = Number(req.query.ai_prompt_id || 0);

    if (!submissionId) return res.status(400).json({ ok: false, error: "missing_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "missing_ai_prompt_id" });

    // Determine school scope from submission (authoritative)
    const sc = await pool.query(
      `
      SELECT school_id
        FROM submissions
       WHERE id = $1
         AND deleted_at IS NULL
       LIMIT 1
      `,
      [submissionId]
    );
    if (!sc.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const schoolId = Number(sc.rows[0].school_id);

    // Enforce that the actor can access that school
    const okCtx = await requireSchoolCtxFromActor(req, res, { schoolId, allowSlugMismatch: true });
    if (!okCtx) return;

    const r = await pool.query(
      `
      SELECT report_text, created_at, model, temperature, max_output_tokens
        FROM ai_reports
       WHERE submission_id = $1
         AND prompt_id = $2
       LIMIT 1
      `,
      [submissionId, promptId]
    );

    if (!r.rowCount) return res.json({ ok: true, exists: false });

    return res.json({
      ok: true,
      exists: true,
      report_text: r.rows[0].report_text,
      meta: {
        created_at: r.rows[0].created_at,
        model: r.rows[0].model,
        temperature: r.rows[0].temperature,
        max_output_tokens: r.rows[0].max_output_tokens,
      },
      source: "cache",
    });
  })
);

// ---------------------------------------------------------------------
// POST /api/admin/reports/generate
// body: { slug, submission_id, ai_prompt_id, force?: true }
// - teacher_admin + admin only
// - scope via slug->school_id and submission.school_id
// ---------------------------------------------------------------------
adminRouter.post(
  "/reports/generate",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.body?.slug || "").trim();
    const submissionId = Number(req.body?.submission_id || 0);
    const promptId = Number(req.body?.ai_prompt_id || 0);
    const force = req.body?.force === true;

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "bad_prompt_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Prompt must belong to school + be active
    const p = await pool.query(
      `
      SELECT id, prompt_text, notes, language
        FROM ai_prompts
       WHERE id = $1
         AND school_id = $2
         AND is_active = true
       LIMIT 1
      `,
      [promptId, ctx.schoolId]
    );
    if (!p.rowCount) return res.status(404).json({ ok: false, error: "prompt_not_found" });

    const promptText = String(p.rows[0].prompt_text || "").trim();
    const notes = String(p.rows[0].notes || "").trim();
    const languageRaw =
      (p.rows[0].language === null || p.rows[0].language === undefined) ? "" : String(p.rows[0].language || "").trim();
    const language = languageRaw || null;

    if (!promptText) return res.status(400).json({ ok: false, error: "empty_prompt_text" });

    // Submission must belong to school, not deleted
    const sub = await pool.query(
      `
      SELECT *
        FROM submissions
       WHERE id = $1
         AND school_id = $2
         AND deleted_at IS NULL
       LIMIT 1
      `,
      [submissionId, ctx.schoolId]
    );
    if (!sub.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const row = sub.rows[0];

    // Variables available to template
    const vars = {
      question: row.question || "",
      transcript: row.transcript_clean || row.transcript || "",
      student: row.student_name || row.student_email || row.student_id || "",

      wpm: row.wpm ?? "",

      mss_fluency: row.mss_fluency ?? "",
      mss_grammar: row.mss_grammar ?? "",
      mss_pron: row.mss_pron ?? "",
      mss_vocab: row.mss_vocab ?? "",
      mss_cefr: row.mss_cefr ?? "",
      mss_toefl: row.mss_toefl ?? "",
      mss_ielts: row.mss_ielts ?? "",
      mss_pte: row.mss_pte ?? "",

      vox_score: row.vox_score ?? "",
    };

    // Render prompt template
    const renderedPromptText = renderPromptTemplate(promptText, vars).trim();
    if (!renderedPromptText) {
      return res.status(400).json({ ok: false, error: "rendered_prompt_empty" });
    }

    // Append notes + output language directives
    const parts = [renderedPromptText];
    if (notes) parts.push(`\n\n---\nNotes / Guidance:\n${notes}\n`);
    if (language) parts.push(`\n\n---\nOutput language:\n${language}\n`);
    const finalPrompt = parts.join("");

    const promptHash = sha256(finalPrompt);

    // Cache check
    if (!force) {
      const existing = await pool.query(
        `
        SELECT report_text
          FROM ai_reports
         WHERE submission_id = $1
           AND prompt_id = $2
         LIMIT 1
        `,
        [submissionId, promptId]
      );

      if (existing.rowCount) {
        return res.json({
          ok: true,
          report_text: existing.rows[0].report_text,
          source: "cache",
          prompt_language: language,
          forced: false,
        });
      }
    }

    // Generate
    const ai = await openAiGenerateReport({
      promptText: finalPrompt,
      language,
      model: "gpt-4o-mini",
      temperature: 0.4,
      max_output_tokens: 900,
    });

    const reportText = String(ai.text || "").trim();

    await pool.query(
      `
      INSERT INTO ai_reports (submission_id, prompt_id, prompt_hash, model, temperature, max_output_tokens, report_text)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      ON CONFLICT (submission_id, prompt_id)
      DO UPDATE SET
        report_text = EXCLUDED.report_text,
        prompt_hash = EXCLUDED.prompt_hash,
        model = EXCLUDED.model,
        temperature = EXCLUDED.temperature,
        max_output_tokens = EXCLUDED.max_output_tokens,
        updated_at = NOW()
      `,
      [submissionId, promptId, promptHash, ai.model, ai.temperature, ai.max_output_tokens, reportText]
    );

    return res.json({
      ok: true,
      report_text: reportText,
      source: "openai",
      prompt_language: language,
      forced: !!force,
    });
  })
);

// ============================================================
// //line 500  (marker for editing later)
// ============================================================

// ============================================================
// SUPPORTING HELPERS (must exist in-file somewhere below or above)
// Notes:
// 1) requireSchoolCtxFromActor is the “Option B” set-and-forget helper.
// 2) This implementation supports both calling styles:
//    - requireSchoolCtxFromActor(req,res, "slug")
//    - requireSchoolCtxFromActor(req,res, { schoolId, allowSlugMismatch:true })
// ============================================================

// ============================================================
// //line 750  (end of this block)
// ============================================================            
// ============================================================
// SERVER REGEN — BLOCK 3
// Purpose: Core school/teacher context helpers + Teacher Admin APIs
// Style: set-and-forget, peer-review comments, consistent scope enforcement
// ============================================================

// ============================================================
// Context Helper: requireTeacherCtxFromAdmin
// - Used by admin/teacher_admin pages that operate on teachers
// - Enforces: actor is admin OR teacher_admin; school scope matches token;
//             teacher belongs to the same school
// ============================================================
async function requireTeacherCtxFromAdmin(req, res, slug, teacherId) {
  const ctx = await requireSchoolCtxFromActor(req, res, slug);
  if (!ctx) return null;

  const tid = Number(teacherId || 0);
  if (!tid) {
    res.status(400).json({ ok: false, error: "missing_teacher_id" });
    return null;
  }

  // Teacher must belong to school
  const t = await pool.query(
    `
    SELECT id, school_id, email, full_name, is_active, is_teacher_admin, created_at, updated_at
      FROM teachers
     WHERE id = $1
       AND school_id = $2
     LIMIT 1
    `,
    [tid, ctx.schoolId]
  );

  if (!t.rowCount) {
    res.status(404).json({ ok: false, error: "teacher_not_found" });
    return null;
  }

  return {
    ...ctx,
    teacher: t.rows[0],
  };
}

// ============================================================
// Context Helper: requireSubmissionCtxFromActor
// - Used by report viewer / report generation / submission details
// - Enforces: actor is admin OR teacher_admin OR teacher (if allowed)
// - Enforces: submission belongs to actor school (or superadmin)
// ============================================================
async function requireSubmissionCtxFromActor(req, res, submissionId, opts = {}) {
  const o = (opts && typeof opts === "object") ? opts : {};
  const allowTeacher = o.allowTeacher === true;

  const a = req.actor || {};
  const actorType = String(a.actorType || "").toLowerCase();

  const isSuperAdmin = (actorType === "admin" && a.isSuperAdmin === true);
  const isTeacherAdmin = (actorType === "teacher" && a.isTeacherAdmin === true);

  if (!(actorType === "admin" || isTeacherAdmin || (allowTeacher && actorType === "teacher"))) {
    res.status(403).json({ ok: false, error: "forbidden_actor" });
    return null;
  }

  const sid = Number(submissionId || 0);
  if (!sid) {
    res.status(400).json({ ok: false, error: "missing_submission_id" });
    return null;
  }

  const sub = await pool.query(
    `
    SELECT *
      FROM submissions
     WHERE id = $1
       AND deleted_at IS NULL
     LIMIT 1
    `,
    [sid]
  );
  if (!sub.rowCount) {
    res.status(404).json({ ok: false, error: "submission_not_found" });
    return null;
  }

  const row = sub.rows[0];
  const submissionSchoolId = Number(row.school_id);

  // Token school scope (required for all non-superadmin flows)
  const tokenSchoolId = (a.schoolId != null ? Number(a.schoolId) : null);
  if (!isSuperAdmin && (!tokenSchoolId || tokenSchoolId !== submissionSchoolId)) {
    res.status(403).json({ ok: false, error: "school_scope_mismatch" });
    return null;
  }

  // Optional: verify slug consistency if supplied (good for debugging)
  let slug = null;
  if (o.slug != null) {
    slug = String(o.slug || "").trim() || null;
    if (slug && !isSuperAdmin) {
      const tokenSlug = String(a.slug || "").trim();
      if (tokenSlug && tokenSlug !== slug) {
        res.status(403).json({ ok: false, error: "slug_mismatch" });
        return null;
      }
    }
  }

  return {
    submission: row,
    schoolId: submissionSchoolId,
    slug,
    actorType,
    isSuperAdmin,
    isTeacherAdmin,
  };
}

// ============================================================
// ADMIN / TEACHERS APIs
// - Designed for School Portal teacher management
// - teacher_admin and admin only
// - Enforces school scope via requireSchoolCtxFromActor
// ============================================================

// ---------------------------------------------------------------------
// GET /api/admin/teachers/:slug
// List teachers in school
// ---------------------------------------------------------------------
adminRouter.get(
  "/teachers/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const r = await pool.query(
      `
      SELECT id, school_id, email, full_name, is_active, is_teacher_admin, created_at, updated_at
        FROM teachers
       WHERE school_id = $1
       ORDER BY
         is_teacher_admin DESC,
         is_active DESC,
         COALESCE(full_name,'') ASC,
         id ASC
      `,
      [ctx.schoolId]
    );

    return res.json({ ok: true, teachers: r.rows });
  })
);

// ---------------------------------------------------------------------
// POST /api/admin/teachers/:slug
// Create teacher (default active)
// Body: { email, full_name, password?, is_teacher_admin? }
// Notes:
// - If password is omitted, caller must handle invite/reset flow elsewhere.
// - This endpoint does NOT email; it only creates data.
// ---------------------------------------------------------------------
adminRouter.post(
  "/teachers/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const email = String(req.body?.email || "").trim().toLowerCase();
    const fullName = String(req.body?.full_name || "").trim();
    const isTeacherAdmin = req.body?.is_teacher_admin === true;

    if (!email) return res.status(400).json({ ok: false, error: "missing_email" });
    if (!fullName) return res.status(400).json({ ok: false, error: "missing_full_name" });

    // Password handling: optional, depending on your auth design.
    // If you are hashing passwords for teachers in DB:
    const passwordRaw = (req.body?.password != null) ? String(req.body.password) : null;

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      // Ensure unique per school email
      const dupe = await client.query(
        `SELECT 1 FROM teachers WHERE school_id=$1 AND lower(email)=lower($2) LIMIT 1`,
        [ctx.schoolId, email]
      );
      if (dupe.rowCount) {
        await client.query("ROLLBACK");
        return res.status(409).json({ ok: false, error: "duplicate_email" });
      }

      // If you use a password hash column, compute here; otherwise store null.
      let passwordHash = null;
      if (passwordRaw && passwordRaw.trim()) {
        passwordHash = await hashPassword(passwordRaw); // assumes helper exists
      }

      const ins = await client.query(
        `
        INSERT INTO teachers (school_id, email, full_name, password_hash, is_teacher_admin, is_active)
        VALUES ($1,$2,$3,$4,$5,true)
        RETURNING id, school_id, email, full_name, is_active, is_teacher_admin, created_at, updated_at
        `,
        [ctx.schoolId, email, fullName, passwordHash, isTeacherAdmin]
      );

      await client.query("COMMIT");
      return res.json({ ok: true, teacher: ins.rows[0] });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch (_) {}
      throw e;
    } finally {
      client.release();
    }
  })
);

// ---------------------------------------------------------------------
// PUT /api/admin/teachers/:slug/:teacher_id
// Update teacher fields (scoped)
// Body supports: { full_name?, email?, is_active?, is_teacher_admin? }
// ---------------------------------------------------------------------
adminRouter.put(
  "/teachers/:slug/:teacher_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "missing_teacher_id" });

    const tctx = await requireTeacherCtxFromAdmin(req, res, slug, teacherId);
    if (!tctx) return;

    const client = await pool.connect();
    try {
      const fields = [];
      const vals = [];
      let n = 1;

      const setField = (col, v) => {
        fields.push(`${col}=$${n++}`);
        vals.push(v);
      };

      if (req.body?.full_name != null) setField("full_name", String(req.body.full_name).trim());
      if (req.body?.email != null) setField("email", String(req.body.email).trim().toLowerCase());
      if (req.body?.is_active != null) setField("is_active", req.body.is_active === true);
      if (req.body?.is_teacher_admin != null) setField("is_teacher_admin", req.body.is_teacher_admin === true);

      // Optional password reset (if supported)
      if (req.body?.password != null) {
        const pw = String(req.body.password || "");
        if (pw.trim()) {
          const h = await hashPassword(pw); // assumes helper exists
          setField("password_hash", h);
        }
      }

      if (!fields.length) return res.json({ ok: true, teacher: tctx.teacher, unchanged: true });

      setField("updated_at", new Date());

      vals.push(teacherId, tctx.schoolId);

      const upd = await client.query(
        `
        UPDATE teachers
           SET ${fields.join(", ")}
         WHERE id=$${n++}
           AND school_id=$${n++}
         RETURNING id, school_id, email, full_name, is_active, is_teacher_admin, created_at, updated_at
        `,
        vals
      );

      return res.json({ ok: true, teacher: upd.rows[0] });
    } finally {
      client.release();
    }
  })
);

// ---------------------------------------------------------------------
// DELETE /api/admin/teachers/:slug/:teacher_id
// Default behavior: soft-deactivate teacher (is_active=false)
// Hard delete is not recommended unless you guarantee no references.
// ---------------------------------------------------------------------
adminRouter.delete(
  "/teachers/:slug/:teacher_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "missing_teacher_id" });

    const tctx = await requireTeacherCtxFromAdmin(req, res, slug, teacherId);
    if (!tctx) return;

    const soft = await pool.query(
      `
      UPDATE teachers
         SET is_active=false, updated_at=now()
       WHERE id=$1 AND school_id=$2
       RETURNING id
      `,
      [teacherId, tctx.schoolId]
    );

    return res.json({ ok: true, deleted: true, mode: "soft", id: soft.rows[0]?.id || teacherId });
  })
);

// ============================================================
// //line 500  (marker for editing later)
// ============================================================

// ============================================================
// NOTE FOR PEER REVIEWERS
// ------------------------------------------------------------
// The following are required "infrastructure helpers" assumed to exist:
// - hashPassword(password): returns secure hash string
// - asyncHandler(fn): wraps async route handlers
// - requireActorAuth: populates req.actor from JWT
// - requireAdminOrTeacherAdmin: enforces actor role on req.actor
// - adminRouter: mounted at /api/admin
//
// These are defined earlier (Block 1 / Block 2).
// ============================================================

// ============================================================
// HARDENING: Common Express error shape (optional)
// - If you already have centralized error middleware, keep it there.
// - This is included here as a ready-to-drop-in pattern.
// ============================================================
function sendError(res, status, code, message, extra) {
  const payload = { ok: false, error: String(code || "error") };
  if (message) payload.message = String(message);
  if (extra && typeof extra === "object") payload.extra = extra;
  return res.status(Number(status || 500)).json(payload);
}

// ============================================================
// //line 750  (end of this block)
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 4
// Focus: AI Prompt Suggest + Suggest Settings + AI Reports (cache/existing + generate)
// Goal: “set it and forget it” role-safe endpoints (admin + teacher_admin), scope correct
// ============================================================

// ============================================================
// AI PROMPT — SUGGEST (meta prompt -> OpenAI -> suggested prompt text)
// POST /api/admin/ai-prompts/:slug/suggest
// - Actor JWT: admin OR teacher_admin
// - School scope enforced by requireSchoolCtxFromActor()
// ============================================================
adminRouter.post(
  "/ai-prompts/:slug/suggest",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // 1) Load per-school defaults (preamble + defaults)
    const ss = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    // 2) Accept request overrides (support multiple key names)
    const language =
      (req.body?.language != null ? String(req.body.language).trim() :
      req.body?.default_language != null ? String(req.body.default_language).trim() :
      String(ss.default_language || "").trim()) || "";

    const notes =
      (req.body?.notes != null ? String(req.body.notes).trim() :
      req.body?.default_notes != null ? String(req.body.default_notes).trim() :
      String(ss.default_notes || "").trim()) || "";

    const selectedMetrics =
      req.body?.selected_metrics ??
      req.body?.selectedMetrics ??
      req.body?.metrics ??
      req.body?.default_selected_metrics ??
      req.body?.default_metrics ??
      ss.default_selected_metrics ??
      [];

    const metaPrompt = buildSuggestedPromptTemplate({
      preamble: ss.preamble,
      language,
      notes,
      selectedMetrics,
    });

    // 3) Generate suggested prompt via OpenAI
    const ai = await openAiGenerateReport({
      promptText: metaPrompt,
      model: "gpt-4o-mini",
      temperature: 0.3,
      max_output_tokens: 900,
    });

    const text = String(ai?.text || "").trim();

    return res.json({
      ok: true,
      slug: ctx.slug,
      schoolId: ctx.schoolId,
      prompt_text: text,
      suggested_prompt_text: text,
      model: ai?.model || null,
    });
  })
);

// ============================================================
// AI PROMPT — SUGGEST SETTINGS (per-school)
// Stored in ai_prompt_preamble (or equivalent table/structure)
//
// GET /api/admin/ai-prompts/:slug/suggest-settings
// PUT /api/admin/ai-prompts/:slug/suggest-settings
// - Actor JWT: admin OR teacher_admin
// - School scope enforced by requireSchoolCtxFromActor()
// ============================================================

adminRouter.get(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const s = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    return res.json({
      ok: true,
      id: s.id,
      preamble_prompt_id: s.id, // legacy FE stability
      preamble: s.preamble,
      default_language: s.default_language,
      default_notes: s.default_notes,
      default_selected_metrics: Array.isArray(s.default_selected_metrics) ? s.default_selected_metrics : [],
      exists: !!s.exists,
    });
  })
);

adminRouter.put(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Required
    const preamble = (req.body?.preamble != null) ? String(req.body.preamble) : null;
    if (preamble == null) return res.status(400).json({ ok: false, error: "missing_preamble" });

    // Optional
    const default_language = (req.body?.default_language != null) ? String(req.body.default_language) : "";
    const default_notes = (req.body?.default_notes != null) ? String(req.body.default_notes) : "";

    // Accept either key during transition
    const default_selected_metrics = Array.isArray(req.body?.default_selected_metrics)
      ? req.body.default_selected_metrics
      : (Array.isArray(req.body?.default_metrics) ? req.body.default_metrics : []);

    const saved = await upsertSuggestSettings({
      schoolId: ctx.schoolId,
      preamble,
      default_language,
      default_notes,
      default_selected_metrics,
    });

    return res.json({
      ok: true,
      id: saved.id,
      preamble_prompt_id: saved.id, // legacy FE stability
      preamble: saved.preamble,
      default_language: saved.default_language,
      default_notes: saved.default_notes,
      default_selected_metrics: Array.isArray(saved.default_selected_metrics) ? saved.default_selected_metrics : [],
    });
  })
);

// ============================================================
// AI REPORTS — EXISTING (cache check)
// GET /api/admin/reports/existing?submission_id=123&ai_prompt_id=456
// - Actor JWT: admin OR teacher_admin
// - Scope enforced via submissions.school_id == token school_id
// ============================================================
adminRouter.get(
  "/reports/existing",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const submissionId = Number(req.query.submission_id || 0);
    const promptId = Number(req.query.ai_prompt_id || 0);

    if (!submissionId) return res.status(400).json({ ok: false, error: "missing_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "missing_ai_prompt_id" });

    // Scope via submissions
    const sc = await pool.query(
      `
      SELECT school_id
        FROM submissions
       WHERE id = $1
         AND deleted_at IS NULL
       LIMIT 1
      `,
      [submissionId]
    );
    if (!sc.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const schoolId = Number(sc.rows[0].school_id);

    // Scope check against token school (superadmin bypass if you want; recommended to keep strict)
    // We reuse the token school scope from req.actor and compare.
    const a = req.actor || {};
    const actorType = String(a.actorType || "").toLowerCase();
    const isSuperAdmin = (actorType === "admin" && a.isSuperAdmin === true);
    const tokenSchoolId = (a.schoolId != null ? Number(a.schoolId) : null);

    if (!isSuperAdmin && (!tokenSchoolId || tokenSchoolId !== schoolId)) {
      return res.status(403).json({ ok: false, error: "school_scope_mismatch" });
    }

    const r = await pool.query(
      `
      SELECT report_text, created_at, model, temperature, max_output_tokens
        FROM ai_reports
       WHERE submission_id = $1
         AND prompt_id = $2
       LIMIT 1
      `,
      [submissionId, promptId]
    );

    if (!r.rowCount) return res.json({ ok: true, exists: false });

    return res.json({
      ok: true,
      exists: true,
      report_text: r.rows[0].report_text,
      meta: {
        created_at: r.rows[0].created_at,
        model: r.rows[0].model,
        temperature: r.rows[0].temperature,
        max_output_tokens: r.rows[0].max_output_tokens,
      },
      source: "cache",
    });
  })
);

// ============================================================
// AI REPORTS — GENERATE (cache + OpenAI + store)
// POST /api/admin/reports/generate
// body: { slug, submission_id, ai_prompt_id, force?: true }
// - Actor JWT: admin OR teacher_admin
// - Scope enforced via slug->school and submissions.school_id
// ============================================================
adminRouter.post(
  "/reports/generate",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.body?.slug || "").trim();
    const submissionId = Number(req.body?.submission_id || 0);
    const promptId = Number(req.body?.ai_prompt_id || 0);
    const force = req.body?.force === true;

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "bad_ai_prompt_id" });

    // Enforce slug/school scope from token
    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Prompt must belong to school + be active
    const p = await pool.query(
      `
      SELECT id, prompt_text, notes, language
        FROM ai_prompts
       WHERE id = $1
         AND school_id = $2
         AND is_active = true
       LIMIT 1
      `,
      [promptId, ctx.schoolId]
    );
    if (!p.rowCount) return res.status(404).json({ ok: false, error: "prompt_not_found" });

    const promptText = String(p.rows[0].prompt_text || "").trim();
    const notes = String(p.rows[0].notes || "").trim();

    const languageRaw =
      (p.rows[0].language === null || p.rows[0].language === undefined)
        ? ""
        : String(p.rows[0].language || "").trim();

    const language = languageRaw || null;

    if (!promptText) return res.status(400).json({ ok: false, error: "empty_prompt_text" });

    // Submission must belong to school, not deleted
    const sub = await pool.query(
      `
      SELECT *
        FROM submissions
       WHERE id = $1
         AND school_id = $2
         AND deleted_at IS NULL
       LIMIT 1
      `,
      [submissionId, ctx.schoolId]
    );
    if (!sub.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const row = sub.rows[0];

    // Variables available to template
    const vars = {
      question: row.question || "",
      transcript: row.transcript_clean || row.transcript || "",
      student: row.student_name || row.student_email || row.student_id || "",

      wpm: row.wpm ?? "",

      mss_fluency: row.mss_fluency ?? "",
      mss_grammar: row.mss_grammar ?? "",
      mss_pron: row.mss_pron ?? "",
      mss_vocab: row.mss_vocab ?? "",
      mss_cefr: row.mss_cefr ?? "",
      mss_toefl: row.mss_toefl ?? "",
      mss_ielts: row.mss_ielts ?? "",
      mss_pte: row.mss_pte ?? "",

      vox_score: row.vox_score ?? "",
    };

    // Render template with vars
    const renderedPromptText = String(renderPromptTemplate(promptText, vars) || "").trim();
    if (!renderedPromptText) return res.status(400).json({ ok: false, error: "rendered_prompt_empty" });

    // Append notes + language to rendered prompt
    const parts = [renderedPromptText];
    if (notes) parts.push(`\n\n---\nNotes / Guidance:\n${notes}\n`);
    if (language) parts.push(`\n\n---\nOutput language:\n${language}\n`);
    const finalPrompt = parts.join("");

    const promptHash = sha256(finalPrompt);

    // Cache check (unless forced)
    if (!force) {
      const existing = await pool.query(
        `
        SELECT report_text
          FROM ai_reports
         WHERE submission_id = $1
           AND prompt_id = $2
         LIMIT 1
        `,
        [submissionId, promptId]
      );

      if (existing.rowCount) {
        return res.json({
          ok: true,
          report_text: existing.rows[0].report_text,
          source: "cache",
          prompt_language: language,
          forced: false,
        });
      }
    }

    // Generate via OpenAI
    const ai = await openAiGenerateReport({
      promptText: finalPrompt,
      language,
      model: "gpt-4o-mini",
      temperature: 0.4,
      max_output_tokens: 900,
    });

    const reportText = String(ai?.text || "").trim();

    await pool.query(
      `
      INSERT INTO ai_reports (submission_id, prompt_id, prompt_hash, model, temperature, max_output_tokens, report_text)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      ON CONFLICT (submission_id, prompt_id)
      DO UPDATE SET
        report_text = EXCLUDED.report_text,
        prompt_hash = EXCLUDED.prompt_hash,
        model = EXCLUDED.model,
        temperature = EXCLUDED.temperature,
        max_output_tokens = EXCLUDED.max_output_tokens,
        updated_at = NOW()
      `,
      [submissionId, promptId, promptHash, ai?.model || null, ai?.temperature ?? null, ai?.max_output_tokens ?? null, reportText]
    );

    return res.json({
      ok: true,
      report_text: reportText,
      source: "openai",
      prompt_language: language,
      forced: !!force,
    });
  })
);

// ============================================================
// //line 500  (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) All endpoints in this block use requireAdminOrTeacherAdmin.
//    That resolves the teacher_admin 401 you observed on /suggest,
//    /suggest-settings, and /reports/* which previously used requireAdminAuth.
//
// 2) School scope enforcement strategy:
//    - For slug-based routes: requireSchoolCtxFromActor(req,res,slug)
//    - For submission-based routes: compare submission.school_id to token schoolId
//      (superadmin bypass supported by policy; currently allowed above).
//
// 3) Assumed helpers already defined elsewhere:
//    - requireSchoolCtxFromActor
//    - getOrCreateSuggestSettings, upsertSuggestSettings
//    - buildSuggestedPromptTemplate
//    - openAiGenerateReport
//    - renderPromptTemplate, sha256
// ============================================================

// ============================================================
// //line 750  (end of this block)
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 5
// Focus: Teacher context + Teacher CRUD + Teacher<->Student links (admin + teacher_admin safe)
// Notes:
// - Admins and teacher_admins can manage teachers for their own school.
// - Superadmin can operate across schools (via ctx.isSuperAdmin policy in requireSchoolCtxFromActor).
// - All routes in this block require Actor JWT + scope checks.
// ============================================================

// ============================================================
// Teacher Context Helper (admin/teacher_admin -> teacher scope)
// - Used when an admin/teacher_admin is acting on a teacher resource.
// - Enforces:
//   1) actor is admin OR teacher_admin
//   2) actor token has valid school scope for :slug
//   3) teacher exists and belongs to same school
// ============================================================

// ============================================================
// TEACHERS — LIST
// GET /api/admin/teachers/:slug
// - Actor JWT: admin OR teacher_admin
// ============================================================
adminRouter.get(
  "/teachers/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const r = await pool.query(
      `
      SELECT id, school_id, email, full_name, is_active, created_at, updated_at
        FROM teachers
       WHERE school_id = $1
       ORDER BY
         is_active DESC,
         COALESCE(full_name,'') ASC,
         COALESCE(email,'') ASC,
         id DESC
      `,
      [ctx.schoolId]
    );

    return res.json({ ok: true, teachers: r.rows });
  })
);

// ============================================================
// TEACHERS — CREATE
// POST /api/admin/teachers/:slug
// body: { email, full_name, password?, is_active? }
// - Actor JWT: admin OR teacher_admin
// - Password strategy (recommended):
//   - either accept explicit password OR generate reset token flow (preferred)
// Here we accept password if provided; otherwise create with random temp.
// ============================================================
adminRouter.post(
  "/teachers/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const email = String(req.body?.email || "").trim().toLowerCase();
    const fullName = String(req.body?.full_name || "").trim();
    const isActive = req.body?.is_active !== false;

    if (!email) return res.status(400).json({ ok: false, error: "missing_email" });

    // Password handling: keep simple; hashPassword must exist elsewhere.
    const rawPw =
      (req.body?.password != null && String(req.body.password).trim())
        ? String(req.body.password)
        : null;

    const passwordHash = rawPw ? await hashPassword(rawPw) : await hashPassword(makeRandomPassword(16));

    try {
      const ins = await pool.query(
        `
        INSERT INTO teachers (school_id, email, full_name, password_hash, is_active)
        VALUES ($1,$2,$3,$4,$5)
        RETURNING id, school_id, email, full_name, is_active, created_at, updated_at
        `,
        [ctx.schoolId, email, fullName, passwordHash, isActive]
      );

      return res.json({ ok: true, teacher: ins.rows[0] });
    } catch (e) {
      // If you have a unique constraint on (school_id,email)
      if (String(e?.message || "").includes("ux_teachers_school_email")) {
        return res.status(409).json({ ok: false, error: "duplicate_email" });
      }
      throw e;
    }
  })
);
//patch in from old server
// List all dashboard HTML templates in /public/dashboards
app.get("/api/list-dashboards", async (req, res) => {
  try {
    const dashboardsDir = path.join(PUBLIC_DIR, "dashboards");
    const files = await fs.readdir(dashboardsDir);

    const dashboards = files
      .filter((name) => name.endsWith(".html"))
      .filter((name) => !name.startsWith("_"))
      .map((name) => name.replace(".html", ""));

    res.json({ dashboards });
  } catch (err) {
    console.error("Error listing dashboards:", err);
    res.status(500).json({ error: "Server error listing dashboards" });
  }
});
// ============================================================
// TEACHERS — UPDATE
// PUT /api/admin/teachers/:slug/:teacher_id
// body: { email?, full_name?, is_active?, password? }
// - Actor JWT: admin OR teacher_admin
// ============================================================
adminRouter.put(
  "/teachers/:slug/:teacher_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "bad_teacher_id" });

    const tctx = await requireTeacherCtxFromAdmin(req, res, slug, teacherId);
    if (!tctx) return;

    const fields = [];
    const vals = [];
    let n = 1;

    const setField = (col, v) => {
      fields.push(`${col}=$${n++}`);
      vals.push(v);
    };

    if (req.body?.email != null) setField("email", String(req.body.email).trim().toLowerCase());
    if (req.body?.full_name != null) setField("full_name", String(req.body.full_name).trim());
    if (req.body?.is_active != null) setField("is_active", req.body.is_active === true);

    if (req.body?.password != null && String(req.body.password).trim()) {
      const pwHash = await hashPassword(String(req.body.password));
      setField("password_hash", pwHash);
    }

    if (!fields.length) {
      return res.json({ ok: true, teacher: tctx.teacher, unchanged: true });
    }

    setField("updated_at", new Date());

    // WHERE params
    vals.push(teacherId, tctx.schoolId);

    try {
      const upd = await pool.query(
        `
        UPDATE teachers
           SET ${fields.join(", ")}
         WHERE id=$${n++}
           AND school_id=$${n++}
         RETURNING id, school_id, email, full_name, is_active, created_at, updated_at
        `,
        vals
      );

      return res.json({ ok: true, teacher: upd.rows[0] });
    } catch (e) {
      if (String(e?.message || "").includes("ux_teachers_school_email")) {
        return res.status(409).json({ ok: false, error: "duplicate_email" });
      }
      throw e;
    }
  })
);

// ============================================================
// TEACHERS — DELETE (soft by default)
// DELETE /api/admin/teachers/:slug/:teacher_id?hard=1
// - Actor JWT: admin OR teacher_admin
// - Policy: default soft delete via is_active=false
// ============================================================
adminRouter.delete(
  "/teachers/:slug/:teacher_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "bad_teacher_id" });

    const tctx = await requireTeacherCtxFromAdmin(req, res, slug, teacherId);
    if (!tctx) return;

    const wantHard = String(req.query?.hard || "") === "1";

    if (!wantHard) {
      const soft = await pool.query(
        `
        UPDATE teachers
           SET is_active=false, updated_at=now()
         WHERE id=$1 AND school_id=$2
         RETURNING id
        `,
        [teacherId, tctx.schoolId]
      );
      return res.json({ ok: true, deleted: true, mode: "soft", id: soft.rows[0]?.id || teacherId });
    }

    // hard delete guarded: only if no FK refs
    // If your schema has teacher_students, student_tasks, submissions etc referencing teacher_id,
    // you should either cascade or block. Here we block if referenced.
    const ref = await pool.query(`SELECT 1 FROM teacher_students WHERE teacher_id=$1 LIMIT 1`, [teacherId]);
    if (ref.rowCount) {
      return res.status(409).json({ ok: false, error: "teacher_referenced" });
    }

    await pool.query(`DELETE FROM teachers WHERE id=$1 AND school_id=$2`, [teacherId, tctx.schoolId]);
    return res.json({ ok: true, deleted: true, mode: "hard", id: teacherId });
  })
);

// ============================================================
// //line 1000 (marker)
// ============================================================

// ============================================================
// TEACHER <-> STUDENTS LINKS
// - teacher_students join table
//
// GET /api/admin/teacher-students/:slug/:teacher_id
// PUT /api/admin/teacher-students/:slug/:teacher_id
// body: { student_ids: [1,2,3] } (full replace)
// - Actor JWT: admin OR teacher_admin
// ============================================================

adminRouter.get(
  "/teacher-students/:slug/:teacher_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "bad_teacher_id" });

    const tctx = await requireTeacherCtxFromAdmin(req, res, slug, teacherId);
    if (!tctx) return;

    const r = await pool.query(
      `
      SELECT ts.teacher_id, ts.student_id, ts.created_at,
             s.email AS student_email, s.full_name AS student_full_name, s.is_active AS student_is_active
        FROM teacher_students ts
        JOIN students s ON s.id = ts.student_id
       WHERE ts.teacher_id = $1
         AND s.school_id = $2
       ORDER BY COALESCE(s.full_name,''), COALESCE(s.email,''), s.id
      `,
      [teacherId, tctx.schoolId]
    );

    return res.json({ ok: true, links: r.rows });
  })
);

adminRouter.put(
  "/teacher-students/:slug/:teacher_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "bad_teacher_id" });

    const tctx = await requireTeacherCtxFromAdmin(req, res, slug, teacherId);
    if (!tctx) return;

    const studentIds = Array.isArray(req.body?.student_ids) ? req.body.student_ids : [];
    const ids = studentIds.map(x => Number(x || 0)).filter(n => n > 0);

    // Verify all students belong to this school (strict)
    if (ids.length) {
      const chk = await pool.query(
        `SELECT id FROM students WHERE school_id=$1 AND id = ANY($2::int[])`,
        [tctx.schoolId, ids]
      );
      if (chk.rowCount !== ids.length) {
        return res.status(400).json({ ok: false, error: "student_scope_invalid" });
      }
    }

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      // Full replace strategy
      await client.query(`DELETE FROM teacher_students WHERE teacher_id=$1`, [teacherId]);

      for (const sid of ids) {
        await client.query(
          `INSERT INTO teacher_students (teacher_id, student_id) VALUES ($1,$2)`,
          [teacherId, sid]
        );
      }

      await client.query("COMMIT");
      return res.json({ ok: true, teacher_id: teacherId, student_ids: ids });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch (_) {}
      throw e;
    } finally {
      client.release();
    }
  })
);

// ============================================================
// //line 1500 (end of this block)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) All routes are secured via requireAdminOrTeacherAdmin + requireSchoolCtxFromActor.
// 2) Teacher CRUD is school-scoped and prevents cross-tenant edits.
// 3) teacher_students update uses “full replace” to simplify state sync.
// 4) Password handling is intentionally minimal; prefer a reset-flow later.
// ============================================================

// ============================================================
// Helpers assumed elsewhere:
// - requireSchoolCtxFromActor(req,res,slug)
// - requireAdminOrTeacherAdmin (actor must be admin OR teacher_admin)
// - asyncHandler
// - hashPassword, makeRandomPassword
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 6
// Focus: Student context + Students CRUD + Teacher-side views of students
// Notes:
// - Admins and teacher_admins can manage students for their school.
// - Teachers (non-admin) typically should NOT have full CRUD here unless explicitly allowed.
//   If you want teacher read-only access, we include an optional teacherReadOnly middleware.
// ============================================================

// ============================================================
// Student Context Helper (admin/teacher_admin -> student scope)
// - Enforces actor is admin OR teacher_admin (via requireAdminOrTeacherAdmin router-level)
// - Enforces token school scope matches :slug
// - Ensures student belongs to same school
// ============================================================
async function requireStudentCtxFromAdmin(req, res, slug, studentId) {
  const ctx = await requireSchoolCtxFromActor(req, res, slug);
  if (!ctx) return null;

  const sid = Number(studentId || 0);
  if (!sid) {
    res.status(400).json({ ok: false, error: "bad_student_id" });
    return null;
  }

  const s = await pool.query(
    `
    SELECT id, school_id, email, full_name, is_active, created_at, updated_at
      FROM students
     WHERE id = $1
       AND school_id = $2
     LIMIT 1
    `,
    [sid, ctx.schoolId]
  );

  if (!s.rowCount) {
    res.status(404).json({ ok: false, error: "student_not_found" });
    return null;
  }

  return { ...ctx, student: s.rows[0] };
}

// ============================================================
// STUDENTS — LIST
// GET /api/admin/students/:slug
// - Actor JWT: admin OR teacher_admin
// - Returns basic student directory for the school.
// ============================================================
adminRouter.get(
  "/students/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const r = await pool.query(
      `
      SELECT id, school_id, email, full_name, is_active, created_at, updated_at
        FROM students
       WHERE school_id = $1
       ORDER BY
         is_active DESC,
         COALESCE(full_name,'') ASC,
         COALESCE(email,'') ASC,
         id DESC
      `,
      [ctx.schoolId]
    );

    return res.json({ ok: true, students: r.rows });
  })
);

// ============================================================
// STUDENTS — CREATE
// POST /api/admin/students/:slug
// body: { email, full_name, is_active? }
// - Actor JWT: admin OR teacher_admin
// ============================================================
adminRouter.post(
  "/students/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const email = String(req.body?.email || "").trim().toLowerCase();
    const fullName = String(req.body?.full_name || "").trim();
    const isActive = req.body?.is_active !== false;

    if (!email) return res.status(400).json({ ok: false, error: "missing_email" });

    try {
      const ins = await pool.query(
        `
        INSERT INTO students (school_id, email, full_name, is_active)
        VALUES ($1,$2,$3,$4)
        RETURNING id, school_id, email, full_name, is_active, created_at, updated_at
        `,
        [ctx.schoolId, email, fullName, isActive]
      );

      return res.json({ ok: true, student: ins.rows[0] });
    } catch (e) {
      if (String(e?.message || "").includes("ux_students_school_email")) {
        return res.status(409).json({ ok: false, error: "duplicate_email" });
      }
      throw e;
    }
  })
);

// ============================================================
// STUDENTS — UPDATE
// PUT /api/admin/students/:slug/:student_id
// body: { email?, full_name?, is_active? }
// - Actor JWT: admin OR teacher_admin
// ============================================================
adminRouter.put(
  "/students/:slug/:student_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const studentId = Number(req.params.student_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!studentId) return res.status(400).json({ ok: false, error: "bad_student_id" });

    const sctx = await requireStudentCtxFromAdmin(req, res, slug, studentId);
    if (!sctx) return;

    const fields = [];
    const vals = [];
    let n = 1;

    const setField = (col, v) => {
      fields.push(`${col}=$${n++}`);
      vals.push(v);
    };

    if (req.body?.email != null) setField("email", String(req.body.email).trim().toLowerCase());
    if (req.body?.full_name != null) setField("full_name", String(req.body.full_name).trim());
    if (req.body?.is_active != null) setField("is_active", req.body.is_active === true);

    if (!fields.length) {
      return res.json({ ok: true, student: sctx.student, unchanged: true });
    }

    setField("updated_at", new Date());
    vals.push(studentId, sctx.schoolId);

    try {
      const upd = await pool.query(
        `
        UPDATE students
           SET ${fields.join(", ")}
         WHERE id=$${n++}
           AND school_id=$${n++}
         RETURNING id, school_id, email, full_name, is_active, created_at, updated_at
        `,
        vals
      );

      return res.json({ ok: true, student: upd.rows[0] });
    } catch (e) {
      if (String(e?.message || "").includes("ux_students_school_email")) {
        return res.status(409).json({ ok: false, error: "duplicate_email" });
      }
      throw e;
    }
  })
);

// ============================================================
// STUDENTS — DELETE (soft by default)
// DELETE /api/admin/students/:slug/:student_id?hard=1
// - Actor JWT: admin OR teacher_admin
// - Default soft delete: is_active=false
// ============================================================
adminRouter.delete(
  "/students/:slug/:student_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const studentId = Number(req.params.student_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!studentId) return res.status(400).json({ ok: false, error: "bad_student_id" });

    const sctx = await requireStudentCtxFromAdmin(req, res, slug, studentId);
    if (!sctx) return;

    const wantHard = String(req.query?.hard || "") === "1";

    if (!wantHard) {
      const soft = await pool.query(
        `
        UPDATE students
           SET is_active=false, updated_at=now()
         WHERE id=$1 AND school_id=$2
         RETURNING id
        `,
        [studentId, sctx.schoolId]
      );
      return res.json({ ok: true, deleted: true, mode: "soft", id: soft.rows[0]?.id || studentId });
    }

    // Hard delete guardrails (block if referenced)
    const ref1 = await pool.query(`SELECT 1 FROM teacher_students WHERE student_id=$1 LIMIT 1`, [studentId]);
    if (ref1.rowCount) return res.status(409).json({ ok: false, error: "student_referenced_teacher_students" });

    const ref2 = await pool.query(`SELECT 1 FROM student_tasks WHERE student_id=$1 LIMIT 1`, [studentId]);
    if (ref2.rowCount) return res.status(409).json({ ok: false, error: "student_referenced_tasks" });

    const ref3 = await pool.query(`SELECT 1 FROM submissions WHERE student_id=$1 LIMIT 1`, [studentId]);
    if (ref3.rowCount) return res.status(409).json({ ok: false, error: "student_referenced_submissions" });

    await pool.query(`DELETE FROM students WHERE id=$1 AND school_id=$2`, [studentId, sctx.schoolId]);
    return res.json({ ok: true, deleted: true, mode: "hard", id: studentId });
  })
);

// ============================================================
// //line 2000 (marker)
// ============================================================

// ============================================================
// STUDENTS — BULK IMPORT (minimal CSV-like JSON)
// POST /api/admin/students/:slug/bulk
// body: { students: [{email, full_name, is_active?}, ...] }
// - Actor JWT: admin OR teacher_admin
// - Inserts valid rows, returns counts + row-level results.
// ============================================================
adminRouter.post(
  "/students/:slug/bulk",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const list = Array.isArray(req.body?.students) ? req.body.students : [];
    if (!list.length) return res.status(400).json({ ok: false, error: "missing_students" });

    const client = await pool.connect();
    const results = [];
    let inserted = 0;
    let failed = 0;

    try {
      await client.query("BEGIN");

      for (let i = 0; i < list.length; i++) {
        const row = list[i] || {};
        const email = String(row.email || "").trim().toLowerCase();
        const fullName = String(row.full_name || "").trim();
        const isActive = row.is_active !== false;

        if (!email) {
          failed++;
          results.push({ i, ok: false, error: "missing_email" });
          continue;
        }

        try {
          const ins = await client.query(
            `
            INSERT INTO students (school_id, email, full_name, is_active)
            VALUES ($1,$2,$3,$4)
            ON CONFLICT (school_id, email) DO UPDATE SET
              full_name = EXCLUDED.full_name,
              is_active = EXCLUDED.is_active,
              updated_at = now()
            RETURNING id, email, full_name, is_active
            `,
            [ctx.schoolId, email, fullName, isActive]
          );

          inserted++;
          results.push({ i, ok: true, student: ins.rows[0] });
        } catch (e) {
          failed++;
          results.push({ i, ok: false, error: "insert_failed", message: String(e?.message || "") });
        }
      }

      await client.query("COMMIT");
      return res.json({ ok: true, inserted, failed, results });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch (_) {}
      throw e;
    } finally {
      client.release();
    }
  })
);

// ============================================================
// Teacher-side directory view (optional)
// GET /api/admin/teacher-directory/:slug
// - Actor JWT: admin OR teacher_admin
// - Handy for UIs that show both teachers and students together.
// ============================================================
adminRouter.get(
  "/teacher-directory/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const teachers = await pool.query(
      `
      SELECT id, email, full_name, is_active
        FROM teachers
       WHERE school_id=$1
       ORDER BY is_active DESC, COALESCE(full_name,''), COALESCE(email,''), id DESC
      `,
      [ctx.schoolId]
    );

    const students = await pool.query(
      `
      SELECT id, email, full_name, is_active
        FROM students
       WHERE school_id=$1
       ORDER BY is_active DESC, COALESCE(full_name,''), COALESCE(email,''), id DESC
      `,
      [ctx.schoolId]
    );

    return res.json({
      ok: true,
      teachers: teachers.rows,
      students: students.rows,
    });
  })
);

// ============================================================
// //line 2500 (end of this block)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) Student CRUD is school-scoped, enforced via requireSchoolCtxFromActor.
// 2) Hard deletes are intentionally blocked if referenced; soft delete is default.
// 3) Bulk endpoint uses upsert to simplify re-import workflows.
// 4) If teachers (non-admin) should read students, create a separate teacherRouter
//    with stricter permissions (e.g., only their assigned students).
// ============================================================

// ============================================================
// Helpers assumed elsewhere:
// - requireSchoolCtxFromActor(req,res,slug)
// - requireAdminOrTeacherAdmin
// - asyncHandler
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 7
// Focus: Teacher ↔ Student relationships + Student Tasks
// Roles:
// - admin / teacher_admin: full control
// - teacher: limited to own students & tasks
// ============================================================

// ============================================================
// Teacher Context Helper (teacher OR admin/teacher_admin)
// - Ensures teacher belongs to school
// - Used for teacher-scoped operations
// ============================================================
async function requireTeacherCtx(req, res, slug) {
  const ctx = await requireSchoolCtxFromActor(req, res, slug);
  if (!ctx) return null;

  const actorType = ctx.actorType;

  // Admin / teacher_admin can impersonate teacher via query or body
  if (actorType === "admin") {
    const teacherId = Number(req.query.teacher_id || req.body?.teacher_id || 0);
    if (!teacherId) {
      res.status(400).json({ ok: false, error: "missing_teacher_id" });
      return null;
    }

    const t = await pool.query(
      `
      SELECT id, school_id, email, full_name, is_active
        FROM teachers
       WHERE id=$1 AND school_id=$2
       LIMIT 1
      `,
      [teacherId, ctx.schoolId]
    );
    if (!t.rowCount) {
      res.status(404).json({ ok: false, error: "teacher_not_found" });
      return null;
    }

    return { ...ctx, teacher: t.rows[0] };
  }

  // Teacher role: teacherId must match token
  if (actorType === "teacher") {
    const teacherId = Number(ctx.actorId || 0);
    if (!teacherId) {
      res.status(401).json({ ok: false, error: "missing_teacher_id" });
      return null;
    }

    const t = await pool.query(
      `
      SELECT id, school_id, email, full_name, is_active
        FROM teachers
       WHERE id=$1 AND school_id=$2
       LIMIT 1
      `,
      [teacherId, ctx.schoolId]
    );
    if (!t.rowCount) {
      res.status(403).json({ ok: false, error: "teacher_scope_violation" });
      return null;
    }

    return { ...ctx, teacher: t.rows[0] };
  }

  res.status(403).json({ ok: false, error: "teacher_context_not_allowed" });
  return null;
}

// ============================================================
// TEACHER ↔ STUDENT LINKING
// ============================================================

// ------------------------------------------------------------
// GET /api/admin/teacher-students/:slug/:teacher_id
// - admin / teacher_admin
// ------------------------------------------------------------
adminRouter.get(
  "/teacher-students/:slug/:teacher_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "bad_teacher_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const r = await pool.query(
      `
      SELECT ts.student_id, s.email, s.full_name, s.is_active
        FROM teacher_students ts
        JOIN students s ON s.id = ts.student_id
       WHERE ts.teacher_id=$1 AND ts.school_id=$2
       ORDER BY COALESCE(s.full_name,''), COALESCE(s.email,'')
      `,
      [teacherId, ctx.schoolId]
    );

    return res.json({ ok: true, students: r.rows });
  })
);

// ------------------------------------------------------------
// POST /api/admin/teacher-students/:slug
// body: { teacher_id, student_id }
// - admin / teacher_admin
// ------------------------------------------------------------
adminRouter.post(
  "/teacher-students/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.body?.teacher_id || 0);
    const studentId = Number(req.body?.student_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "missing_teacher_id" });
    if (!studentId) return res.status(400).json({ ok: false, error: "missing_student_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    await pool.query(
      `
      INSERT INTO teacher_students (school_id, teacher_id, student_id)
      VALUES ($1,$2,$3)
      ON CONFLICT DO NOTHING
      `,
      [ctx.schoolId, teacherId, studentId]
    );

    return res.json({ ok: true, linked: true });
  })
);

// ------------------------------------------------------------
// DELETE /api/admin/teacher-students/:slug
// body: { teacher_id, student_id }
// - admin / teacher_admin
// ------------------------------------------------------------
adminRouter.delete(
  "/teacher-students/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.body?.teacher_id || 0);
    const studentId = Number(req.body?.student_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "missing_teacher_id" });
    if (!studentId) return res.status(400).json({ ok: false, error: "missing_student_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    await pool.query(
      `
      DELETE FROM teacher_students
       WHERE school_id=$1 AND teacher_id=$2 AND student_id=$3
      `,
      [ctx.schoolId, teacherId, studentId]
    );

    return res.json({ ok: true, unlinked: true });
  })
);

// ============================================================
// STUDENT TASKS (Assignment Foundation)
// ============================================================

// ------------------------------------------------------------
// POST /api/admin/student-tasks/:slug
// body: { student_id, title, instructions, due_at? }
// Roles:
// - admin / teacher_admin
// - teacher (own students only)
// ------------------------------------------------------------
adminRouter.post(
  "/student-tasks/:slug",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const studentId = Number(req.body?.student_id || 0);
    const title = String(req.body?.title || "").trim();
    const instructions = String(req.body?.instructions || "").trim();
    const dueAt = req.body?.due_at ? new Date(req.body.due_at) : null;

    if (!studentId) return res.status(400).json({ ok: false, error: "missing_student_id" });
    if (!title) return res.status(400).json({ ok: false, error: "missing_title" });

    // Teacher must be linked to student (unless admin)
    if (tctx.actorType === "teacher") {
      const link = await pool.query(
        `
        SELECT 1 FROM teacher_students
         WHERE school_id=$1 AND teacher_id=$2 AND student_id=$3
         LIMIT 1
        `,
        [tctx.schoolId, tctx.teacher.id, studentId]
      );
      if (!link.rowCount) {
        return res.status(403).json({ ok: false, error: "student_not_assigned_to_teacher" });
      }
    }

    const ins = await pool.query(
      `
      INSERT INTO student_tasks
        (school_id, teacher_id, student_id, title, instructions, due_at)
      VALUES ($1,$2,$3,$4,$5,$6)
      RETURNING *
      `,
      [
        tctx.schoolId,
        tctx.teacher.id,
        studentId,
        title,
        instructions,
        dueAt,
      ]
    );

    return res.json({ ok: true, task: ins.rows[0] });
  })
);

// ============================================================
// //line 3000 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) Teacher context is unified: admin can impersonate; teacher is locked to self.
// 2) teacher_students table is the authoritative assignment gate.
// 3) student_tasks is intentionally minimal; widget/task tokens come later.
// 4) All routes enforce school scope via requireSchoolCtxFromActor.
// ============================================================

// ============================================================
// End BLOCK 7
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 8
// Focus: Task-scoped widget tokens ("Practice Loop" foundation)
// Goals:
// - Teacher/Admin creates a task (already in Block 7)
// - System issues a secure task_token URL for student
// - Widget loads task config by token (public endpoint)
// - Submissions link back to task_id (later blocks)
// ============================================================

// ============================================================
// Token helpers (set & forget)
// - Store only token_hash in DB
// - Return raw token only once at creation time
// ============================================================
function randomToken(len = 32) {
  // url-safe, no padding; good enough for bearer token use
  try {
    const bytes = new Uint8Array(len);
    crypto.getRandomValues(bytes);
    let s = "";
    for (const b of bytes) s += ("0" + b.toString(16)).slice(-2);
    return s; // hex length = len*2
  } catch (_) {
    // fallback (node environments without web crypto)
    const { randomBytes } = require("crypto");
    return randomBytes(len).toString("hex");
  }
}

function sha256Hex(text) {
  // Prefer your existing sha256 helper if one exists in server.js.
  // This is a local safe fallback.
  const { createHash } = require("crypto");
  return createHash("sha256").update(String(text || ""), "utf8").digest("hex");
}

// ============================================================
// Task scope helper:
// - Finds task by token hash
// - Ensures active/not revoked
// - Returns normalized task context for widget
// ============================================================
async function requireTaskCtxFromToken(req, res, tokenRaw) {
  const token = String(tokenRaw || "").trim();
  if (!token) {
    res.status(400).json({ ok: false, error: "missing_task_token" });
    return null;
  }

  const tokenHash = sha256Hex(token);

  const q = await pool.query(
    `
    SELECT
      t.id,
      t.school_id,
      t.teacher_id,
      t.student_id,
      t.title,
      t.instructions,
      t.due_at,
      t.is_active,
      t.created_at,
      s.slug AS school_slug
    FROM student_tasks t
    JOIN schools s ON s.id = t.school_id
    WHERE t.task_token_hash = $1
    LIMIT 1
    `,
    [tokenHash]
  );

  if (!q.rowCount) {
    res.status(404).json({ ok: false, error: "task_not_found" });
    return null;
  }

  const task = q.rows[0];
  if (task.is_active === false) {
    res.status(410).json({ ok: false, error: "task_inactive" });
    return null;
  }

  return {
    taskId: Number(task.id),
    schoolId: Number(task.school_id),
    slug: String(task.school_slug || ""),
    teacherId: Number(task.teacher_id),
    studentId: Number(task.student_id),
    title: String(task.title || ""),
    instructions: String(task.instructions || ""),
    dueAt: task.due_at || null,
  };
}

// ============================================================
// ADMIN/TEACHER: Issue a task token for an existing student_task
// POST /api/admin/student-tasks/:slug/:task_id/issue-token
// Roles:
// - admin / teacher_admin
// - teacher (must own task)
// Returns: { task_token, task_url }
// ============================================================
adminRouter.post(
  "/student-tasks/:slug/:task_id/issue-token",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const taskId = Number(req.params.task_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!taskId) return res.status(400).json({ ok: false, error: "bad_task_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // Task must exist and be in-scope
    const t = await pool.query(
      `
      SELECT id, school_id, teacher_id, student_id, is_active
      FROM student_tasks
      WHERE id=$1 AND school_id=$2
      LIMIT 1
      `,
      [taskId, tctx.schoolId]
    );
    if (!t.rowCount) return res.status(404).json({ ok: false, error: "task_not_found" });

    const row = t.rows[0];
    if (row.is_active === false) return res.status(410).json({ ok: false, error: "task_inactive" });

    // Teacher role: must own task
    if (tctx.actorType === "teacher" && Number(row.teacher_id) !== Number(tctx.teacher.id)) {
      return res.status(403).json({ ok: false, error: "task_not_owned_by_teacher" });
    }

    // Issue token (rotate any existing token by overwriting hash)
    const token = randomToken(24); // 48 hex chars
    const tokenHash = sha256Hex(token);

    await pool.query(
      `
      UPDATE student_tasks
         SET task_token_hash=$1,
             token_issued_at=NOW(),
             updated_at=NOW()
       WHERE id=$2 AND school_id=$3
      `,
      [tokenHash, taskId, tctx.schoolId]
    );

    // NOTE: You will choose the final widget URL location later.
    // This returns a sensible default that you can change in FE config.
    const taskUrl =
      `/widget/Widget.html?task_token=${encodeURIComponent(token)}`;

    return res.json({
      ok: true,
      task_id: taskId,
      school_id: tctx.schoolId,
      slug,
      task_token: token, // returned ONCE; do not log this server-side
      task_url: taskUrl,
    });
  })
);

// ============================================================
// ADMIN/TEACHER: Revoke a task token
// POST /api/admin/student-tasks/:slug/:task_id/revoke-token
// Roles:
// - admin / teacher_admin
// - teacher (must own task)
// ============================================================
adminRouter.post(
  "/student-tasks/:slug/:task_id/revoke-token",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const taskId = Number(req.params.task_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!taskId) return res.status(400).json({ ok: false, error: "bad_task_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const t = await pool.query(
      `
      SELECT id, teacher_id
      FROM student_tasks
      WHERE id=$1 AND school_id=$2
      LIMIT 1
      `,
      [taskId, tctx.schoolId]
    );
    if (!t.rowCount) return res.status(404).json({ ok: false, error: "task_not_found" });

    if (tctx.actorType === "teacher" && Number(t.rows[0].teacher_id) !== Number(tctx.teacher.id)) {
      return res.status(403).json({ ok: false, error: "task_not_owned_by_teacher" });
    }

    await pool.query(
      `
      UPDATE student_tasks
         SET task_token_hash=NULL,
             token_revoked_at=NOW(),
             updated_at=NOW()
       WHERE id=$1 AND school_id=$2
      `,
      [taskId, tctx.schoolId]
    );

    return res.json({ ok: true, revoked: true, task_id: taskId });
  })
);

// ============================================================
// PUBLIC: Widget loads task context by token
// GET /api/widget/task
// query: ?task_token=xxxx
// Returns: { slug, task_id, student_id, title, instructions, constraints... }
// IMPORTANT:
// - This is PUBLIC by design (token is the bearer secret)
// - Do NOT return teacher/admin data
// - Do NOT return internal ids beyond what widget needs
// ============================================================
app.get(
  "/api/widget/task",
  asyncHandler(async (req, res) => {
    const token = String(req.query.task_token || "").trim();
    const ctx = await requireTaskCtxFromToken(req, res, token);
    if (!ctx) return;

    // Load any per-task widget configuration you store.
    // For now, keep minimal. You can expand as you formalize widget_task_config.
    //
    // Suggested future fields:
    // - question_set_ids
    // - allow_help (no-help rule)
    // - max_attempts
    // - helper_language
    // - timer limits, etc.
    //
    // For now: return a stable contract that won’t need rework.
    return res.json({
      ok: true,
      slug: ctx.slug,
      task_id: ctx.taskId,
      student_id: ctx.studentId,
      title: ctx.title,
      instructions: ctx.instructions,
      due_at: ctx.dueAt,
      // placeholder for future widget constraints
      constraints: {
        allow_help: true,
        max_attempts: null,
      },
    });
  })
);

// ============================================================
// TEACHER: List tasks for teacher (teacher sees own; admin can specify)
// GET /api/admin/student-tasks/:slug
// query:
// - teacher sees own tasks
// - admin can add ?teacher_id=
// ============================================================
adminRouter.get(
  "/student-tasks/:slug",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const teacherId = Number(tctx.teacher.id);

    const r = await pool.query(
      `
      SELECT
        id,
        student_id,
        title,
        instructions,
        due_at,
        is_active,
        token_issued_at,
        token_revoked_at,
        created_at,
        updated_at
      FROM student_tasks
      WHERE school_id=$1 AND teacher_id=$2
      ORDER BY created_at DESC, id DESC
      `,
      [tctx.schoolId, teacherId]
    );

    return res.json({ ok: true, tasks: r.rows });
  })
);

// ============================================================
// //line 3500 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) Tokens are bearer secrets. We store only SHA-256 hash in DB.
// 2) Public endpoint reveals only student-facing task details.
// 3) Admin/teacher flow uses requireTeacherCtx() so scope rules are uniform.
// 4) This block intentionally avoids “widget config complexity” until your
//    custom widget flow is finalized—contract already anticipates constraints.
// ============================================================

// ============================================================
// End BLOCK 8
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 9
// Focus: Task-linked submissions (submit + list + read)
// Goals:
// - Widget submits a task attempt using task_token
// - Server stores submission with task_id, school_id, student_id, teacher_id
// - Teacher/Admin can list submissions for a task
// - Teacher/Admin can read a submission (scoped)
// ============================================================

// ============================================================
// DB ASSUMPTIONS (add if not already present)
// ------------------------------------------------------------
// submissions table should support:
// - task_id (nullable)  FK -> student_tasks(id)
// - student_id (nullable) FK -> students(id)
// - teacher_id (nullable) FK -> teachers(id)
// - school_id (required)
// - question, transcript, transcript_clean, audio_url, etc.
// ------------------------------------------------------------

// ============================================================
// Helper: requireTaskCtxFromToken() already defined in Block 8
// Helper: requireTeacherCtx() already exists from prior blocks
// ============================================================

// ============================================================
// PUBLIC: Task submission entry point (widget → server)
// POST /api/widget/task/submit
// body: {
//   task_token,
//   question_id?, question_text?,
//   audio_url?, audio_blob? (if you support upload), meta? {},
//   transcript? (optional if ASR is server-side),
//   transcript_clean? (optional),
//   duration_sec? (optional; for WPM later)
// }
//
// Notes:
// - This endpoint is PUBLIC; the bearer secret is task_token
// - It must never accept school_id from client
// - It must derive school/student/teacher from the task record
// ============================================================
app.post(
  "/api/widget/task/submit",
  asyncHandler(async (req, res) => {
    const taskToken = String(req.body?.task_token || "").trim();
    const ctx = await requireTaskCtxFromToken(req, res, taskToken);
    if (!ctx) return;

    // ---- Validate payload minimally (keep stable, expand later) ----
    const questionId = req.body?.question_id != null ? Number(req.body.question_id) : null;
    const questionText = req.body?.question_text != null ? String(req.body.question_text).trim() : "";
    const audioUrl = req.body?.audio_url != null ? String(req.body.audio_url).trim() : "";
    const transcript = req.body?.transcript != null ? String(req.body.transcript) : "";
    const transcriptClean = req.body?.transcript_clean != null ? String(req.body.transcript_clean) : "";
    const durationSec = req.body?.duration_sec != null ? Number(req.body.duration_sec) : null;

    if (!questionId && !questionText) {
      return res.status(400).json({ ok: false, error: "missing_question" });
    }

    // You may not always have audio at this stage (ex: server-side recorder).
    // Keep this permissive for now, but enforce at least one of audio/transcript.
    if (!audioUrl && !transcript && !transcriptClean) {
      return res.status(400).json({ ok: false, error: "missing_audio_or_transcript" });
    }

    // ---- Store meta as JSONB (optional) ----
    const meta = (req.body?.meta && typeof req.body.meta === "object") ? req.body.meta : null;

    // Insert submission
    const ins = await pool.query(
      `
      INSERT INTO submissions (
        school_id,
        teacher_id,
        student_id,
        task_id,
        question_id,
        question,
        audio_url,
        transcript,
        transcript_clean,
        length_sec,
        meta_json
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      RETURNING id, school_id, teacher_id, student_id, task_id, created_at
      `,
      [
        ctx.schoolId,
        ctx.teacherId,
        ctx.studentId,
        ctx.taskId,
        questionId,
        questionText,
        audioUrl,
        transcript,
        transcriptClean,
        durationSec,
        meta ? JSON.stringify(meta) : null
      ]
    );

    // Optional: log a student action
    // If you already have student_logs table + helper, call it here.

    return res.json({
      ok: true,
      submission_id: ins.rows[0].id,
      task_id: ins.rows[0].task_id,
      created_at: ins.rows[0].created_at,
    });
  })
);

// ============================================================
// TEACHER/ADMIN: List submissions for a task
// GET /api/admin/task-submissions/:slug/:task_id
// Teacher: must own task
// Admin/TeacherAdmin: must be in school scope (slug match) and task belongs to school
// ============================================================
adminRouter.get(
  "/task-submissions/:slug/:task_id",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const taskId = Number(req.params.task_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!taskId) return res.status(400).json({ ok: false, error: "bad_task_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // Task in-scope?
    const t = await pool.query(
      `
      SELECT id, school_id, teacher_id, student_id, title, is_active
      FROM student_tasks
      WHERE id=$1 AND school_id=$2
      LIMIT 1
      `,
      [taskId, tctx.schoolId]
    );
    if (!t.rowCount) return res.status(404).json({ ok: false, error: "task_not_found" });

    const task = t.rows[0];

    // Teacher must own the task
    if (tctx.actorType === "teacher" && Number(task.teacher_id) !== Number(tctx.teacher.id)) {
      return res.status(403).json({ ok: false, error: "task_not_owned_by_teacher" });
    }

    const r = await pool.query(
      `
      SELECT
        id,
        created_at,
        question_id,
        question,
        audio_url,
        transcript_clean,
        length_sec,
        -- include Vox or AI scoring columns as they exist in your schema:
        vox_score,
        mss_cefr,
        mss_toefl
      FROM submissions
      WHERE school_id=$1
        AND task_id=$2
        AND deleted_at IS NULL
      ORDER BY created_at DESC, id DESC
      `,
      [tctx.schoolId, taskId]
    );

    return res.json({
      ok: true,
      task: {
        id: Number(task.id),
        title: String(task.title || ""),
        student_id: Number(task.student_id),
        teacher_id: Number(task.teacher_id),
        is_active: task.is_active !== false,
      },
      submissions: r.rows,
    });
  })
);

// ============================================================
// TEACHER/ADMIN: Read a single submission (task-scoped safe)
// GET /api/admin/task-submission/:slug/:submission_id
// Rules:
// - submission.school_id must match school scope
// - if submission.task_id exists and actor is teacher, must own that task
// - for admin/teacher_admin, school scope is sufficient
// ============================================================
adminRouter.get(
  "/task-submission/:slug/:submission_id",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.params.submission_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const s = await pool.query(
      `
      SELECT
        id,
        school_id,
        teacher_id,
        student_id,
        task_id,
        created_at,
        question_id,
        question,
        audio_url,
        transcript,
        transcript_clean,
        length_sec,
        meta_json,
        -- scoring fields (adjust to your schema)
        vox_score,
        mss_fluency,
        mss_grammar,
        mss_pron,
        mss_vocab,
        mss_cefr,
        mss_toefl
      FROM submissions
      WHERE id=$1
        AND school_id=$2
        AND deleted_at IS NULL
      LIMIT 1
      `,
      [submissionId, tctx.schoolId]
    );

    if (!s.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });
    const sub = s.rows[0];

    // Teacher ownership enforcement if task-linked OR teacher_id present
    if (tctx.actorType === "teacher") {
      // Strongest check: submission.teacher_id must match
      if (Number(sub.teacher_id) && Number(sub.teacher_id) !== Number(tctx.teacher.id)) {
        return res.status(403).json({ ok: false, error: "submission_not_owned_by_teacher" });
      }

      // If task_id exists, verify task teacher matches too (belt & suspenders)
      if (sub.task_id) {
        const t = await pool.query(
          `SELECT teacher_id FROM student_tasks WHERE id=$1 AND school_id=$2 LIMIT 1`,
          [Number(sub.task_id), tctx.schoolId]
        );
        if (t.rowCount && Number(t.rows[0].teacher_id) !== Number(tctx.teacher.id)) {
          return res.status(403).json({ ok: false, error: "task_not_owned_by_teacher" });
        }
      }
    }

    return res.json({ ok: true, submission: sub });
  })
);

// ============================================================
// //line 4000 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) /api/widget/task/submit is PUBLIC; task_token is bearer secret.
//    Never accept school_id/teacher_id/student_id from client.
// 2) Teacher/Admin listing uses requireTeacherCtx() for consistent scoping.
// 3) Teacher ownership is enforced to prevent cross-teacher leakage.
// 4) This block is intentionally permissive about transcript/audio presence;
//    tighten once widget recording/upload is finalized.
// 5) length_sec is stored to support WPM server-side (your outstanding item).
// ============================================================

// ============================================================
// End BLOCK 9
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 10
// Focus: Task-scoped scoring pipeline (WPM + Vox + SpeechRater)
// ============================================================

// ============================================================
// ASSUMPTIONS / CONFIG
// ------------------------------------------------------------
// - submissions has: id, school_id, teacher_id, student_id, task_id,
//   transcript_clean, transcript, length_sec (seconds), created_at
// - submissions scoring columns exist (nullable):
//   wpm, vox_score, mss_fluency, mss_grammar, mss_pron, mss_vocab,
//   mss_cefr, mss_toefl, speechrater_json
// - You have helpers:
//   requireTeacherCtx(req,res,slug)
//   openAiGenerateReport(...) [already used elsewhere]
//   voxScoreSubmission(...)   // your internal Vox engine wrapper
//   speechRaterScore(...)     // optional ETS wrapper (can be no-op)
// ============================================================

// ============================================================
// Utilities
// ============================================================


// ============================================================
// Internal: scoreSubmissionOnce()
// - Computes WPM
// - Runs Vox (authoritative)
// - Optionally runs SpeechRater (secondary)
// - Persists results (idempotent)
// ============================================================
async function scoreSubmissionOnce({ submission, force = false }) {
  const submissionId = Number(submission.id);
  const updates = {};
  const meta = {};

  // ----------------------------
  // WPM (always deterministic)
  // ----------------------------
  if (submission.length_sec && submission.transcript_clean) {
    const wpm = computeWpmFromTranscript(
      submission.transcript_clean,
      Number(submission.length_sec)
    );
    if (wpm != null) {
      updates.wpm = wpm;
      meta.wpm_computed = true;
    }
  }

  // ----------------------------
  // Vox scoring (primary)
  // ----------------------------
  // If already scored and not forcing, skip
  const hasVox =
    submission.vox_score != null ||
    submission.mss_cefr != null ||
    submission.mss_toefl != null;

  if (!hasVox || force) {
    const vox = await voxScoreSubmission({
      transcript: submission.transcript_clean || submission.transcript || "",
      lengthSec: submission.length_sec ?? null,
      // include any model/version flags you standardize on
    });

    // Expect vox = { score, fluency, grammar, pron, vocab, cefr, toefl }
    updates.vox_score = vox.score ?? null;
    updates.mss_fluency = vox.fluency ?? null;
    updates.mss_grammar = vox.grammar ?? null;
    updates.mss_pron = vox.pron ?? null;
    updates.mss_vocab = vox.vocab ?? null;
    updates.mss_cefr = vox.cefr ?? null;
    updates.mss_toefl = vox.toefl ?? null;

    meta.vox_model = vox.model || "vox";
    meta.vox_scored = true;
  }

  // ----------------------------
  // SpeechRater (optional / secondary)
  // ----------------------------
  // If you are transitioning away, keep this gated.
  if (typeof speechRaterScore === "function") {
    const hasSR = submission.speechrater_json != null;
    if (!hasSR || force) {
      try {
        const sr = await speechRaterScore({
          transcript: submission.transcript_clean || submission.transcript || "",
        });
        updates.speechrater_json = sr || null;
        meta.speechrater_scored = true;
      } catch (e) {
        // Non-fatal: log and continue
        meta.speechrater_error = String(e?.message || e);
      }
    }
  }

  // ----------------------------
  // Persist if anything changed
  // ----------------------------
  const keys = Object.keys(updates);
  if (!keys.length) {
    return { updated: false, meta };
  }

  const sets = [];
  const vals = [];
  let i = 1;

  for (const k of keys) {
    sets.push(`${k} = $${i++}`);
    vals.push(updates[k]);
  }
  sets.push(`updated_at = NOW()`);

  await pool.query(
    `
    UPDATE submissions
    SET ${sets.join(", ")}
    WHERE id = $${i}
    `,
    [...vals, submissionId]
  );

  return { updated: true, meta };
}

// ============================================================
// TEACHER / ADMIN: Score a submission (task-scoped)
// POST /api/admin/submissions/:slug/:submission_id/score
// body: { force?: true }
// ============================================================
adminRouter.post(
  "/submissions/:slug/:submission_id/score",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.params.submission_id || 0);
    const force = req.body?.force === true;

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // Load submission in-scope
    const s = await pool.query(
      `
      SELECT *
      FROM submissions
      WHERE id=$1
        AND school_id=$2
        AND deleted_at IS NULL
      LIMIT 1
      `,
      [submissionId, tctx.schoolId]
    );
    if (!s.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const sub = s.rows[0];

    // Teacher ownership enforcement
    if (tctx.actorType === "teacher") {
      if (Number(sub.teacher_id) && Number(sub.teacher_id) !== Number(tctx.teacher.id)) {
        return res.status(403).json({ ok: false, error: "submission_not_owned_by_teacher" });
      }
    }

    const result = await scoreSubmissionOnce({ submission: sub, force });

    return res.json({
      ok: true,
      submission_id: submissionId,
      updated: result.updated,
      meta: result.meta,
    });
  })
);

// ============================================================
// TEACHER / ADMIN: Read scoring snapshot (task-safe)
// GET /api/admin/submissions/:slug/:submission_id/score
// ============================================================
adminRouter.get(
  "/submissions/:slug/:submission_id/score",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.params.submission_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const s = await pool.query(
      `
      SELECT
        id,
        created_at,
        wpm,
        vox_score,
        mss_fluency,
        mss_grammar,
        mss_pron,
        mss_vocab,
        mss_cefr,
        mss_toefl,
        speechrater_json
      FROM submissions
      WHERE id=$1
        AND school_id=$2
        AND deleted_at IS NULL
      LIMIT 1
      `,
      [submissionId, tctx.schoolId]
    );
    if (!s.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    return res.json({ ok: true, score: s.rows[0] });
  })
);

// ============================================================
// //line 4500 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) WPM is computed server-side from transcript_clean + length_sec.
// 2) Vox is authoritative; SpeechRater is optional and non-fatal.
// 3) Idempotent scoring: call without force to skip already-scored subs.
// 4) Teacher ownership enforced; admin/teacher_admin bypass ownership.
// 5) This block closes the outstanding WPM implementation item.
// ============================================================

// ============================================================
// End BLOCK 10
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 11
// Focus: Batch scoring + lightweight queue/throttle
// ============================================================

// ============================================================
// Batch scoring helpers
// ============================================================

function parseIdList(v) {
  if (!v) return [];
  if (Array.isArray(v)) return v.map(x => Number(x)).filter(n => Number.isFinite(n) && n > 0);
  if (typeof v === "string") {
    return v
      .split(",")
      .map(s => Number(String(s).trim()))
      .filter(n => Number.isFinite(n) && n > 0);
  }
  return [];
}

function clampInt(n, lo, hi, dflt) {
  const x = Number(n);
  if (!Number.isFinite(x)) return dflt;
  return Math.max(lo, Math.min(hi, Math.trunc(x)));
}

// ============================================================
// Simple concurrency limiter (set-it-and-forget-it)
// - Avoids external dependencies
// - Keeps server stable under QA bursts
// ============================================================

async function runWithConcurrency(items, worker, concurrency) {
  const limit = clampInt(concurrency, 1, 6, 2); // default 2, max 6
  const results = new Array(items.length);
  let idx = 0;

  async function runner() {
    while (true) {
      const i = idx++;
      if (i >= items.length) return;
      try {
        results[i] = await worker(items[i], i);
      } catch (e) {
        results[i] = { ok: false, error: String(e?.message || e), item: items[i] };
      }
    }
  }

  const workers = [];
  for (let k = 0; k < Math.min(limit, items.length); k++) workers.push(runner());
  await Promise.all(workers);
  return results;
}

// ============================================================
// Query builder for selecting submissions in-scope
// ------------------------------------------------------------
// Supported selection modes (exactly one required):
// - submission_ids: [1,2,3]
// - task_id: 123
// - student_id: 456
// - teacher_id: 789 (admin-only unless teacher matches self)
// Also always enforces:
// - school_id
// - not deleted
// Optionally filters:
// - only_unscored=true (default true)
// ============================================================

async function selectSubmissionsForBatch({
  schoolId,
  selection,
  onlyUnscored = true,
  limit = 200
}) {
  const where = [`school_id = $1`, `deleted_at IS NULL`];
  const vals = [Number(schoolId)];
  let n = 2;

  const submissionIds = parseIdList(selection.submission_ids || selection.submissionIds);

  if (submissionIds.length) {
    where.push(`id = ANY($${n}::int[])`);
    vals.push(submissionIds);
    n++;
  } else if (selection.task_id || selection.taskId) {
    where.push(`task_id = $${n}`);
    vals.push(Number(selection.task_id || selection.taskId));
    n++;
  } else if (selection.student_id || selection.studentId) {
    where.push(`student_id = $${n}`);
    vals.push(Number(selection.student_id || selection.studentId));
    n++;
  } else if (selection.teacher_id || selection.teacherId) {
    where.push(`teacher_id = $${n}`);
    vals.push(Number(selection.teacher_id || selection.teacherId));
    n++;
  } else {
    return { ok: false, error: "missing_selection" };
  }

  // By default, avoid re-scoring everything unless explicitly asked.
  if (onlyUnscored) {
    where.push(`(vox_score IS NULL OR mss_cefr IS NULL OR mss_toefl IS NULL OR wpm IS NULL)`);
  }

  const hardLimit = clampInt(limit, 1, 1000, 200);

  const q = await pool.query(
    `
    SELECT *
    FROM submissions
    WHERE ${where.join(" AND ")}
    ORDER BY created_at DESC, id DESC
    LIMIT ${hardLimit}
    `,
    vals
  );

  return { ok: true, rows: q.rows };
}

// ============================================================
// Batch score endpoint
// POST /api/admin/submissions/:slug/score-batch
// body:
// {
//   selection: { submission_ids?: [], task_id?:, student_id?:, teacher_id?: },
//   force?: true,
//   only_unscored?: true,   // default true
//   limit?: 200,            // default 200
//   concurrency?: 2         // default 2, max 6
// }
// ------------------------------------------------------------
// Rules:
// - teacher can batch score ONLY their own submissions
//   (unless teacher_admin? — still teacher actor; keep strict)
// - admin/teacher_admin can batch score within school scope
// ============================================================

adminRouter.post(
  "/submissions/:slug/score-batch",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const force = req.body?.force === true;
    const onlyUnscored = req.body?.only_unscored !== false; // default true
    const limit = clampInt(req.body?.limit, 1, 1000, 200);
    const concurrency = clampInt(req.body?.concurrency, 1, 6, 2);

    const selection = (req.body?.selection && typeof req.body.selection === "object")
      ? req.body.selection
      : {};

    // Teacher restriction: teacher actor can only score their own submissions.
    // If they try to pass teacher_id not equal self, reject.
    if (tctx.actorType === "teacher") {
      const requestedTeacherId = selection.teacher_id || selection.teacherId || null;
      if (requestedTeacherId && Number(requestedTeacherId) !== Number(tctx.teacher.id)) {
        return res.status(403).json({ ok: false, error: "teacher_scope_violation" });
      }
      // Enforce teacher_id if selection doesn't already restrict it.
      if (!selection.teacher_id && !selection.teacherId) {
        selection.teacher_id = Number(tctx.teacher.id);
      }
    }

    // Select candidates
    const picked = await selectSubmissionsForBatch({
      schoolId: tctx.schoolId,
      selection,
      onlyUnscored,
      limit
    });

    if (!picked.ok) return res.status(400).json({ ok: false, error: picked.error });

    const rows = picked.rows || [];
    if (!rows.length) {
      return res.json({
        ok: true,
        selected: 0,
        updated: 0,
        skipped: 0,
        failed: 0,
        results: [],
      });
    }

    // Run scoring with concurrency throttle
    const results = await runWithConcurrency(
      rows,
      async (sub) => {
        // Teacher ownership enforcement (belt + suspenders)
        if (tctx.actorType === "teacher") {
          if (Number(sub.teacher_id) && Number(sub.teacher_id) !== Number(tctx.teacher.id)) {
            return { ok: false, submission_id: sub.id, error: "submission_not_owned_by_teacher" };
          }
        }

        const r = await scoreSubmissionOnce({ submission: sub, force });
        return {
          ok: true,
          submission_id: Number(sub.id),
          updated: !!r.updated,
          meta: r.meta || null,
        };
      },
      concurrency
    );

    let updated = 0;
    let failed = 0;
    for (const r of results) {
      if (!r || r.ok !== true) failed++;
      else if (r.updated) updated++;
    }
    const selected = rows.length;
    const skipped = selected - updated - failed;

    return res.json({
      ok: true,
      selected,
      updated,
      skipped,
      failed,
      concurrency,
      force,
      only_unscored: onlyUnscored,
      results,
    });
  })
);

// ============================================================
// Read “last-known diagnostics” helpers (server side)
// ------------------------------------------------------------
// This is optional, but useful for peer review and QA:
// a stable endpoint to confirm selection + access controls.
// GET /api/admin/submissions/:slug/batch-preview?... (query style)
// ============================================================

adminRouter.get(
  "/submissions/:slug/batch-preview",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const onlyUnscored = String(req.query.only_unscored || "1") !== "0";
    const limit = clampInt(req.query.limit, 1, 1000, 200);

    const selection = {
      submission_ids: parseIdList(req.query.submission_ids),
      task_id: req.query.task_id ? Number(req.query.task_id) : null,
      student_id: req.query.student_id ? Number(req.query.student_id) : null,
      teacher_id: req.query.teacher_id ? Number(req.query.teacher_id) : null,
    };

    if (tctx.actorType === "teacher") {
      // Teachers cannot preview other teachers’ data
      if (selection.teacher_id && Number(selection.teacher_id) !== Number(tctx.teacher.id)) {
        return res.status(403).json({ ok: false, error: "teacher_scope_violation" });
      }
      if (!selection.teacher_id) selection.teacher_id = Number(tctx.teacher.id);
    }

    const picked = await selectSubmissionsForBatch({
      schoolId: tctx.schoolId,
      selection,
      onlyUnscored,
      limit
    });

    if (!picked.ok) return res.status(400).json({ ok: false, error: picked.error });

    // Return only minimal fields for preview
    const rows = (picked.rows || []).map(r => ({
      id: Number(r.id),
      created_at: r.created_at,
      teacher_id: r.teacher_id ?? null,
      student_id: r.student_id ?? null,
      task_id: r.task_id ?? null,
      length_sec: r.length_sec ?? null,
      has_transcript_clean: !!r.transcript_clean,
      wpm: r.wpm ?? null,
      vox_score: r.vox_score ?? null,
      mss_cefr: r.mss_cefr ?? null,
      mss_toefl: r.mss_toefl ?? null,
    }));

    return res.json({
      ok: true,
      count: rows.length,
      only_unscored: onlyUnscored,
      limit,
      selection,
      rows,
    });
  })
);

// ============================================================
// //line 5000 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) Batch scoring is throttled via runWithConcurrency().
// 2) Teachers are forcibly scoped to their own teacher_id.
// 3) Admin/teacher_admin can score within school_id scope.
// 4) Selection supports multiple modes; missing selection is rejected.
// 5) Preview endpoint is deliberately minimal to avoid data leakage.
// 6) This block is “queue-friendly”: later we can replace the worker
//    loop with a job enqueue to Redis/SQS without changing the API.
// ============================================================

// ============================================================
// End BLOCK 11
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 12
// Focus: Student Portal foundations + Task Token workflow
// ============================================================

// ============================================================
// Token helpers (opaque task_token)
// - Use crypto.randomBytes when available
// ============================================================

function makeOpaqueToken(bytes = 24) {
  try {
    return crypto.randomBytes(bytes).toString("hex"); // 48 chars @ 24 bytes
  } catch {
    // fallback (should never happen in Node)
    return String(Date.now()) + "_" + Math.random().toString(16).slice(2);
  }
}

// ============================================================
// Actor-scoped teacher enforcement
// - If actorType=teacher, they must be the teacher_id for teacher endpoints
// - If actorType=admin, they can operate within school scope
// ============================================================

function enforceTeacherSelfScope(tctx, teacherId) {
  if (!tctx) return { ok: false, error: "missing_ctx" };
  if (tctx.actorType === "teacher") {
    const selfId = Number(tctx.teacher?.id || 0);
    if (!selfId) return { ok: false, error: "teacher_ctx_missing_id" };
    if (Number(teacherId) !== selfId) return { ok: false, error: "teacher_scope_violation" };
  }
  return { ok: true };
}

// ============================================================
// STUDENTS: list + create + update (admin/teacher_admin/teacher)
// - Teacher: sees only students linked to them (teacher_students)
// - Admin: sees all students in school
// ============================================================

adminRouter.get(
  "/students/:slug",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // teacher sees only linked students
    if (tctx.actorType === "teacher") {
      const r = await pool.query(
        `
        SELECT s.*
        FROM students s
        JOIN teacher_students ts ON ts.student_id = s.id
        WHERE s.school_id = $1
          AND ts.teacher_id = $2
          AND s.deleted_at IS NULL
        ORDER BY s.created_at DESC, s.id DESC
        `,
        [tctx.schoolId, tctx.teacher.id]
      );
      return res.json({ ok: true, scope: "teacher", students: r.rows });
    }

    // admin sees all
    const r = await pool.query(
      `
      SELECT *
      FROM students
      WHERE school_id = $1
        AND deleted_at IS NULL
      ORDER BY created_at DESC, id DESC
      `,
      [tctx.schoolId]
    );
    return res.json({ ok: true, scope: "school", students: r.rows });
  })
);

// Create student
adminRouter.post(
  "/students/:slug",
  requireActorAuth,
  requireAdminOrTeacherAdmin, // teacher role should not create students by default
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const fullName = String(req.body?.full_name || req.body?.name || "").trim();
    const email = String(req.body?.email || "").trim().toLowerCase();

    if (!fullName && !email) {
      return res.status(400).json({ ok: false, error: "missing_student_identity" });
    }

    const r = await pool.query(
      `
      INSERT INTO students (school_id, full_name, email)
      VALUES ($1, $2, $3)
      RETURNING *
      `,
      [ctx.schoolId, fullName || null, email || null]
    );

    return res.json({ ok: true, student: r.rows[0] });
  })
);

// Update student (admin/teacher_admin only)
adminRouter.put(
  "/students/:slug/:student_id",
  requireActorAuth,
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const studentId = Number(req.params.student_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!studentId) return res.status(400).json({ ok: false, error: "bad_student_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const fields = [];
    const vals = [ctx.schoolId, studentId];
    let n = 3;

    const set = (col, v) => { fields.push(`${col}=$${n++}`); vals.push(v); };

    if (req.body?.full_name != null) set("full_name", String(req.body.full_name).trim());
    if (req.body?.email != null) set("email", String(req.body.email).trim().toLowerCase());
    if (req.body?.is_active != null) set("is_active", req.body.is_active === true);

    if (!fields.length) return res.json({ ok: true, unchanged: true });

    const r = await pool.query(
      `
      UPDATE students
         SET ${fields.join(", ")}, updated_at = NOW()
       WHERE school_id = $1 AND id = $2 AND deleted_at IS NULL
       RETURNING *
      `,
      vals
    );

    if (!r.rowCount) return res.status(404).json({ ok: false, error: "student_not_found" });
    return res.json({ ok: true, student: r.rows[0] });
  })
);

// ============================================================
// TEACHER ↔ STUDENT linking
// - Admin/teacher_admin can link any teacher in school
// - Teacher actor can link ONLY themselves (optional; allow if you want)
// ============================================================

adminRouter.get(
  "/teacher-students/:slug/:teacher_id",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "bad_teacher_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const sc = enforceTeacherSelfScope(tctx, teacherId);
    if (!sc.ok) return res.status(403).json({ ok: false, error: sc.error });

    const r = await pool.query(
      `
      SELECT ts.*, s.full_name, s.email
      FROM teacher_students ts
      JOIN students s ON s.id = ts.student_id
      WHERE ts.school_id = $1
        AND ts.teacher_id = $2
        AND s.deleted_at IS NULL
      ORDER BY ts.created_at DESC, ts.id DESC
      `,
      [tctx.schoolId, teacherId]
    );

    return res.json({ ok: true, teacher_id: teacherId, links: r.rows });
  })
);

adminRouter.post(
  "/teacher-students/:slug/:teacher_id/link",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);
    const studentId = Number(req.body?.student_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "bad_teacher_id" });
    if (!studentId) return res.status(400).json({ ok: false, error: "bad_student_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // Teachers may link themselves only; admins can link any.
    if (tctx.actorType === "teacher") {
      const sc = enforceTeacherSelfScope(tctx, teacherId);
      if (!sc.ok) return res.status(403).json({ ok: false, error: sc.error });
    } else {
      // admin or teacher_admin
      const ctx = await requireSchoolCtxFromActor(req, res, slug);
      if (!ctx) return;
    }

    // verify student in school
    const s = await pool.query(
      `SELECT id FROM students WHERE id=$1 AND school_id=$2 AND deleted_at IS NULL LIMIT 1`,
      [studentId, tctx.schoolId]
    );
    if (!s.rowCount) return res.status(404).json({ ok: false, error: "student_not_found" });

    // verify teacher in school
    const t = await pool.query(
      `SELECT id FROM teachers WHERE id=$1 AND school_id=$2 AND deleted_at IS NULL LIMIT 1`,
      [teacherId, tctx.schoolId]
    );
    if (!t.rowCount) return res.status(404).json({ ok: false, error: "teacher_not_found" });

    // upsert link
    const r = await pool.query(
      `
      INSERT INTO teacher_students (school_id, teacher_id, student_id)
      VALUES ($1,$2,$3)
      ON CONFLICT (school_id, teacher_id, student_id)
      DO UPDATE SET updated_at = NOW()
      RETURNING *
      `,
      [tctx.schoolId, teacherId, studentId]
    );

    return res.json({ ok: true, link: r.rows[0] });
  })
);

adminRouter.post(
  "/teacher-students/:slug/:teacher_id/unlink",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const teacherId = Number(req.params.teacher_id || 0);
    const studentId = Number(req.body?.student_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!teacherId) return res.status(400).json({ ok: false, error: "bad_teacher_id" });
    if (!studentId) return res.status(400).json({ ok: false, error: "bad_student_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    if (tctx.actorType === "teacher") {
      const sc = enforceTeacherSelfScope(tctx, teacherId);
      if (!sc.ok) return res.status(403).json({ ok: false, error: sc.error });
    } else {
      const ctx = await requireSchoolCtxFromActor(req, res, slug);
      if (!ctx) return;
    }

    await pool.query(
      `
      DELETE FROM teacher_students
      WHERE school_id = $1 AND teacher_id = $2 AND student_id = $3
      `,
      [tctx.schoolId, teacherId, studentId]
    );

    return res.json({ ok: true, unlinked: true, teacher_id: teacherId, student_id: studentId });
  })
);

// ============================================================
// TASKS (teacher creates task for student; generates task_token URL)
// ------------------------------------------------------------
// POST /api/admin/tasks/:slug
// body: { student_id, question_ids?, widget_config?, instructions?, no_help?, expires_at? }
// Returns: task + task_url
// ============================================================

adminRouter.post(
  "/tasks/:slug",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // Teacher/admin both allowed, but teacher must act within school and (optionally) linked student.
    const studentId = Number(req.body?.student_id || 0);
    if (!studentId) return res.status(400).json({ ok: false, error: "bad_student_id" });

    // Verify student in school
    const st = await pool.query(
      `SELECT id FROM students WHERE id=$1 AND school_id=$2 AND deleted_at IS NULL LIMIT 1`,
      [studentId, tctx.schoolId]
    );
    if (!st.rowCount) return res.status(404).json({ ok: false, error: "student_not_found" });

    // If teacher actor: ensure student linked to this teacher
    if (tctx.actorType === "teacher") {
      const link = await pool.query(
        `
        SELECT 1 FROM teacher_students
        WHERE school_id=$1 AND teacher_id=$2 AND student_id=$3
        LIMIT 1
        `,
        [tctx.schoolId, tctx.teacher.id, studentId]
      );
      if (!link.rowCount) {
        return res.status(403).json({ ok: false, error: "student_not_linked_to_teacher" });
      }
    }

    // Optional payload elements for task-scoped widget
    const questionIds = Array.isArray(req.body?.question_ids) ? req.body.question_ids : [];
    const widgetConfig = req.body?.widget_config != null ? req.body.widget_config : null;
    const instructions = req.body?.instructions != null ? String(req.body.instructions) : "";
    const noHelp = req.body?.no_help === true;

    // expiration optional
    const expiresAt = req.body?.expires_at ? new Date(String(req.body.expires_at)) : null;
    const token = makeOpaqueToken(24);

    const r = await pool.query(
      `
      INSERT INTO student_tasks
        (school_id, teacher_id, student_id, task_token, question_ids, widget_config, instructions, no_help, expires_at)
      VALUES
        ($1,$2,$3,$4,$5,$6,$7,$8,$9)
      RETURNING *
      `,
      [
        tctx.schoolId,
        (tctx.actorType === "teacher" ? tctx.teacher.id : (tctx.actorId || null)), // admin actorId may not be teacher_id; OK if you allow admin create
        studentId,
        token,
        questionIds,
        widgetConfig,
        instructions,
        noHelp,
        expiresAt
      ]
    );

    const task = r.rows[0];

    // This is the URL the student uses (no JWT required).
    // Your widget should have a handler like /widget/Widget.html?task_token=...
    const taskUrl = `/widget/Widget.html?task_token=${encodeURIComponent(token)}`;

    return res.json({ ok: true, task, task_url: taskUrl });
  })
);

// ============================================================
// STUDENT-FACING: resolve task by token (NO auth)
// ------------------------------------------------------------
// GET /api/task/by-token/:task_token
// Returns minimal task context needed by widget.
// Does NOT expose admin secrets.
// ============================================================

app.get(
  "/api/task/by-token/:task_token",
  asyncHandler(async (req, res) => {
    const token = String(req.params.task_token || "").trim();
    if (!token) return res.status(400).json({ ok: false, error: "missing_task_token" });

    const r = await pool.query(
      `
      SELECT id, school_id, student_id, teacher_id, task_token, question_ids,
             widget_config, instructions, no_help, expires_at, created_at
      FROM student_tasks
      WHERE task_token = $1
        AND deleted_at IS NULL
      LIMIT 1
      `,
      [token]
    );

    if (!r.rowCount) return res.status(404).json({ ok: false, error: "task_not_found" });

    const task = r.rows[0];

    // expiry check
    if (task.expires_at) {
      const exp = new Date(task.expires_at);
      if (Number.isFinite(exp.getTime()) && exp.getTime() < Date.now()) {
        return res.status(410).json({ ok: false, error: "task_expired" });
      }
    }

    // return minimal data for widget initialization
    return res.json({
      ok: true,
      task: {
        id: task.id,
        school_id: task.school_id,
        student_id: task.student_id,
        task_token: task.task_token,
        question_ids: task.question_ids || [],
        widget_config: task.widget_config || null,
        instructions: task.instructions || "",
        no_help: task.no_help === true,
      }
    });
  })
);

// ============================================================
// Teacher/Admin: list tasks (in-scope)
// GET /api/admin/tasks/:slug?student_id=..&teacher_id=..
// ============================================================

adminRouter.get(
  "/tasks/:slug",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const studentId = req.query.student_id ? Number(req.query.student_id) : null;
    const teacherId = req.query.teacher_id ? Number(req.query.teacher_id) : null;

    const where = [`school_id = $1`, `deleted_at IS NULL`];
    const vals = [tctx.schoolId];
    let n = 2;

    if (studentId) { where.push(`student_id = $${n++}`); vals.push(studentId); }

    if (tctx.actorType === "teacher") {
      // teacher scope always self
      where.push(`teacher_id = $${n++}`);
      vals.push(tctx.teacher.id);
    } else if (teacherId) {
      where.push(`teacher_id = $${n++}`);
      vals.push(teacherId);
    }

    const r = await pool.query(
      `
      SELECT id, school_id, teacher_id, student_id, task_token, question_ids,
             instructions, no_help, expires_at, created_at, updated_at
      FROM student_tasks
      WHERE ${where.join(" AND ")}
      ORDER BY created_at DESC, id DESC
      LIMIT 500
      `,
      vals
    );

    return res.json({ ok: true, tasks: r.rows });
  })
);

// ============================================================
// Teacher/Admin: revoke task (soft delete)
// POST /api/admin/tasks/:slug/:task_id/revoke
// ============================================================

adminRouter.post(
  "/tasks/:slug/:task_id/revoke",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const taskId = Number(req.params.task_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!taskId) return res.status(400).json({ ok: false, error: "bad_task_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // teachers can revoke only their tasks
    const where = [`id=$1`, `school_id=$2`, `deleted_at IS NULL`];
    const vals = [taskId, tctx.schoolId];
    let n = 3;

    if (tctx.actorType === "teacher") {
      where.push(`teacher_id = $${n++}`);
      vals.push(tctx.teacher.id);
    }

    const r = await pool.query(
      `
      UPDATE student_tasks
         SET deleted_at = NOW(), updated_at = NOW()
       WHERE ${where.join(" AND ")}
       RETURNING id
      `,
      vals
    );

    if (!r.rowCount) return res.status(404).json({ ok: false, error: "task_not_found" });
    return res.json({ ok: true, revoked: true, task_id: r.rows[0].id });
  })
);

// ============================================================
// //line 5500 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) “Tasks” are the core of the custom widget flow.
// 2) Student-facing token endpoint does NOT require auth.
// 3) Teacher actor is strictly self-scoped for teacher_id operations.
// 4) Linking (teacher_students) is required for teacher-created tasks;
//    admin can create tasks for any student in school.
// 5) task_url is intentionally simple; keep widget responsibility
//    for enforcing question constraints + no_help UI behavior.
// ============================================================

// ============================================================
// End BLOCK 12
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 13
// Focus: Task-scoped submission pipeline (student-facing, no JWT)
// ============================================================

// ------------------------------------------------------------
// Helper: load task by token (shared)
// - returns task row or null response sent already
// ------------------------------------------------------------
async function requireTaskByToken(req, res, taskToken) {
  const token = String(taskToken || "").trim();
  if (!token) {
    res.status(400).json({ ok: false, error: "missing_task_token" });
    return null;
  }

  const r = await pool.query(
    `
    SELECT id, school_id, teacher_id, student_id, task_token,
           question_ids, widget_config, instructions, no_help, expires_at,
           created_at, deleted_at
    FROM student_tasks
    WHERE task_token = $1
      AND deleted_at IS NULL
    LIMIT 1
    `,
    [token]
  );

  if (!r.rowCount) {
    res.status(404).json({ ok: false, error: "task_not_found" });
    return null;
  }

  const task = r.rows[0];

  // expiry check (410 Gone if expired)
  if (task.expires_at) {
    const exp = new Date(task.expires_at);
    if (Number.isFinite(exp.getTime()) && exp.getTime() < Date.now()) {
      res.status(410).json({ ok: false, error: "task_expired" });
      return null;
    }
  }

  return task;
}

// ------------------------------------------------------------
// Helper: validate question_id is allowed for task
// - if task.question_ids empty => allow any (design choice)
// - else require question_id in list
// ------------------------------------------------------------
function isQuestionAllowedForTask(task, questionId) {
  const qid = Number(questionId || 0);
  if (!qid) return false;

  const list = Array.isArray(task?.question_ids) ? task.question_ids : [];
  if (!list.length) return true; // open task (not restricted)
  return list.map(Number).includes(qid);
}

// ------------------------------------------------------------
// Student-facing: create submission under a task token
// POST /api/task/submit
// Body (typical):
//   {
//     task_token,
//     question_id,              // required
//     question_text?,           // optional (if FE already has the prompt)
//     student_name?,            // optional (server can also infer from students table later)
//     student_email?,           // optional
//     audio_url?,               // optional (if uploaded elsewhere)
//     audio_key?,               // optional (s3 key etc.)
//     length_sec?,              // optional (needed for WPM later)
//     transcript?,              // optional (if client has it)
//     transcript_clean?         // optional
//   }
//
// Notes:
// - NO JWT required.
// - Server sets: school_id, teacher_id, student_id, task_id deterministically.
// - This endpoint should remain minimal + stable.
// ------------------------------------------------------------
app.post(
  "/api/task/submit",
  asyncHandler(async (req, res) => {
    const taskToken = String(req.body?.task_token || "").trim();
    const task = await requireTaskByToken(req, res, taskToken);
    if (!task) return;

    const questionId = Number(req.body?.question_id || 0);
    if (!questionId) return res.status(400).json({ ok: false, error: "missing_question_id" });

    // Enforce task question restriction (if any)
    if (!isQuestionAllowedForTask(task, questionId)) {
      return res.status(403).json({ ok: false, error: "question_not_allowed_for_task" });
    }

    // Optional fields (keep loose; validation belongs to later stages)
    const questionText = String(req.body?.question_text || req.body?.question || "").trim() || null;

    const studentName = String(req.body?.student_name || "").trim() || null;
    const studentEmail = String(req.body?.student_email || "").trim().toLowerCase() || null;

    const audioUrl = String(req.body?.audio_url || "").trim() || null;
    const audioKey = String(req.body?.audio_key || "").trim() || null;

    const lengthSec =
      req.body?.length_sec == null ? null : Number(req.body.length_sec);

    const transcript = (req.body?.transcript != null) ? String(req.body.transcript) : null;
    const transcriptClean = (req.body?.transcript_clean != null) ? String(req.body.transcript_clean) : null;

    // Minimal submission record.
    // Your schema may differ; adjust columns to match your actual submissions table.
    // Key requirement: persist school_id + task_id + student_id + teacher_id.
    const ins = await pool.query(
      `
      INSERT INTO submissions
        (school_id, teacher_id, student_id, task_id,
         question_id, question,
         student_name, student_email,
         audio_url, audio_key,
         length_sec,
         transcript, transcript_clean)
      VALUES
        ($1,$2,$3,$4,
         $5,$6,
         $7,$8,
         $9,$10,
         $11,
         $12,$13)
      RETURNING id, school_id, teacher_id, student_id, task_id, question_id, created_at
      `,
      [
        Number(task.school_id),
        (task.teacher_id != null ? Number(task.teacher_id) : null),
        Number(task.student_id),
        Number(task.id),

        questionId,
        questionText,

        studentName,
        studentEmail,

        audioUrl,
        audioKey,

        (Number.isFinite(lengthSec) ? lengthSec : null),

        transcript,
        transcriptClean,
      ]
    );

    const row = ins.rows[0];

    // Return only what the widget needs next.
    return res.json({
      ok: true,
      submission: row,
      next: {
        // hints for next pipeline stages (optional)
        can_score: true,
        task_id: row.task_id,
        submission_id: row.id,
      }
    });
  })
);

// ------------------------------------------------------------
// Student-facing: fetch submission minimal (no JWT)
// GET /api/task/submission/:task_token/:submission_id
// - verifies submission belongs to task_token
// ------------------------------------------------------------
app.get(
  "/api/task/submission/:task_token/:submission_id",
  asyncHandler(async (req, res) => {
    const taskToken = String(req.params.task_token || "").trim();
    const submissionId = Number(req.params.submission_id || 0);

    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });

    const task = await requireTaskByToken(req, res, taskToken);
    if (!task) return;

    const r = await pool.query(
      `
      SELECT id, task_id, school_id, student_id, teacher_id,
             question_id, question, created_at,
             length_sec,
             transcript_clean, transcript
      FROM submissions
      WHERE id = $1
        AND task_id = $2
        AND school_id = $3
        AND deleted_at IS NULL
      LIMIT 1
      `,
      [submissionId, Number(task.id), Number(task.school_id)]
    );

    if (!r.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    // Minimal safe return
    return res.json({ ok: true, submission: r.rows[0] });
  })
);

// ============================================================
// Teacher/Admin: list submissions for a task (JWT required)
// GET /api/admin/task-submissions/:slug/:task_id
// - Teacher actor: only their own tasks
// - Admin: school scope
// ============================================================
adminRouter.get(
  "/task-submissions/:slug/:task_id",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const taskId = Number(req.params.task_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!taskId) return res.status(400).json({ ok: false, error: "bad_task_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // verify task in school (+ teacher scope if teacher actor)
    const where = [`id = $1`, `school_id = $2`, `deleted_at IS NULL`];
    const vals = [taskId, tctx.schoolId];
    let n = 3;

    if (tctx.actorType === "teacher") {
      where.push(`teacher_id = $${n++}`);
      vals.push(tctx.teacher.id);
    }

    const tr = await pool.query(
      `
      SELECT id, school_id, teacher_id, student_id, task_token, question_ids, created_at
      FROM student_tasks
      WHERE ${where.join(" AND ")}
      LIMIT 1
      `,
      vals
    );

    if (!tr.rowCount) return res.status(404).json({ ok: false, error: "task_not_found" });

    const subs = await pool.query(
      `
      SELECT id, task_id, student_id, teacher_id,
             question_id, question,
             created_at,
             length_sec,
             wpm,
             mss_cefr, mss_toefl, vox_score
      FROM submissions
      WHERE school_id = $1
        AND task_id = $2
        AND deleted_at IS NULL
      ORDER BY created_at DESC, id DESC
      LIMIT 500
      `,
      [tctx.schoolId, taskId]
    );

    return res.json({
      ok: true,
      task: tr.rows[0],
      submissions: subs.rows
    });
  })
);

// ============================================================
// Teacher/Admin: fetch submission full (JWT required)
// GET /api/admin/submissions/:slug/:submission_id
// - teacher actor: must be teacher_id on submission
// ============================================================
adminRouter.get(
  "/submissions/:slug/:submission_id",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.params.submission_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const where = [`id=$1`, `school_id=$2`, `deleted_at IS NULL`];
    const vals = [submissionId, tctx.schoolId];
    let n = 3;

    if (tctx.actorType === "teacher") {
      where.push(`teacher_id = $${n++}`);
      vals.push(tctx.teacher.id);
    }

    const r = await pool.query(
      `
      SELECT *
      FROM submissions
      WHERE ${where.join(" AND ")}
      LIMIT 1
      `,
      vals
    );

    if (!r.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    return res.json({ ok: true, submission: r.rows[0] });
  })
);

// ============================================================
// //line 6000 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) Student submission endpoint is intentionally JWT-free.
//    It relies on task_token’s opacity + expiry + revocation.
// 2) Deterministic scoping: school_id, task_id, student_id, teacher_id
//    are always derived from student_tasks, never trusted from client.
// 3) Teacher review endpoints enforce teacher scope using requireTeacherCtx.
// 4) If you later add rate limiting, do it at /api/task/* endpoints.
// 5) This block lays groundwork for WPM fix: length_sec is persisted here.
// ============================================================

// ============================================================
// End BLOCK 13
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 14
// Focus: Task-scoped scoring pipeline + WPM fix (server-side)
// ============================================================

// ------------------------------------------------------------
// Helper: basic word count (robust enough for our use)
// ------------------------------------------------------------
function countWords(text) {
  const s = String(text || "").trim();
  if (!s) return 0;
  // Split on whitespace; keep it simple and stable
  return s.split(/\s+/).filter(Boolean).length;
}

// ------------------------------------------------------------
// Helper: compute WPM from transcript + length_sec
// - returns null if insufficient data
// - clamps weird values
// ------------------------------------------------------------
function computeWpm({ transcript, lengthSec }) {
  const sec = Number(lengthSec || 0);
  if (!Number.isFinite(sec) || sec <= 0) return null;

  const wc = countWords(transcript);
  if (!wc) return null;

  const minutes = sec / 60;
  if (minutes <= 0) return null;

  const wpm = wc / minutes;

  // sanity clamp (optional but helpful)
  if (!Number.isFinite(wpm)) return null;
  if (wpm < 20) return Math.round(wpm);      // keep it
  if (wpm > 400) return Math.round(wpm);     // keep it but it will be suspicious
  return Math.round(wpm);
}

// ------------------------------------------------------------
// Helper: fetch submission with strict school scope (+ teacher scope)
// Used for admin/teacher scoring endpoints
// ------------------------------------------------------------
async function requireSubmissionForTeacherCtx(req, res, { slug, submissionId }) {
  const tctx = await requireTeacherCtx(req, res, slug);
  if (!tctx) return null;

  const where = [`id=$1`, `school_id=$2`, `deleted_at IS NULL`];
  const vals = [Number(submissionId), Number(tctx.schoolId)];
  let n = 3;

  if (tctx.actorType === "teacher") {
    where.push(`teacher_id = $${n++}`);
    vals.push(tctx.teacher.id);
  }

  const r = await pool.query(
    `SELECT * FROM submissions WHERE ${where.join(" AND ")} LIMIT 1`,
    vals
  );

  if (!r.rowCount) {
    res.status(404).json({ ok: false, error: "submission_not_found" });
    return null;
  }

  return { tctx, submission: r.rows[0] };
}

// ------------------------------------------------------------
// Helper: score a submission (single canonical scorer)
// - This is your “one place” to wire Vox + SpeechRater.
// - It *must* be deterministic about what it writes to DB.
// ------------------------------------------------------------
async function scoreSubmissionCanonical({ submissionRow, schoolId, opts = {} }) {
  const force = opts.force === true;

  // Pull canonical inputs
  const submissionId = Number(submissionRow?.id || 0);
  if (!submissionId) throw new Error("bad_submission_id");

  const transcript =
    String(submissionRow.transcript_clean || submissionRow.transcript || "").trim();

  // If no transcript, you can still do audio-only scoring if your pipeline supports it.
  // For now: require at least *some* evidence to score.
  const hasTranscript = !!transcript;
  const audioUrl = String(submissionRow.audio_url || "").trim();
  const audioKey = String(submissionRow.audio_key || "").trim();

  if (!hasTranscript && !audioUrl && !audioKey) {
    return {
      ok: false,
      error: "missing_scoring_inputs",
      detail: { hasTranscript, hasAudioUrl: !!audioUrl, hasAudioKey: !!audioKey }
    };
  }

  // ----------------------------------------------------------
  // PLACEHOLDER A: Vox scoring
  // Replace this with your existing Vox API call.
  //
  // Expected output example:
  //   { ok:true, vox_score: 72, mss_fluency: 3.5, mss_grammar: 3.0, ... }
  // ----------------------------------------------------------
  let vox = null;
  try {
    if (typeof scoreWithVox === "function") {
      vox = await scoreWithVox({
        submissionId,
        schoolId,
        audioUrl: audioUrl || null,
        audioKey: audioKey || null,
        transcript: hasTranscript ? transcript : null,
        force
      });
    }
  } catch (e) {
    vox = { ok: false, error: "vox_failed", message: String(e?.message || e || "") };
  }

  // ----------------------------------------------------------
  // PLACEHOLDER B: SpeechRater scoring (optional)
  // Replace this with your existing SpeechRater call if applicable.
  // ----------------------------------------------------------
  let sr = null;
  try {
    if (typeof scoreWithSpeechRater === "function") {
      sr = await scoreWithSpeechRater({
        submissionId,
        schoolId,
        audioUrl: audioUrl || null,
        audioKey: audioKey || null,
        transcript: hasTranscript ? transcript : null,
        force
      });
    }
  } catch (e) {
    sr = { ok: false, error: "speechrater_failed", message: String(e?.message || e || "") };
  }

  // Normalize what we persist (keep this stable)
  const fields = {
    // vox fields
    vox_score: (vox && vox.vox_score != null) ? vox.vox_score : null,

    // mss breakdown (if you are storing it on submissions)
    mss_fluency: (vox && vox.mss_fluency != null) ? vox.mss_fluency : null,
    mss_grammar: (vox && vox.mss_grammar != null) ? vox.mss_grammar : null,
    mss_pron:    (vox && vox.mss_pron != null) ? vox.mss_pron : null,
    mss_vocab:   (vox && vox.mss_vocab != null) ? vox.mss_vocab : null,
    mss_cefr:    (vox && vox.mss_cefr != null) ? vox.mss_cefr : null,
    mss_toefl:   (vox && vox.mss_toefl != null) ? vox.mss_toefl : null,
    mss_ielts:   (vox && vox.mss_ielts != null) ? vox.mss_ielts : null,
    mss_pte:     (vox && vox.mss_pte != null) ? vox.mss_pte : null,

    // speechrater optional (persist if you have columns)
    sr_overall:  (sr && sr.sr_overall != null) ? sr.sr_overall : null,
    sr_detail:   (sr && sr.sr_detail != null) ? sr.sr_detail : null,
  };

  // Persist only columns that exist in your schema.
  // If your schema differs, adjust the UPDATE accordingly.
  // Note: If you don't have sr_* columns, remove them here.
  await pool.query(
    `
    UPDATE submissions
       SET vox_score   = COALESCE($2, vox_score),
           mss_fluency = COALESCE($3, mss_fluency),
           mss_grammar = COALESCE($4, mss_grammar),
           mss_pron    = COALESCE($5, mss_pron),
           mss_vocab   = COALESCE($6, mss_vocab),
           mss_cefr    = COALESCE($7, mss_cefr),
           mss_toefl   = COALESCE($8, mss_toefl),
           mss_ielts   = COALESCE($9, mss_ielts),
           mss_pte     = COALESCE($10, mss_pte),
           updated_at  = NOW()
     WHERE id = $1
    `,
    [
      submissionId,
      fields.vox_score,
      fields.mss_fluency,
      fields.mss_grammar,
      fields.mss_pron,
      fields.mss_vocab,
      fields.mss_cefr,
      fields.mss_toefl,
      fields.mss_ielts,
      fields.mss_pte,
    ]
  );

  return {
    ok: true,
    submission_id: submissionId,
    vox: vox || null,
    speechrater: sr || null
  };
}

// ============================================================
// Student-facing: finalize submission after upload/transcription
// POST /api/task/finalize
// - no JWT (task token authority)
// - updates transcript + duration + WPM server-side
// - optionally triggers scoring (opts.autoScore)
// ============================================================
app.post(
  "/api/task/finalize",
  asyncHandler(async (req, res) => {
    const taskToken = String(req.body?.task_token || "").trim();
    const submissionId = Number(req.body?.submission_id || 0);
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });

    const task = await requireTaskByToken(req, res, taskToken);
    if (!task) return;

    // Must belong to task + school
    const r = await pool.query(
      `
      SELECT *
      FROM submissions
      WHERE id = $1
        AND task_id = $2
        AND school_id = $3
        AND deleted_at IS NULL
      LIMIT 1
      `,
      [submissionId, Number(task.id), Number(task.school_id)]
    );
    if (!r.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const sub = r.rows[0];

    // Accept updates
    const transcript = (req.body?.transcript != null) ? String(req.body.transcript) : null;
    const transcriptClean = (req.body?.transcript_clean != null) ? String(req.body.transcript_clean) : null;

    const lengthSec =
      req.body?.length_sec == null ? null : Number(req.body.length_sec);

    // WPM: computed from best available transcript + length_sec
    const bestTranscriptForWpm =
      String(transcriptClean || transcript || sub.transcript_clean || sub.transcript || "").trim();

    const wpm = computeWpm({ transcript: bestTranscriptForWpm, lengthSec });

    // Persist finalize fields
    const upd = await pool.query(
      `
      UPDATE submissions
         SET transcript       = COALESCE($2, transcript),
             transcript_clean = COALESCE($3, transcript_clean),
             length_sec       = COALESCE($4, length_sec),
             wpm              = COALESCE($5, wpm),
             updated_at       = NOW()
       WHERE id = $1
       RETURNING id, school_id, task_id, student_id, teacher_id, length_sec, wpm, transcript_clean
      `,
      [submissionId, transcript, transcriptClean, (Number.isFinite(lengthSec) ? lengthSec : null), wpm]
    );

    const out = upd.rows[0];

    // Optional: auto-score (you can keep this OFF in production and only score from teacher/admin)
    const autoScore = req.body?.auto_score === true;

    let scoreResult = null;
    if (autoScore) {
      try {
        // reload full row for scorer
        const rr = await pool.query(`SELECT * FROM submissions WHERE id=$1 LIMIT 1`, [submissionId]);
        if (rr.rowCount) {
          scoreResult = await scoreSubmissionCanonical({
            submissionRow: rr.rows[0],
            schoolId: Number(task.school_id),
            opts: { force: false }
          });
        }
      } catch (e) {
        scoreResult = { ok: false, error: "auto_score_failed", message: String(e?.message || e || "") };
      }
    }

    return res.json({
      ok: true,
      submission: out,
      scoring: scoreResult
    });
  })
);

// ============================================================
// Teacher/Admin: Score submission now (or re-score)
// POST /api/admin/submissions/:slug/:submission_id/score
// Body: { force?: true }
// ============================================================
adminRouter.post(
  "/submissions/:slug/:submission_id/score",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.params.submission_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });

    const pack = await requireSubmissionForTeacherCtx(req, res, { slug, submissionId });
    if (!pack) return;

    const { tctx, submission } = pack;

    // Ensure WPM is computed if length_sec + transcript exists but wpm is null
    const bestTranscriptForWpm =
      String(submission.transcript_clean || submission.transcript || "").trim();

    const wpm = (submission.wpm == null)
      ? computeWpm({ transcript: bestTranscriptForWpm, lengthSec: submission.length_sec })
      : submission.wpm;

    if (submission.wpm == null && wpm != null) {
      await pool.query(
        `UPDATE submissions SET wpm=$2, updated_at=NOW() WHERE id=$1`,
        [submissionId, wpm]
      );
      submission.wpm = wpm;
    }

    // Canonical score call
    const force = req.body?.force === true;

    const scoreResult = await scoreSubmissionCanonical({
      submissionRow: submission,
      schoolId: Number(tctx.schoolId),
      opts: { force }
    });

    return res.json({
      ok: true,
      submission_id: submissionId,
      wpm: submission.wpm ?? null,
      score: scoreResult
    });
  })
);

// ============================================================
// //line 6500 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) WPM fix is enforced server-side in TWO places:
//    - /api/task/finalize (student flow)
//    - /api/admin/.../score (teacher/admin safety backstop)
// 2) scoreSubmissionCanonical is the ONE scoring entry point.
//    Wire your Vox/SpeechRater calls into the two placeholders,
//    but keep the DB-write contract stable.
// 3) Student endpoints are task-token scoped; never trust school_id
//    or student_id from the client.
// 4) Re-score is force=true and should overwrite relevant score fields.
// ============================================================

// ============================================================
// End BLOCK 14
// ============================================================// ============================================================
// SERVER REGEN — BLOCK 15
// Focus: Task assignment + secure task tokens + teacher workflow
// ============================================================

// ------------------------------------------------------------
// Token helper: URL-safe random string
// ------------------------------------------------------------

function makeTaskToken() {
  // 24 bytes => 32 chars base64url-ish; stable uniqueness
  return crypto.randomBytes(24).toString("base64")
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

// ------------------------------------------------------------
// Helper: canonical task URL
// - this is what the teacher copies to student
// ------------------------------------------------------------
function buildTaskUrl({ slug, taskToken }) {
  // Your actual student widget route may differ.
  // Keep it stable and versionable.
  return `/widget/Widget.html?slug=${encodeURIComponent(slug)}&task=${encodeURIComponent(taskToken)}`;
}

// ------------------------------------------------------------
// Helper: require task by token (student-side authority)
// - used by /api/task/* endpoints (see Block 14 finalize)
// ------------------------------------------------------------

// ============================================================
// TEACHER/ADMIN: Students for teacher (scope enforced)
// GET /api/admin/students/:slug
// - teacher => only their students
// - teacher_admin/admin => all students in school (optional filter)
// ============================================================
adminRouter.get(
  "/students/:slug",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const q = String(req.query.q || "").trim().toLowerCase();

    // teacher => restrict to teacher_students
    if (tctx.actorType === "teacher") {
      const teacherId = Number(tctx.teacher.id);

      const r = await pool.query(
        `
        SELECT s.id, s.school_id, s.full_name, s.email, s.is_active, s.created_at
        FROM teacher_students ts
        JOIN students s ON s.id = ts.student_id
        WHERE ts.teacher_id = $1
          AND s.school_id = $2
          AND s.deleted_at IS NULL
          AND ( $3 = '' OR lower(coalesce(s.full_name,'')) LIKE '%'||$3||'%' OR lower(coalesce(s.email,'')) LIKE '%'||$3||'%' )
        ORDER BY s.full_name ASC, s.id ASC
        `,
        [teacherId, tctx.schoolId, q]
      );

      return res.json({ ok: true, students: r.rows, scope: "teacher" });
    }

    // admin/teacher_admin => all students in school
    const r = await pool.query(
      `
      SELECT id, school_id, full_name, email, is_active, created_at
      FROM students
      WHERE school_id = $1
        AND deleted_at IS NULL
        AND ( $2 = '' OR lower(coalesce(full_name,'')) LIKE '%'||$2||'%' OR lower(coalesce(email,'')) LIKE '%'||$2||'%' )
      ORDER BY full_name ASC, id ASC
      `,
      [tctx.schoolId, q]
    );

    return res.json({ ok: true, students: r.rows, scope: "school" });
  })
);

// ============================================================
// TEACHER/ADMIN: Create a task (Assign Practice Loop)
// POST /api/admin/tasks/:slug
// Body:
// {
//   student_id,
//   title?, instructions?, no_help?,
//   question_ids: [..],   // selected from Question Manager
//   max_submissions?,     // optional
//   expires_at?           // optional ISO date
// }
// ============================================================
adminRouter.post(
  "/tasks/:slug",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const studentId = Number(req.body?.student_id || 0);
    if (!studentId) return res.status(400).json({ ok: false, error: "missing_student_id" });

    // Validate student belongs to school (+ teacher relationship if teacher)
    if (tctx.actorType === "teacher") {
      const chk = await pool.query(
        `
        SELECT 1
        FROM teacher_students ts
        JOIN students s ON s.id = ts.student_id
        WHERE ts.teacher_id = $1
          AND ts.student_id = $2
          AND s.school_id = $3
          AND s.deleted_at IS NULL
        LIMIT 1
        `,
        [tctx.teacher.id, studentId, tctx.schoolId]
      );
      if (!chk.rowCount) {
        return res.status(403).json({ ok: false, error: "student_not_assigned_to_teacher" });
      }
    } else {
      const chk = await pool.query(
        `SELECT 1 FROM students WHERE id=$1 AND school_id=$2 AND deleted_at IS NULL LIMIT 1`,
        [studentId, tctx.schoolId]
      );
      if (!chk.rowCount) return res.status(404).json({ ok: false, error: "student_not_found" });
    }

    const title = String(req.body?.title || "Practice Loop").trim();
    const instructions = String(req.body?.instructions || "").trim();
    const noHelp = req.body?.no_help === true;

    const questionIds = Array.isArray(req.body?.question_ids) ? req.body.question_ids : [];
    if (!questionIds.length) return res.status(400).json({ ok: false, error: "missing_question_ids" });

    const maxSubs = req.body?.max_submissions != null ? Number(req.body.max_submissions) : null;
    const expiresAt = req.body?.expires_at != null ? new Date(req.body.expires_at) : null;

    const token = makeTaskToken();
    const teacherId = (tctx.actorType === "teacher") ? Number(tctx.teacher.id) : (Number(req.body?.teacher_id || 0) || null);

    // If admin provided teacher_id, validate it belongs to school
    if (tctx.actorType !== "teacher" && teacherId) {
      const chkT = await pool.query(
        `SELECT 1 FROM teachers WHERE id=$1 AND school_id=$2 AND deleted_at IS NULL LIMIT 1`,
        [teacherId, tctx.schoolId]
      );
      if (!chkT.rowCount) return res.status(400).json({ ok: false, error: "bad_teacher_id" });
    }

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      const ins = await client.query(
        `
        INSERT INTO student_tasks
          (school_id, teacher_id, student_id, task_token,
           title, instructions, no_help,
           question_ids, max_submissions, expires_at,
           is_active)
        VALUES
          ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,true)
        RETURNING *
        `,
        [
          tctx.schoolId,
          teacherId,
          studentId,
          token,
          title,
          instructions,
          noHelp,
          JSON.stringify(questionIds),
          (Number.isFinite(maxSubs) ? maxSubs : null),
          (expiresAt instanceof Date && !isNaN(expiresAt.getTime())) ? expiresAt : null,
        ]
      );

      await client.query("COMMIT");

      const task = ins.rows[0];
      const url = buildTaskUrl({ slug, taskToken: token });

      return res.json({
        ok: true,
        task,
        task_url: url,
      });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch {}
      console.error("POST /tasks/:slug failed:", e);
      return res.status(500).json({ ok: false, error: "create_task_failed" });
    } finally {
      client.release();
    }
  })
);

// ============================================================
// TEACHER/ADMIN: List tasks (assigned tasks)
// GET /api/admin/tasks/:slug?student_id=&active=1
// ============================================================
adminRouter.get(
  "/tasks/:slug",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    const studentId = req.query.student_id != null ? Number(req.query.student_id) : null;
    const activeOnly = String(req.query.active || "") === "1";

    const where = [`school_id=$1`, `deleted_at IS NULL`];
    const vals = [Number(tctx.schoolId)];
    let n = 2;

    if (tctx.actorType === "teacher") {
      where.push(`teacher_id = $${n++}`);
      vals.push(Number(tctx.teacher.id));
    }

    if (studentId) {
      where.push(`student_id = $${n++}`);
      vals.push(Number(studentId));
    }

    if (activeOnly) where.push(`is_active = true`);

    const r = await pool.query(
      `
      SELECT *
      FROM student_tasks
      WHERE ${where.join(" AND ")}
      ORDER BY created_at DESC, id DESC
      `,
      vals
    );

    // Add computed URLs
    const tasks = r.rows.map(t => ({
      ...t,
      task_url: buildTaskUrl({ slug, taskToken: t.task_token })
    }));

    return res.json({ ok: true, tasks });
  })
);

// ============================================================
// TEACHER/ADMIN: Deactivate task (soft stop)
// POST /api/admin/tasks/:slug/:task_id/deactivate
// ============================================================
adminRouter.post(
  "/tasks/:slug/:task_id/deactivate",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const taskId = Number(req.params.task_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!taskId) return res.status(400).json({ ok: false, error: "bad_task_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // teacher can only deactivate their tasks
    const where = [`id=$1`, `school_id=$2`, `deleted_at IS NULL`];
    const vals = [taskId, tctx.schoolId];
    let n = 3;

    if (tctx.actorType === "teacher") {
      where.push(`teacher_id = $${n++}`);
      vals.push(Number(tctx.teacher.id));
    }

    const r = await pool.query(
      `
      UPDATE student_tasks
         SET is_active = false, updated_at = NOW()
       WHERE ${where.join(" AND ")}
       RETURNING id, is_active, updated_at
      `,
      vals
    );

    if (!r.rowCount) return res.status(404).json({ ok: false, error: "task_not_found" });

    return res.json({ ok: true, task: r.rows[0] });
  })
);

// ============================================================
// STUDENT (task-token): Read task config
// GET /api/task/config?task=<token>
// - returns minimal config to power the widget UI
// ============================================================
app.get(
  "/api/task/config",
  asyncHandler(async (req, res) => {
    const tok = String(req.query.task || "").trim();
    const task = await requireTaskByToken(req, res, tok);
    if (!task) return;

    // You may wish to resolve questions from Question Manager here.
    // For now, return IDs; client can request question text via a task-scoped endpoint.
    return res.json({
      ok: true,
      task: {
        id: task.id,
        school_id: task.school_id,
        teacher_id: task.teacher_id,
        student_id: task.student_id,
        title: task.title,
        instructions: task.instructions,
        no_help: !!task.no_help,
        question_ids: Array.isArray(task.question_ids) ? task.question_ids : safeJsonParse(task.question_ids) || [],
        max_submissions: task.max_submissions,
        expires_at: task.expires_at,
      }
    });
  })
);

// ============================================================
// //line 7000 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) All teacher/admin task operations are scoped via requireTeacherCtx():
//    - teacher -> only their students/tasks
//    - admin/teacher_admin -> school scope
// 2) Student endpoints never trust school_id/student_id from the client.
//    Authority is the task_token record.
// 3) The task_url is intentionally generated server-side to prevent FE drift.
// 4) question_ids are stored on student_tasks. If you prefer a join table,
//    swap this to student_task_questions(task_id, question_id).
// ============================================================

// ============================================================
// End BLOCK 15
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 16
// Focus: Task-scoped questions + start submission + enforcement
// ============================================================

// ------------------------------------------------------------
// Local helper (safe JSON parsing) in case earlier blocks differ
// ------------------------------------------------------------
function safeJsonParseAny(v) {
  try {
    if (v == null) return null;
    if (Array.isArray(v)) return v;
    if (typeof v === "object") return v;
    const s = String(v || "").trim();
    if (!s) return null;
    return JSON.parse(s);
  } catch {
    return null;
  }
}

function isExpired(expiresAt) {
  try {
    if (!expiresAt) return false;
    const d = new Date(expiresAt);
    if (isNaN(d.getTime())) return false;
    return d.getTime() < Date.now();
  } catch {
    return false;
  }
}

// ------------------------------------------------------------
// Resolve question_ids array from task row
// ------------------------------------------------------------
function getTaskQuestionIds(task) {
  const raw = task?.question_ids;
  const arr = safeJsonParseAny(raw);
  if (Array.isArray(arr)) return arr.map(x => Number(x)).filter(Boolean);
  return [];
}

// ============================================================
// STUDENT (task-token): Fetch questions for task
// GET /api/task/questions?task=<token>
// - Authority is student_tasks.task_token
// - Returns only questions referenced by task.question_ids
// ============================================================
app.get(
  "/api/task/questions",
  asyncHandler(async (req, res) => {
    const tok = String(req.query.task || "").trim();
    const task = await requireTaskByToken(req, res, tok);
    if (!task) return;

    // Expiry enforcement
    if (isExpired(task.expires_at)) {
      return res.status(403).json({ ok: false, error: "task_expired" });
    }

    const qids = getTaskQuestionIds(task);
    if (!qids.length) {
      return res.json({ ok: true, questions: [], note: "no_questions" });
    }

    // IMPORTANT: scope to task.school_id (never trust client)
    // Assumes questions table has: id, school_id, prompt, title, is_active, sort_order, created_at
    const r = await pool.query(
      `
      SELECT id, school_id, title, prompt, is_active, sort_order
      FROM questions
      WHERE school_id = $1
        AND id = ANY($2::int[])
        AND deleted_at IS NULL
      ORDER BY
        COALESCE(sort_order, 999999) ASC,
        id ASC
      `,
      [Number(task.school_id), qids]
    );

    // Preserve original ordering of qids if desired (optional)
    const byId = new Map(r.rows.map(q => [Number(q.id), q]));
    const ordered = qids.map(id => byId.get(Number(id))).filter(Boolean);

    return res.json({
      ok: true,
      task_id: task.id,
      questions: ordered,
    });
  })
);

// ============================================================
// STUDENT (task-token): Create a submission row (Start Recording)
// POST /api/task/submissions/start
// Body: { task, question_id }
// - Validates question_id is in task.question_ids
// - Enforces is_active, expires_at, max_submissions
// - Creates a "submission stub" for the recording pipeline
// ============================================================
app.post(
  "/api/task/submissions/start",
  asyncHandler(async (req, res) => {
    const tok = String(req.body?.task || "").trim();
    const questionId = Number(req.body?.question_id || 0);

    if (!tok) return res.status(400).json({ ok: false, error: "missing_task_token" });
    if (!questionId) return res.status(400).json({ ok: false, error: "missing_question_id" });

    const task = await requireTaskByToken(req, res, tok);
    if (!task) return;

    // Expiry enforcement
    if (isExpired(task.expires_at)) {
      return res.status(403).json({ ok: false, error: "task_expired" });
    }

    const qids = getTaskQuestionIds(task);
    if (!qids.includes(questionId)) {
      return res.status(403).json({ ok: false, error: "question_not_in_task" });
    }

    // max_submissions enforcement (if configured)
    const maxSubs = task.max_submissions != null ? Number(task.max_submissions) : null;
    if (Number.isFinite(maxSubs) && maxSubs > 0) {
      const c = await pool.query(
        `
        SELECT COUNT(*)::int AS n
        FROM submissions
        WHERE task_id = $1
          AND student_id = $2
          AND deleted_at IS NULL
        `,
        [Number(task.id), Number(task.student_id)]
      );

      const used = Number(c.rows?.[0]?.n || 0);
      if (used >= maxSubs) {
        return res.status(403).json({
          ok: false,
          error: "max_submissions_reached",
          used,
          max: maxSubs,
        });
      }
    }

    // Verify question exists (school scoped)
    const q = await pool.query(
      `
      SELECT id, prompt, title
      FROM questions
      WHERE id = $1
        AND school_id = $2
        AND deleted_at IS NULL
      LIMIT 1
      `,
      [questionId, Number(task.school_id)]
    );
    if (!q.rowCount) return res.status(404).json({ ok: false, error: "question_not_found" });

    const questionText = String(q.rows[0].prompt || "").trim();
    const questionTitle = String(q.rows[0].title || "").trim();

    // Create submission stub
    // Assumes submissions table has: id, school_id, teacher_id, student_id, task_id, question_id, question, status, created_at
    const ins = await pool.query(
      `
      INSERT INTO submissions
        (school_id, teacher_id, student_id, task_id, question_id, question, status)
      VALUES
        ($1,$2,$3,$4,$5,$6,'started')
      RETURNING id, school_id, teacher_id, student_id, task_id, question_id, status, created_at
      `,
      [
        Number(task.school_id),
        (task.teacher_id != null ? Number(task.teacher_id) : null),
        Number(task.student_id),
        Number(task.id),
        Number(questionId),
        (questionTitle ? `${questionTitle}: ${questionText}` : questionText),
      ]
    );

    return res.json({
      ok: true,
      submission: ins.rows[0],
      task: {
        id: task.id,
        no_help: !!task.no_help,
      },
    });
  })
);

// ============================================================
// TEACHER/ADMIN: View submissions for a task
// GET /api/admin/tasks/:slug/:task_id/submissions
// - teacher -> only their tasks
// - admin/teacher_admin -> school scope
// ============================================================
adminRouter.get(
  "/tasks/:slug/:task_id/submissions",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const taskId = Number(req.params.task_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!taskId) return res.status(400).json({ ok: false, error: "bad_task_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // Confirm task scope (teacher restriction if applicable)
    const where = [`id=$1`, `school_id=$2`, `deleted_at IS NULL`];
    const vals = [taskId, tctx.schoolId];
    let n = 3;

    if (tctx.actorType === "teacher") {
      where.push(`teacher_id = $${n++}`);
      vals.push(Number(tctx.teacher.id));
    }

    const t = await pool.query(
      `SELECT * FROM student_tasks WHERE ${where.join(" AND ")} LIMIT 1`,
      vals
    );
    if (!t.rowCount) return res.status(404).json({ ok: false, error: "task_not_found" });

    const s = await pool.query(
      `
      SELECT id, student_id, teacher_id, task_id, question_id, status,
             transcript_clean, transcript, wpm,
             mss_fluency, mss_grammar, mss_pron, mss_vocab, mss_cefr, mss_toefl,
             created_at, updated_at
      FROM submissions
      WHERE task_id = $1
        AND school_id = $2
        AND deleted_at IS NULL
      ORDER BY created_at DESC, id DESC
      `,
      [taskId, tctx.schoolId]
    );

    return res.json({
      ok: true,
      task: t.rows[0],
      submissions: s.rows,
    });
  })
);

// ============================================================
// //line 7500 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) Student endpoints are "token-auth", not actor-auth.
//    The task_token is the authority; no reliance on client school/student ids.
// 2) max_submissions is enforced per student per task.
// 3) "started" submission is a stub; later endpoints should:
//    - attach audio storage reference
//    - finalize transcript + scores
//    - set status 'submitted'/'scored'/etc
// 4) Question ordering is preserved to match the assigned practice loop.
// ============================================================

// ============================================================
// End BLOCK 16
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 17
// Focus: Task-scoped submission finalize (“Stop Recording / Submit”)
// ============================================================

// ------------------------------------------------------------
// Student endpoint: finalize a submission for a task
// POST /api/task/submissions/submit
// Body: {
//   task, submission_id,
//   length_sec,
//   audio_url?, audio_path?,
//   transcript?, transcript_clean?,
//   vox_score?, mss_*?, (optional)
// }
// ------------------------------------------------------------
app.post(
  "/api/task/submissions/submit",
  asyncHandler(async (req, res) => {
    const tok = String(req.body?.task || "").trim();
    const submissionId = Number(req.body?.submission_id || 0);

    const lengthSecRaw = req.body?.length_sec;
    const lengthSec = lengthSecRaw == null ? null : Number(lengthSecRaw);

    if (!tok) return res.status(400).json({ ok: false, error: "missing_task_token" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "missing_submission_id" });

    // Validate task token => authoritative scope
    const task = await requireTaskByToken(req, res, tok);
    if (!task) return;

    // Expiry enforcement (consistent with Block 16)
    if (isExpired(task.expires_at)) {
      return res.status(403).json({ ok: false, error: "task_expired" });
    }

    // Load submission and assert it belongs to this task + student + school
    const sub = await pool.query(
      `
      SELECT id, school_id, student_id, teacher_id, task_id, status,
             question_id, question,
             transcript, transcript_clean,
             length_sec, wpm,
             audio_url, audio_path,
             deleted_at
      FROM submissions
      WHERE id = $1
      LIMIT 1
      `,
      [submissionId]
    );

    if (!sub.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const row = sub.rows[0];
    if (row.deleted_at) return res.status(404).json({ ok: false, error: "submission_deleted" });

    // Hard scope checks: task + student + school
    if (Number(row.task_id) !== Number(task.id)) {
      return res.status(403).json({ ok: false, error: "task_mismatch" });
    }
    if (Number(row.student_id) !== Number(task.student_id)) {
      return res.status(403).json({ ok: false, error: "student_mismatch" });
    }
    if (Number(row.school_id) !== Number(task.school_id)) {
      return res.status(403).json({ ok: false, error: "school_mismatch" });
    }

    // Only allow submit from "started" (or "recording") states
    const status = String(row.status || "").trim().toLowerCase();
    if (status && !["started", "recording"].includes(status)) {
      // idempotency-friendly: if already submitted, just return current
      if (["submitted", "scored"].includes(status)) {
        return res.json({ ok: true, already: true, submission: row });
      }
      return res.status(409).json({ ok: false, error: "bad_submission_state", status });
    }

    // Inputs
    const audioUrl = req.body?.audio_url != null ? String(req.body.audio_url).trim() : null;
    const audioPath = req.body?.audio_path != null ? String(req.body.audio_path).trim() : null;

    const transcript = req.body?.transcript != null ? String(req.body.transcript) : null;
    const transcriptClean = req.body?.transcript_clean != null ? String(req.body.transcript_clean) : null;

    // Enforce length_sec if you want it mandatory
    if (lengthSec == null || !Number.isFinite(lengthSec) || lengthSec <= 0) {
      return res.status(400).json({ ok: false, error: "missing_or_bad_length_sec" });
    }

    // Compute WPM from transcript_clean if present, else transcript
    const wc = countWords(transcriptClean || transcript || row.transcript_clean || row.transcript || "");
    const wpm = computeWpm(wc, lengthSec);

    // Optional Vox / MSS fields (if client passes them; otherwise left null)
    const voxScore = req.body?.vox_score != null ? Number(req.body.vox_score) : null;

    const mssFluency = req.body?.mss_fluency != null ? Number(req.body.mss_fluency) : null;
    const mssGrammar = req.body?.mss_grammar != null ? Number(req.body.mss_grammar) : null;
    const mssPron = req.body?.mss_pron != null ? Number(req.body.mss_pron) : null;
    const mssVocab = req.body?.mss_vocab != null ? Number(req.body.mss_vocab) : null;
    const mssCefr = req.body?.mss_cefr != null ? String(req.body.mss_cefr) : null;
    const mssToefl = req.body?.mss_toefl != null ? Number(req.body.mss_toefl) : null;

    // Update submission (finalize)
    const upd = await pool.query(
      `
      UPDATE submissions
         SET status = 'submitted',
             audio_url = COALESCE($1, audio_url),
             audio_path = COALESCE($2, audio_path),
             transcript = COALESCE($3, transcript),
             transcript_clean = COALESCE($4, transcript_clean),
             length_sec = $5,
             wpm = $6,
             vox_score = COALESCE($7, vox_score),
             mss_fluency = COALESCE($8, mss_fluency),
             mss_grammar = COALESCE($9, mss_grammar),
             mss_pron = COALESCE($10, mss_pron),
             mss_vocab = COALESCE($11, mss_vocab),
             mss_cefr = COALESCE($12, mss_cefr),
             mss_toefl = COALESCE($13, mss_toefl),
             updated_at = NOW()
       WHERE id = $14
       RETURNING id, school_id, teacher_id, student_id, task_id, question_id,
                 status, audio_url, audio_path,
                 transcript, transcript_clean,
                 length_sec, wpm,
                 vox_score, mss_fluency, mss_grammar, mss_pron, mss_vocab, mss_cefr, mss_toefl,
                 created_at, updated_at
      `,
      [
        audioUrl,
        audioPath,
        transcript,
        transcriptClean,
        lengthSec,
        wpm,
        voxScore,
        mssFluency,
        mssGrammar,
        mssPron,
        mssVocab,
        mssCefr,
        mssToefl,
        submissionId,
      ]
    );

    return res.json({
      ok: true,
      submission: upd.rows[0],
      computed: {
        word_count: wc,
        wpm,
      },
    });
  })
);

// ============================================================
// Teacher/Admin: fetch a submission (for Report Viewer / review)
// GET /api/admin/submissions/:slug/:submission_id
// - teacher: only their school scope (and optionally only their submissions)
// - admin/teacher_admin: school scope
// ============================================================
adminRouter.get(
  "/submissions/:slug/:submission_id",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.params.submission_id || 0);
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // Teacher restriction: you may decide to enforce teacher_id match
    // For now, we enforce school scope always, and optionally teacher_id for teacher.
    const where = [`id=$1`, `school_id=$2`, `deleted_at IS NULL`];
    const vals = [submissionId, tctx.schoolId];
    let n = 3;

    if (tctx.actorType === "teacher") {
      where.push(`teacher_id = $${n++}`);
      vals.push(Number(tctx.teacher.id));
    }

    const s = await pool.query(
      `
      SELECT *
      FROM submissions
      WHERE ${where.join(" AND ")}
      LIMIT 1
      `,
      vals
    );

    if (!s.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    return res.json({ ok: true, submission: s.rows[0] });
  })
);

// ============================================================
// //line 8000 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) We compute WPM server-side using transcript word count + length_sec.
//    This aligns with the “flight-safety rule” you captured as an outstanding item.
// 2) Task-token flow is strictly scoped:
//    submission.task_id + submission.student_id + submission.school_id must match task row.
// 3) Submit endpoint is idempotent-ish:
//    if already submitted/scored, returns existing to avoid client retries causing errors.
// 4) If your audio upload happens elsewhere, keep it.
//    This endpoint only binds metadata/transcript + transitions status.
// ============================================================

// ============================================================
// End BLOCK 17
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 18
// Focus: AI report generation (cache + OpenAI + store)
// Supports teacher_admin + teacher + admin (+ superadmin)
// ============================================================

// ------------------------------------------------------------
// Helper: Load a prompt (must belong to school; active optional)
// ------------------------------------------------------------
async function loadAiPromptForSchool({ schoolId, promptId, requireActive = true }) {
  const pid = Number(promptId || 0);
  if (!pid) return null;

  const q = await pool.query(
    `
    SELECT id, school_id, name, prompt_text, notes, language,
           is_default, is_active, sort_order, created_at, updated_at
    FROM ai_prompts
    WHERE id = $1 AND school_id = $2
      ${requireActive ? "AND is_active = true" : ""}
    LIMIT 1
    `,
    [pid, schoolId]
  );

  return q.rowCount ? q.rows[0] : null;
}

// ------------------------------------------------------------
// Helper: Find default prompt for a school
// ------------------------------------------------------------
async function loadDefaultAiPromptForSchool({ schoolId }) {
  const q = await pool.query(
    `
    SELECT id, school_id, name, prompt_text, notes, language,
           is_default, is_active, sort_order, created_at, updated_at
    FROM ai_prompts
    WHERE school_id = $1
      AND is_active = true
      AND is_default = true
    ORDER BY updated_at DESC, id DESC
    LIMIT 1
    `,
    [schoolId]
  );
  return q.rowCount ? q.rows[0] : null;
}

// ------------------------------------------------------------
// Helper: Load submission scoped to school (+ teacher restriction)
// ------------------------------------------------------------
async function loadSubmissionScoped({ submissionId, schoolId, teacherIdOrNull }) {
  const sid = Number(submissionId || 0);
  if (!sid) return null;

  const vals = [sid, schoolId];
  let where = `id=$1 AND school_id=$2 AND deleted_at IS NULL`;
  let n = 3;

  if (teacherIdOrNull) {
    where += ` AND teacher_id=$${n++}`;
    vals.push(Number(teacherIdOrNull));
  }

  const q = await pool.query(`SELECT * FROM submissions WHERE ${where} LIMIT 1`, vals);
  return q.rowCount ? q.rows[0] : null;
}

// ------------------------------------------------------------
// Helper: Build vars for renderPromptTemplate
// ------------------------------------------------------------
function buildSubmissionVars(row) {
  return {
    question: row?.question || "",
    transcript: row?.transcript_clean || row?.transcript || "",
    student: row?.student_name || row?.student_email || row?.student_id || "",

    wpm: row?.wpm ?? "",
    length_sec: row?.length_sec ?? "",

    mss_fluency: row?.mss_fluency ?? "",
    mss_grammar: row?.mss_grammar ?? "",
    mss_pron: row?.mss_pron ?? "",
    mss_vocab: row?.mss_vocab ?? "",
    mss_cefr: row?.mss_cefr ?? "",
    mss_toefl: row?.mss_toefl ?? "",
    mss_ielts: row?.mss_ielts ?? "",
    mss_pte: row?.mss_pte ?? "",

    vox_score: row?.vox_score ?? "",
  };
}

// ------------------------------------------------------------
// ADMIN/TEACHER: existing cache check
// GET /api/admin/reports/existing?submission_id=123&ai_prompt_id=456
// - Auth: actor JWT (teacher/admin)
// - Scope: submission.school_id via slug ctx + (teacher_id if actor is teacher)
// ------------------------------------------------------------
adminRouter.get(
  "/reports/existing",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const submissionId = Number(req.query.submission_id || 0);
    const promptId = Number(req.query.ai_prompt_id || 0);
    const slug = String(req.query.slug || "").trim(); // allow either query slug or header routing
    // NOTE: your FE might not pass slug here today; if not, change to require slug in query.
    if (!submissionId) return res.status(400).json({ ok: false, error: "missing_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "missing_ai_prompt_id" });
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // Confirm submission exists & scope matches school (+ teacher restriction if teacher)
    const sub = await loadSubmissionScoped({
      submissionId,
      schoolId: tctx.schoolId,
      teacherIdOrNull: (tctx.actorType === "teacher" ? Number(tctx.teacher.id) : null),
    });
    if (!sub) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const r = await pool.query(
      `
      SELECT report_text, created_at, updated_at, model, temperature, max_output_tokens
      FROM ai_reports
      WHERE submission_id=$1 AND prompt_id=$2
      LIMIT 1
      `,
      [submissionId, promptId]
    );

    if (!r.rowCount) return res.json({ ok: true, exists: false });

    return res.json({
      ok: true,
      exists: true,
      report_text: r.rows[0].report_text,
      meta: {
        created_at: r.rows[0].created_at,
        updated_at: r.rows[0].updated_at,
        model: r.rows[0].model,
        temperature: r.rows[0].temperature,
        max_output_tokens: r.rows[0].max_output_tokens,
      },
      source: "cache",
    });
  })
);

// ------------------------------------------------------------
// ADMIN/TEACHER: generate report (cache + OpenAI + UPSERT)
// POST /api/admin/reports/generate
// Body: { slug, submission_id, ai_prompt_id, force?: true }
// - Auth: actor JWT (teacher/admin/teacher_admin)
// - Scope: slug + submission.school_id + prompt.school_id + (teacher restriction if teacher)
// ------------------------------------------------------------
adminRouter.post(
  "/reports/generate",
  requireActorAuth,
  asyncHandler(async (req, res) => {
    const slug = String(req.body?.slug || "").trim();
    const submissionId = Number(req.body?.submission_id || 0);
    const promptId = Number(req.body?.ai_prompt_id || 0);
    const force = req.body?.force === true;

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "bad_prompt_id" });

    const tctx = await requireTeacherCtx(req, res, slug);
    if (!tctx) return;

    // Prompt must belong to school
    const prompt = await loadAiPromptForSchool({ schoolId: tctx.schoolId, promptId, requireActive: true });
    if (!prompt) return res.status(404).json({ ok: false, error: "prompt_not_found" });

    // Submission must belong to school (+ teacher restriction if teacher)
    const sub = await loadSubmissionScoped({
      submissionId,
      schoolId: tctx.schoolId,
      teacherIdOrNull: (tctx.actorType === "teacher" ? Number(tctx.teacher.id) : null),
    });
    if (!sub) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const promptText = String(prompt.prompt_text || "").trim();
    if (!promptText) return res.status(400).json({ ok: false, error: "empty_prompt_text" });

    // Render template
    const vars = buildSubmissionVars(sub);
    const rendered = String(renderPromptTemplate(promptText, vars) || "").trim();
    if (!rendered) return res.status(400).json({ ok: false, error: "rendered_prompt_empty" });

    const notes = prompt.notes != null ? String(prompt.notes || "").trim() : "";
    const languageRaw = prompt.language != null ? String(prompt.language || "").trim() : "";
    const language = languageRaw || null;

    const parts = [rendered];
    if (notes) parts.push(`\n\n---\nNotes / Guidance:\n${notes}\n`);
    if (language) parts.push(`\n\n---\nOutput language:\n${language}\n`);
    const finalPrompt = parts.join("");
    const promptHash = sha256(finalPrompt);

    // Cache check
    if (!force) {
      const existing = await pool.query(
        `SELECT report_text, created_at, updated_at
         FROM ai_reports
         WHERE submission_id=$1 AND prompt_id=$2
         LIMIT 1`,
        [submissionId, promptId]
      );

      if (existing.rowCount) {
        return res.json({
          ok: true,
          report_text: existing.rows[0].report_text,
          source: "cache",
          prompt_language: language,
          forced: false,
        });
      }
    }

    // OpenAI generate
    const ai = await openAiGenerateReport({
      promptText: finalPrompt,
      language,
      model: "gpt-4o-mini",
      temperature: 0.4,
      max_output_tokens: 900,
    });

    const reportText = String(ai.text || "").trim();

    await pool.query(
      `
      INSERT INTO ai_reports (submission_id, prompt_id, prompt_hash, model, temperature, max_output_tokens, report_text)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      ON CONFLICT (submission_id, prompt_id)
      DO UPDATE SET
        report_text = EXCLUDED.report_text,
        prompt_hash = EXCLUDED.prompt_hash,
        model = EXCLUDED.model,
        temperature = EXCLUDED.temperature,
        max_output_tokens = EXCLUDED.max_output_tokens,
        updated_at = NOW()
      `,
      [submissionId, promptId, promptHash, ai.model, ai.temperature, ai.max_output_tokens, reportText]
    );

    return res.json({
      ok: true,
      report_text: reportText,
      source: "openai",
      prompt_language: language,
      forced: !!force,
    });
  })
);

// ------------------------------------------------------------
// TASK-SCOPED (optional): Generate report using task token
// POST /api/task/reports/generate
// Body: { task, submission_id, ai_prompt_id?, force?: true }
// - Scope: task token => school + student + task_id
// - Prompt selection:
//   - if ai_prompt_id present => must belong to school
//   - else => use school's default prompt (active)
// ------------------------------------------------------------
app.post(
  "/api/task/reports/generate",
  asyncHandler(async (req, res) => {
    const tok = String(req.body?.task || "").trim();
    const submissionId = Number(req.body?.submission_id || 0);
    const promptId = Number(req.body?.ai_prompt_id || 0) || null;
    const force = req.body?.force === true;

    if (!tok) return res.status(400).json({ ok: false, error: "missing_task_token" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "missing_submission_id" });

    const task = await requireTaskByToken(req, res, tok);
    if (!task) return;

    if (isExpired(task.expires_at)) {
      return res.status(403).json({ ok: false, error: "task_expired" });
    }

    // Load submission and assert strict scope
    const s = await pool.query(
      `
      SELECT *
      FROM submissions
      WHERE id=$1 AND deleted_at IS NULL
      LIMIT 1
      `,
      [submissionId]
    );
    if (!s.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const sub = s.rows[0];
    if (Number(sub.task_id) !== Number(task.id)) return res.status(403).json({ ok: false, error: "task_mismatch" });
    if (Number(sub.student_id) !== Number(task.student_id)) return res.status(403).json({ ok: false, error: "student_mismatch" });
    if (Number(sub.school_id) !== Number(task.school_id)) return res.status(403).json({ ok: false, error: "school_mismatch" });

    // Choose prompt
    let prompt = null;
    if (promptId) {
      prompt = await loadAiPromptForSchool({ schoolId: task.school_id, promptId, requireActive: true });
      if (!prompt) return res.status(404).json({ ok: false, error: "prompt_not_found" });
    } else {
      prompt = await loadDefaultAiPromptForSchool({ schoolId: task.school_id });
      if (!prompt) return res.status(404).json({ ok: false, error: "no_default_prompt" });
    }

    const promptText = String(prompt.prompt_text || "").trim();
    if (!promptText) return res.status(400).json({ ok: false, error: "empty_prompt_text" });

    const vars = buildSubmissionVars(sub);
    const rendered = String(renderPromptTemplate(promptText, vars) || "").trim();
    if (!rendered) return res.status(400).json({ ok: false, error: "rendered_prompt_empty" });

    const notes = prompt.notes != null ? String(prompt.notes || "").trim() : "";
    const languageRaw = prompt.language != null ? String(prompt.language || "").trim() : "";
    const language = languageRaw || null;

    const parts = [rendered];
    if (notes) parts.push(`\n\n---\nNotes / Guidance:\n${notes}\n`);
    if (language) parts.push(`\n\n---\nOutput language:\n${language}\n`);
    const finalPrompt = parts.join("");
    const promptHash = sha256(finalPrompt);

    const effectivePromptId = Number(prompt.id);

    // Cache check
    if (!force) {
      const existing = await pool.query(
        `SELECT report_text
         FROM ai_reports
         WHERE submission_id=$1 AND prompt_id=$2
         LIMIT 1`,
        [submissionId, effectivePromptId]
      );

      if (existing.rowCount) {
        return res.json({
          ok: true,
          report_text: existing.rows[0].report_text,
          source: "cache",
          prompt_id: effectivePromptId,
          forced: false,
        });
      }
    }

    const ai = await openAiGenerateReport({
      promptText: finalPrompt,
      language,
      model: "gpt-4o-mini",
      temperature: 0.4,
      max_output_tokens: 900,
    });

    const reportText = String(ai.text || "").trim();

    await pool.query(
      `
      INSERT INTO ai_reports (submission_id, prompt_id, prompt_hash, model, temperature, max_output_tokens, report_text)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      ON CONFLICT (submission_id, prompt_id)
      DO UPDATE SET
        report_text = EXCLUDED.report_text,
        prompt_hash = EXCLUDED.prompt_hash,
        model = EXCLUDED.model,
        temperature = EXCLUDED.temperature,
        max_output_tokens = EXCLUDED.max_output_tokens,
        updated_at = NOW()
      `,
      [submissionId, effectivePromptId, promptHash, ai.model, ai.temperature, ai.max_output_tokens, reportText]
    );

    return res.json({
      ok: true,
      report_text: reportText,
      source: "openai",
      prompt_id: effectivePromptId,
      forced: !!force,
    });
  })
);

// ============================================================
// //line 8500 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) This block intentionally supports BOTH:
//    - Admin/Teacher portal usage (/api/admin/...)
//    - Task-token usage (/api/task/...)
// 2) Teacher restriction: teachers can only generate reports for their own submissions.
//    If you want teachers to see all submissions in the school, remove teacher_id filter.
// 3) Prompt scoping is enforced strictly by school_id.
// 4) Cache semantics are identical across both flows (ai_reports UPSERT by (submission_id,prompt_id)).
// ============================================================

// ============================================================
// End BLOCK 18
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 19
// Focus: AI Prompt Suggest + Suggest Settings
// Fix: teacher_admin must be allowed (no requireAdminAuth here)
// ============================================================

// ------------------------------------------------------------
// NOTE: These endpoints assume you already have:
// - requireActorAuth
// - requireAdminOrTeacherAdmin
// - requireSchoolCtxFromActor(req,res,slug)
// - getOrCreateSuggestSettings({ schoolId })
// - upsertSuggestSettings({ schoolId, preamble, default_language, default_notes, default_selected_metrics })
// - buildSuggestedPromptTemplate({ preamble, language, notes, selectedMetrics })
// - openAiGenerateReport({ promptText, model, temperature, max_output_tokens })
// ------------------------------------------------------------

// ------------------------------------------------------------
// POST /api/admin/ai-prompts/:slug/suggest
// - Creates an AI-generated "suggested prompt" text using per-school defaults
// - Role: admin OR teacher_admin (teacher_admin must work)
// - Scope: slug -> schoolId verified + token scope enforced
// Body accepts overrides:
//   { language, notes, selected_metrics | selectedMetrics | metrics | default_selected_metrics | default_metrics }
// ------------------------------------------------------------
adminRouter.post(
  "/ai-prompts/:slug/suggest",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // 1) Load per-school defaults (preamble + defaults)
    const ss = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    // 2) Accept overrides
    const language =
      req.body?.language != null ? String(req.body.language).trim() :
      req.body?.default_language != null ? String(req.body.default_language).trim() :
      String(ss?.default_language || "").trim();

    const notes =
      req.body?.notes != null ? String(req.body.notes).trim() :
      req.body?.default_notes != null ? String(req.body.default_notes).trim() :
      String(ss?.default_notes || "").trim();

    const selectedMetrics =
      req.body?.selected_metrics ??
      req.body?.selectedMetrics ??
      req.body?.metrics ??
      req.body?.default_selected_metrics ??
      req.body?.default_metrics ??
      ss?.default_selected_metrics ??
      [];

    // Normalize metrics array defensively
    const metrics = Array.isArray(selectedMetrics) ? selectedMetrics : [];

    const metaPrompt = buildSuggestedPromptTemplate({
      preamble: String(ss?.preamble || ""),
      language,
      notes,
      selectedMetrics: metrics,
    });

    if (!String(metaPrompt || "").trim()) {
      return res.status(400).json({ ok: false, error: "empty_meta_prompt" });
    }

    // 3) Generate suggestion via OpenAI
    const ai = await openAiGenerateReport({
      promptText: metaPrompt,
      model: "gpt-4o-mini",
      temperature: 0.3,
      max_output_tokens: 900,
    });

    const out = String(ai?.text || "").trim();
    if (!out) return res.status(500).json({ ok: false, error: "empty_ai_response" });

    return res.json({
      ok: true,
      slug: ctx.slug,
      schoolId: ctx.schoolId,
      prompt_text: out,
      suggested_prompt_text: out, // FE legacy compatibility
      model: ai?.model || "unknown",
    });
  })
);

// ------------------------------------------------------------
// GET /api/admin/ai-prompts/:slug/suggest-settings
// - Returns per-school suggest defaults (preamble + defaults)
// - Role: admin OR teacher_admin
// - Scope: slug -> schoolId verified + token scope enforced
// ------------------------------------------------------------
adminRouter.get(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const s = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    return res.json({
      ok: true,
      id: s.id,
      preamble_prompt_id: s.id, // FE legacy key
      preamble: s.preamble,
      default_language: s.default_language,
      default_notes: s.default_notes,
      default_selected_metrics: Array.isArray(s.default_selected_metrics) ? s.default_selected_metrics : [],
      exists: !!s.exists,
    });
  })
);

// ------------------------------------------------------------
// PUT /api/admin/ai-prompts/:slug/suggest-settings
// - Saves per-school suggest defaults
// - Role: admin OR teacher_admin
// - Scope: slug -> schoolId verified + token scope enforced
// Body: { preamble, default_language, default_notes, default_selected_metrics }
// Also accepts: default_metrics (transition key)
// ------------------------------------------------------------
adminRouter.put(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // fingerprint for QA
    console.log("[SUGGEST-SETTINGS v3] PUT", req.originalUrl, "schoolId=", ctx.schoolId);

    // Required
    const preamble = (req.body?.preamble != null) ? String(req.body.preamble) : null;
    if (preamble == null) return res.status(400).json({ ok: false, error: "missing_preamble" });

    // Optional
    const default_language = (req.body?.default_language != null) ? String(req.body.default_language) : "";
    const default_notes = (req.body?.default_notes != null) ? String(req.body.default_notes) : "";

    // Transition acceptance
    const default_selected_metrics = Array.isArray(req.body?.default_selected_metrics)
      ? req.body.default_selected_metrics
      : (Array.isArray(req.body?.default_metrics) ? req.body.default_metrics : []);

    const saved = await upsertSuggestSettings({
      schoolId: ctx.schoolId,
      preamble,
      default_language,
      default_notes,
      default_selected_metrics,
    });

    return res.json({
      ok: true,
      id: saved.id,
      preamble_prompt_id: saved.id, // FE legacy key
      preamble: saved.preamble,
      default_language: saved.default_language,
      default_notes: saved.default_notes,
      default_selected_metrics: Array.isArray(saved.default_selected_metrics) ? saved.default_selected_metrics : [],
    });
  })
);

// ============================================================
// //line 9000 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) This block is the fix for your captured diag:
//    POST /api/admin/ai-prompts/:slug/suggest returning 401 for teacher_admin.
//    Cause: requireAdminAuth rejects teacher JWTs.
//    Fix: requireAdminOrTeacherAdmin + requireSchoolCtxFromActor.
// 2) All suggest endpoints now share a single scoping pattern:
//    token scope + slug scope + DB verification.
// 3) If you later decide ONLY admin (not teacher_admin) can modify suggest-settings,
//    keep GET/POST suggest open but change PUT suggest-settings to requireAdminRole.
// ============================================================

// ============================================================
// End BLOCK 19
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 20
// Auth + Role + Scope Middleware (Single source of truth)
// ============================================================

/*
  DESIGN GOALS
  ------------
  1) One JWT middleware for *all* actor types:
     - admin (including superadmin, owner)
     - teacher (including teacher_admin)
  2) All routes use: requireActorAuth + role middleware + (optional) scope middleware.
  3) "Option B" school scoping:
     - actor token MUST include schoolId + slug for non-superadmin
     - slug in route must match token slug unless superadmin
     - DB verifies slug => school_id matches token schoolId
  4) Deterministic error codes: 401 for auth, 403 for forbidden/scope mismatch.
*/

// ------------------------------------------------------------
// Dependencies assumed present elsewhere in server:
// - jwt (jsonwebtoken)
// - JWT_SECRET (string)
// - pool (pg Pool)
// ------------------------------------------------------------

// ---------------------------
// Small helpers
// ---------------------------
function pickBool(v) { return v === true || v === "true" || v === 1 || v === "1"; }
function normStr(v) { return String(v == null ? "" : v).trim(); }
function normLower(v) { return normStr(v).toLowerCase(); }
function asNum(v) { const n = Number(v); return Number.isFinite(n) && n > 0 ? n : null; }

// ------------------------------------------------------------
// Extract Bearer token (Authorization: Bearer <jwt>)
// ------------------------------------------------------------
function getBearerToken(req) {
  try {
    const h = req.headers?.authorization || req.headers?.Authorization || "";
    const s = String(h).trim();
    if (!s) return "";
    const m = s.match(/^Bearer\s+(.+)$/i);
    return m ? String(m[1] || "").trim() : "";
  } catch {
    return "";
  }
}

// ------------------------------------------------------------
// Normalize JWT payload -> canonical req.actor shape
// ------------------------------------------------------------
function normalizeActorFromJwtPayload(payload) {
  const p = payload && typeof payload === "object" ? payload : {};

  // actorType may be "admin" or "teacher"
  const actorType = normLower(p.actorType || p.actor_type || p.type || "");

  // actorId: support either actorId or adminId/teacherId in legacy payloads
  const actorId =
    asNum(p.actorId) ||
    asNum(p.actor_id) ||
    (actorType === "admin" ? asNum(p.adminId || p.admin_id) : null) ||
    (actorType === "teacher" ? asNum(p.teacherId || p.teacher_id) : null) ||
    null;

  // School scope (critical for Option B)
  const schoolId = asNum(p.schoolId || p.school_id) || null;
  const slug = normStr(p.slug || p.schoolSlug || p.school_slug || "");

  // Flags
  const isSuperAdmin = pickBool(p.isSuperAdmin || p.is_superadmin);
  const isOwner = pickBool(p.isOwner || p.is_owner);
  const isTeacherAdmin = pickBool(p.isTeacherAdmin || p.is_teacher_admin);

  // Actor email/name (optional but useful)
  const email = normLower(p.email || "");
  const fullName = normStr(p.full_name || p.fullName || "");

  return {
    actorType,            // "admin" | "teacher" | ""
    actorId,              // number | null
    email,                // string
    fullName,             // string
    schoolId,             // number | null
    slug,                 // string (may be "")
    isSuperAdmin,         // boolean
    isOwner,              // boolean
    isTeacherAdmin,       // boolean

    // Keep raw payload for auditing/diagnostics
    jwt: p,
  };
}

// ------------------------------------------------------------
// Role guards
// ------------------------------------------------------------
function requireAdminOnly(req, res, next) {
  const a = req.actor || {};
  if (a.actorType !== "admin") return res.status(403).json({ ok: false, error: "admin_required" });
  return next();
}

function requireSuperAdminOnly(req, res, next) {
  const a = req.actor || {};
  if (a.actorType !== "admin" || a.isSuperAdmin !== true) {
    return res.status(403).json({ ok: false, error: "superadmin_required" });
  }
  return next();
}

function requireTeacherOnly(req, res, next) {
  const a = req.actor || {};
  if (a.actorType !== "teacher") return res.status(403).json({ ok: false, error: "teacher_required" });
  return next();
}

function requireTeacherOrTeacherAdmin(req, res, next) {
  // For teacher-facing pages, teacher_admin is still a teacher.
  const a = req.actor || {};
  if (a.actorType !== "teacher") return res.status(403).json({ ok: false, error: "teacher_required" });
  return next();
}

function requireAdminOrTeacherAdmin(req, res, next) {
  const a = req.actor || {};
  const isAdmin = a.actorType === "admin";
  const isTeacherAdmin = a.actorType === "teacher" && a.isTeacherAdmin === true;

  if (!isAdmin && !isTeacherAdmin) {
    return res.status(403).json({ ok: false, error: "admin_or_teacher_admin_required" });
  }
  return next();
}

// ============================================================
// School scope resolver (Option B)
// - Use on any route with :slug in path, or where school scoping is required
// ============================================================

// ============================================================
// Optional: lightweight helpers to read last-known actor context
// (useful for logging / diagnostics, safe to keep)
// ============================================================

function actorSummary(req) {
  const a = req.actor || {};
  return {
    actorType: a.actorType || null,
    actorId: a.actorId || null,
    email: a.email || null,
    schoolId: a.schoolId || null,
    slug: a.slug || null,
    isSuperAdmin: !!a.isSuperAdmin,
    isTeacherAdmin: !!a.isTeacherAdmin,
  };
}

// ============================================================
// //line 9500 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) This replaces any need for requireAdminAuth in endpoints that
//    must accept teacher_admin JWTs.
// 2) Migration policy:
//    - Endpoints that should accept {admin, teacher_admin} MUST use:
//        requireActorAuth + requireAdminOrTeacherAdmin + requireSchoolCtxFromActor
//    - Endpoints that are truly admin-only MUST use:
//        requireActorAuth + requireAdminOnly (+ requireSchoolCtxFromActor if scoped)
// 3) If superadmin should be able to "cross schools":
//    - requireSchoolCtxFromActor already allows slug mismatch for superadmin.
//    - You may still decide to enforce DB school scope via additional rules.
// ============================================================

// ============================================================
// End BLOCK 20
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 21
// Router Wiring + Ordering Discipline (Set & Forget)
// ============================================================

/*
  GOAL
  ----
  Make it impossible to:
   - mount admin routes without requireActorAuth
   - accidentally break teacher_admin (by using requireAdminAuth)
   - shadow specific routes by placing param routes too early

  RULES
  -----
  1) All /api/admin routes live in ONE router: adminRouter
  2) requireActorAuth is applied ONCE at the router mount: see 597
     
  3) Inside adminRouter:
       - put fixed/static routes FIRST (e.g., /me, /health, /stats)
       - then more specific subpaths (e.g., /ai-prompts/:slug/suggest-settings)
       - then param routes last (e.g., /ai-prompts/:slug, /ai-prompts/:slug/:id)
  4) Do NOT put generic patterns like "/:slug" above more specific routes.
*/


// Optional: request tracing for admin routes (cheap, valuable)
adminRouter.use((req, res, next) => {
  try {
    // Keep log lightweight; do not dump entire payload/token
    // console.log("[ADMIN]", req.method, req.originalUrl);
  } catch (_) {}
  next();
});

// ============================================================
// 1) Admin "who am I" endpoints (static paths first)
// ============================================================

// GET /api/admin/me
// - This can be used by FE to confirm actor context from token.
// - It intentionally supports admin OR teacher_admin (both are "actor auth").
// - If you need DB-backed admin record, keep separate as /api/admin/admin-me
adminRouter.get(
  "/me",
  asyncHandler(async (req, res) => {
    // req.actor is guaranteed by requireActorAuth at mount
    return res.json({ ok: true, actor: req.actor });
  })
);

// If you still want the DB-backed admins table lookup, make it explicit:
adminRouter.get(
  "/admin-me",
  requireAdminOnly,
  asyncHandler(async (req, res) => {
    const adminId = Number(req.actor?.actorId || 0);
    if (!adminId) return res.status(401).json({ ok: false, error: "bad_admin_id" });

    const q = await pool.query(
      `SELECT id, email, full_name, is_superadmin, is_owner, school_id, is_active
       FROM admins
       WHERE id = $1
       LIMIT 1`,
      [adminId]
    );
    if (!q.rowCount) return res.status(401).json({ ok: false, error: "admin_not_found" });

    const a = q.rows[0];
    if (a.is_active === false) return res.status(403).json({ ok: false, error: "admin_inactive" });

    return res.json({ ok: true, admin: a });
  })
);

// ============================================================
// 2) AI Prompt routes (order matters)
// Prefix: /api/admin/ai-prompts
// ============================================================

// ----- Suggest settings (static tail) MUST come BEFORE "/:slug" -----

// GET /api/admin/ai-prompts/:slug/suggest-settings
adminRouter.get(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOnly, // suggest-settings is admin-only by policy (adjust if desired)
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    // Admin-only scope enforcement still uses the same helper
    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const s = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });
    return res.json({
      ok: true,
      id: s.id,
      preamble_prompt_id: s.id, // legacy FE name
      preamble: s.preamble,
      default_language: s.default_language,
      default_notes: s.default_notes,
      default_selected_metrics: Array.isArray(s.default_selected_metrics) ? s.default_selected_metrics : [],
      exists: !!s.exists,
    });
  })
);

// PUT /api/admin/ai-prompts/:slug/suggest-settings
adminRouter.put(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOnly, // admin-only by policy
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const preamble = (req.body?.preamble != null) ? String(req.body.preamble) : null;
    if (preamble == null) return res.status(400).json({ ok: false, error: "missing_preamble" });

    const default_language = (req.body?.default_language != null) ? String(req.body.default_language) : "";
    const default_notes = (req.body?.default_notes != null) ? String(req.body.default_notes) : "";

    const default_selected_metrics = Array.isArray(req.body?.default_selected_metrics)
      ? req.body.default_selected_metrics
      : (Array.isArray(req.body?.default_metrics) ? req.body.default_metrics : []);

    const saved = await upsertSuggestSettings({
      schoolId: ctx.schoolId,
      preamble,
      default_language,
      default_notes,
      default_selected_metrics,
    });

    return res.json({
      ok: true,
      id: saved.id,
      preamble_prompt_id: saved.id,
      preamble: saved.preamble,
      default_language: saved.default_language,
      default_notes: saved.default_notes,
      default_selected_metrics: Array.isArray(saved.default_selected_metrics) ? saved.default_selected_metrics : [],
    });
  })
);

// ----- Suggest prompt (teacher_admin OR admin) MUST be before "/:slug" -----

// POST /api/admin/ai-prompts/:slug/suggest
adminRouter.post(
  "/ai-prompts/:slug/suggest",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const ss = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    const language =
      req.body?.language != null ? String(req.body.language).trim() :
      req.body?.default_language != null ? String(req.body.default_language).trim() :
      String(ss.default_language || "").trim();

    const notes =
      req.body?.notes != null ? String(req.body.notes).trim() :
      req.body?.default_notes != null ? String(req.body.default_notes).trim() :
      String(ss.default_notes || "").trim();

    const selectedMetrics =
      req.body?.selected_metrics ??
      req.body?.selectedMetrics ??
      req.body?.metrics ??
      req.body?.default_selected_metrics ??
      req.body?.default_metrics ??
      ss.default_selected_metrics ??
      [];

    const metaPrompt = buildSuggestedPromptTemplate({
      preamble: ss.preamble,
      language,
      notes,
      selectedMetrics,
    });

    const ai = await openAiGenerateReport({
      promptText: metaPrompt,
      model: "gpt-4o-mini",
      temperature: 0.3,
      max_output_tokens: 900,
    });

    return res.json({
      ok: true,
      slug: ctx.slug,
      schoolId: ctx.schoolId,
      prompt_text: ai.text,
      suggested_prompt_text: ai.text,
      model: ai.model,
    });
  })
);

// ----- CRUD collection routes -----

// GET /api/admin/ai-prompts/:slug
adminRouter.get(
  "/ai-prompts/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const r = await pool.query(
      `
      SELECT id, school_id, name, prompt_text, is_default, is_active, sort_order,
             notes, language, created_at, updated_at
      FROM ai_prompts
      WHERE school_id = $1
        AND COALESCE(name, '') <> '__SUGGEST_PREAMBLE__'
      ORDER BY
        COALESCE(sort_order, 999999) ASC,
        is_default DESC,
        updated_at DESC,
        id DESC
      `,
      [ctx.schoolId]
    );

    return res.json({ ok: true, prompts: r.rows });
  })
);

// POST /api/admin/ai-prompts/:slug  (create) — admin-only by policy
adminRouter.post(
  "/ai-prompts/:slug",
  requireAdminOnly,
  asyncHandler(async (req, res) => {
    // (implementation lives in your earlier blocks)
    // keep here as placeholder to enforce ordering; actual handler below in full regen
    return res.status(501).json({ ok: false, error: "not_implemented_in_block_21" });
  })
);

// PUT /api/admin/ai-prompts/:slug/:id  (update) — admin-only
adminRouter.put(
  "/ai-prompts/:slug/:id",
  requireAdminOnly,
  asyncHandler(async (req, res) => {
    return res.status(501).json({ ok: false, error: "not_implemented_in_block_21" });
  })
);

// DELETE /api/admin/ai-prompts/:slug/:id (delete) — admin-only
adminRouter.delete(
  "/ai-prompts/:slug/:id",
  requireAdminOnly,
  asyncHandler(async (req, res) => {
    return res.status(501).json({ ok: false, error: "not_implemented_in_block_21" });
  })
);

// PUT /api/admin/ai-prompts/:slug/reorder — admin OR teacher_admin
adminRouter.put(
  "/ai-prompts/:slug/reorder",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    return res.status(501).json({ ok: false, error: "not_implemented_in_block_21" });
  })
);

// ============================================================
// 3) AI Reports routes (static-ish before param heavy routes)
// Prefix: /api/admin/reports
// ============================================================

// GET /api/admin/reports/existing?submission_id=...&ai_prompt_id=...
adminRouter.get(
  "/reports/existing",
  requireAdminOnly, // policy; adjust if teacher_admin should be allowed
  asyncHandler(async (req, res) => {
    return res.status(501).json({ ok: false, error: "not_implemented_in_block_21" });
  })
);

// POST /api/admin/reports/generate
adminRouter.post(
  "/reports/generate",
  requireAdminOnly, // policy
  asyncHandler(async (req, res) => {
    return res.status(501).json({ ok: false, error: "not_implemented_in_block_21" });
  })
);

// DELETE /api/admin/reports/:slug/:submission_id/:prompt_id
adminRouter.delete(
  "/reports/:slug/:submission_id/:prompt_id",
  requireAdminOnly,
  asyncHandler(async (req, res) => {
    return res.status(501).json({ ok: false, error: "not_implemented_in_block_21" });
  })
);

// ============================================================
// //line 10000 (marker)
// ============================================================

// ============================================================
// PEER REVIEW NOTES
// ------------------------------------------------------------
// 1) Route order is intentional. Do NOT move "/ai-prompts/:slug" above
//    "/ai-prompts/:slug/suggest" or "/suggest-settings".
// 2) Mount path is authoritative: "/api/admin".
//    If you get "Cannot GET /api/admin/..." => router isn't mounted or server isn't restarted.
// 3) "Policy knobs":
//    - If teacher_admin should be allowed for reports:
//        change requireAdminOnly -> requireAdminOrTeacherAdmin
//        and keep scope via requireSchoolCtxFromActor.
// ============================================================

// ============================================================
// End BLOCK 21
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 22
// AI PROMPTS — CRUD + ORDERING + DEFAULT (Set & Forget)
// (fills in Block 21 placeholders)
// ============================================================

// Helper: normalize unique constraint checks
function isUniqueViolation(err, nameHint) {
  const msg = String(err?.message || "");
  if (!msg) return false;
  if (nameHint && msg.includes(nameHint)) return true;
  // generic postgres unique
  return msg.toLowerCase().includes("duplicate key") || msg.toLowerCase().includes("unique");
}

// ------------------------------------------------------------
// POST /api/admin/ai-prompts/:slug
// Create prompt (ADMIN ONLY)
// ------------------------------------------------------------
adminRouter.post(
  "/ai-prompts/:slug",
  requireAdminOnly,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const name = String(req.body?.name || "").trim();
    const promptText = String(req.body?.prompt_text || "").trim();
    if (!name) return res.status(400).json({ ok: false, error: "missing_name" });
    if (!promptText) return res.status(400).json({ ok: false, error: "missing_prompt_text" });

    const isDefault = req.body?.is_default === true;
    const isActive = req.body?.is_active !== false; // default true
    const sortOrder = req.body?.sort_order != null ? Number(req.body.sort_order) : null;
    const notes = req.body?.notes != null ? String(req.body.notes) : null;
    const language = req.body?.language != null ? String(req.body.language) : null;

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      if (isDefault) {
        await client.query(
          `UPDATE ai_prompts
             SET is_default=false, updated_at=now()
           WHERE school_id=$1`,
          [ctx.schoolId]
        );
      }

      const ins = await client.query(
        `
        INSERT INTO ai_prompts
          (school_id, name, prompt_text, is_default, is_active, sort_order, notes, language)
        VALUES
          ($1,$2,$3,$4,$5,$6,$7,$8)
        RETURNING
          id, school_id, name, prompt_text, is_default, is_active, sort_order,
          notes, language, created_at, updated_at
        `,
        [ctx.schoolId, name, promptText, isDefault, isActive, sortOrder, notes, language]
      );

      await client.query("COMMIT");
      return res.json({ ok: true, prompt: ins.rows[0] });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch (_) {}

      if (isUniqueViolation(e, "ux_ai_prompts_school_name")) {
        return res.status(409).json({ ok: false, error: "duplicate_name" });
      }

      console.error("POST /ai-prompts/:slug failed", e);
      return res.status(500).json({ ok: false, error: "internal_error" });
    } finally {
      client.release();
    }
  })
);

// ------------------------------------------------------------
// PUT /api/admin/ai-prompts/:slug/:id
// Update prompt (ADMIN ONLY)
// ------------------------------------------------------------
adminRouter.put(
  "/ai-prompts/:slug/:id",
  requireAdminOnly,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const id = Number(req.params.id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!id) return res.status(400).json({ ok: false, error: "bad_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      // Ensure belongs to school
      const exists = await client.query(
        `SELECT id, is_default
           FROM ai_prompts
          WHERE id=$1 AND school_id=$2
          LIMIT 1`,
        [id, ctx.schoolId]
      );
      if (!exists.rowCount) {
        await client.query("ROLLBACK");
        return res.status(404).json({ ok: false, error: "prompt_not_found" });
      }

      const fields = [];
      const vals = [];
      let n = 1;

      const setField = (col, v) => {
        fields.push(`${col}=$${n++}`);
        vals.push(v);
      };

      // Determine default intent
      const wantsDefault = req.body?.is_default === true;

      // Only set provided fields
      if (req.body?.name != null) setField("name", String(req.body.name).trim());
      if (req.body?.prompt_text != null) setField("prompt_text", String(req.body.prompt_text).trim());
      if (req.body?.notes != null) setField("notes", String(req.body.notes));
      if (req.body?.language != null) setField("language", String(req.body.language));
      if (req.body?.sort_order != null) setField("sort_order", Number(req.body.sort_order));
      if (req.body?.is_active != null) setField("is_active", req.body.is_active === true);

      if (wantsDefault) {
        // Clear other defaults then set this one default+active
        await client.query(
          `UPDATE ai_prompts
              SET is_default=false, updated_at=now()
            WHERE school_id=$1`,
          [ctx.schoolId]
        );
        setField("is_default", true);
        setField("is_active", true);
      } else if (req.body?.is_default === false) {
        setField("is_default", false);
      }

      // If nothing changed, return unchanged
      if (!fields.length) {
        await client.query("ROLLBACK");
        return res.json({ ok: true, unchanged: true });
      }

      // Always touch updated_at
      setField("updated_at", new Date());

      // WHERE params
      vals.push(id, ctx.schoolId);

      const upd = await client.query(
        `
        UPDATE ai_prompts
           SET ${fields.join(", ")}
         WHERE id=$${n++} AND school_id=$${n++}
        RETURNING
          id, school_id, name, prompt_text, is_default, is_active, sort_order,
          notes, language, created_at, updated_at
        `,
        vals
      );

      await client.query("COMMIT");
      return res.json({ ok: true, prompt: upd.rows[0] });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch (_) {}

      if (isUniqueViolation(e, "ux_ai_prompts_school_name")) {
        return res.status(409).json({ ok: false, error: "duplicate_name" });
      }

      console.error("PUT /ai-prompts/:slug/:id failed", e);
      return res.status(500).json({ ok: false, error: "internal_error" });
    } finally {
      client.release();
    }
  })
);

// ------------------------------------------------------------
// DELETE /api/admin/ai-prompts/:slug/:id
// Soft delete by default; optional hard delete (?hard=1) if unreferenced
// ADMIN ONLY
// ------------------------------------------------------------
adminRouter.delete(
  "/ai-prompts/:slug/:id",
  requireAdminOnly,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const id = Number(req.params.id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!id) return res.status(400).json({ ok: false, error: "bad_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const wantHard = String(req.query?.hard || "") === "1";

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      const p = await client.query(
        `SELECT id, is_default
           FROM ai_prompts
          WHERE id=$1 AND school_id=$2
          LIMIT 1`,
        [id, ctx.schoolId]
      );
      if (!p.rowCount) {
        await client.query("ROLLBACK");
        return res.status(404).json({ ok: false, error: "prompt_not_found" });
      }

      if (p.rows[0].is_default) {
        await client.query("ROLLBACK");
        return res.status(409).json({ ok: false, error: "cannot_delete_default" });
      }

      if (wantHard) {
        // Only hard delete if not referenced
        const ref = await client.query(
          `SELECT 1 FROM ai_reports WHERE prompt_id=$1 LIMIT 1`,
          [id]
        );

        if (ref.rowCount) {
          // fallback to soft delete
          const soft = await client.query(
            `UPDATE ai_prompts
                SET is_active=false, updated_at=now()
              WHERE id=$1 AND school_id=$2
            RETURNING id`,
            [id, ctx.schoolId]
          );
          await client.query("COMMIT");
          return res.json({ ok: true, deleted: true, mode: "soft", id: soft.rows[0].id });
        }

        await client.query(
          `DELETE FROM ai_prompts WHERE id=$1 AND school_id=$2`,
          [id, ctx.schoolId]
        );
        await client.query("COMMIT");
        return res.json({ ok: true, deleted: true, mode: "hard", id });
      }

      // Default: soft delete
      const soft = await client.query(
        `UPDATE ai_prompts
            SET is_active=false, updated_at=now()
          WHERE id=$1 AND school_id=$2
        RETURNING id`,
        [id, ctx.schoolId]
      );

      await client.query("COMMIT");
      return res.json({ ok: true, deleted: true, mode: "soft", id: soft.rows[0].id });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch (_) {}
      console.error("DELETE /ai-prompts/:slug/:id failed", e);
      return res.status(500).json({ ok: false, error: "internal_error" });
    } finally {
      client.release();
    }
  })
);

// ------------------------------------------------------------
// POST /api/admin/ai-prompts/:slug/:id/set-default
// ADMIN ONLY
// ------------------------------------------------------------
adminRouter.post(
  "/ai-prompts/:slug/:id/set-default",
  requireAdminOnly,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const id = Number(req.params.id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!id) return res.status(400).json({ ok: false, error: "bad_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      const p = await client.query(
        `SELECT id
           FROM ai_prompts
          WHERE id=$1 AND school_id=$2
          LIMIT 1`,
        [id, ctx.schoolId]
      );
      if (!p.rowCount) {
        await client.query("ROLLBACK");
        return res.status(404).json({ ok: false, error: "prompt_not_found" });
      }

      await client.query(
        `UPDATE ai_prompts
            SET is_default=false, updated_at=now()
          WHERE school_id=$1`,
        [ctx.schoolId]
      );

      const upd = await client.query(
        `UPDATE ai_prompts
            SET is_default=true, is_active=true, updated_at=now()
          WHERE id=$1 AND school_id=$2
        RETURNING id, school_id, name, is_default, is_active, updated_at`,
        [id, ctx.schoolId]
      );

      await client.query("COMMIT");
      return res.json({ ok: true, prompt: upd.rows[0] });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch (_) {}
      console.error("POST /set-default failed", e);
      return res.status(500).json({ ok: false, error: "internal_error" });
    } finally {
      client.release();
    }
  })
);

// ------------------------------------------------------------
// PUT /api/admin/ai-prompts/:slug/reorder
// ADMIN OR TEACHER_ADMIN
// ------------------------------------------------------------
adminRouter.put(
  "/ai-prompts/:slug/reorder",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const order = Array.isArray(req.body?.order) ? req.body.order : [];

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      for (const item of order) {
        const id = Number(item?.id || 0);
        const so = (item?.sort_order == null) ? null : Number(item.sort_order);
        if (!id) continue;

        await client.query(
          `UPDATE ai_prompts
              SET sort_order=$1, updated_at=now()
            WHERE id=$2 AND school_id=$3`,
          [so, id, ctx.schoolId]
        );
      }

      await client.query("COMMIT");
      return res.json({ ok: true });
    } catch (e) {
      try { await client.query("ROLLBACK"); } catch (_) {}
      console.error("PUT /ai-prompts/:slug/reorder failed", e);
      return res.status(500).json({ ok: false, error: "internal_error" });
    } finally {
      client.release();
    }
  })
);

// ============================================================
// //line 10500
// ============================================================

// ============================================================
// End BLOCK 22
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 23
// AI REPORTS — existing + generate + delete (Set & Forget)
// ============================================================

// ------------------------------------------------------------
// GET /api/admin/reports/existing?slug=...&submission_id=123&ai_prompt_id=456
// - checks cache only
// - scope enforced by submissions.school_id + actor school scope
// ADMIN OR TEACHER_ADMIN
// ------------------------------------------------------------
adminRouter.get(
  "/reports/existing",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.query?.slug || "").trim();
    const submissionId = Number(req.query?.submission_id || 0);
    const promptId = Number(req.query?.ai_prompt_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "missing_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "missing_ai_prompt_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Scope via submissions.school_id (authoritative)
    const sc = await pool.query(
      `SELECT school_id
         FROM submissions
        WHERE id = $1
          AND deleted_at IS NULL
        LIMIT 1`,
      [submissionId]
    );
    if (!sc.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const subSchoolId = Number(sc.rows[0].school_id);
    if (subSchoolId !== ctx.schoolId) {
      return res.status(403).json({ ok: false, error: "school_scope_mismatch" });
    }

    const r = await pool.query(
      `SELECT report_text, created_at, updated_at, model, temperature, max_output_tokens
         FROM ai_reports
        WHERE submission_id = $1
          AND prompt_id = $2
        LIMIT 1`,
      [submissionId, promptId]
    );

    if (!r.rowCount) {
      return res.json({ ok: true, exists: false });
    }

    return res.json({
      ok: true,
      exists: true,
      report_text: r.rows[0].report_text,
      meta: {
        created_at: r.rows[0].created_at,
        updated_at: r.rows[0].updated_at,
        model: r.rows[0].model,
        temperature: r.rows[0].temperature,
        max_output_tokens: r.rows[0].max_output_tokens,
      },
      source: "cache",
    });
  })
);

// ------------------------------------------------------------
// POST /api/admin/reports/generate
// body: { slug, submission_id, ai_prompt_id, force?: true }
// - scope enforced (slug + submissions.school_id)
// - prompt must belong to same school and is_active=true
// - UPSERT into ai_reports
// ADMIN OR TEACHER_ADMIN
// ------------------------------------------------------------
adminRouter.post(
  "/reports/generate",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.body?.slug || "").trim();
    const submissionId = Number(req.body?.submission_id || 0);
    const promptId = Number(req.body?.ai_prompt_id || 0);
    const force = req.body?.force === true;

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "bad_ai_prompt_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Submission must belong to school, not deleted
    const sub = await pool.query(
      `SELECT *
         FROM submissions
        WHERE id = $1
          AND school_id = $2
          AND deleted_at IS NULL
        LIMIT 1`,
      [submissionId, ctx.schoolId]
    );
    if (!sub.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const row = sub.rows[0];

    // Prompt must belong to school + be active
    const p = await pool.query(
      `SELECT id, prompt_text, notes, language
         FROM ai_prompts
        WHERE id = $1
          AND school_id = $2
          AND is_active = true
        LIMIT 1`,
      [promptId, ctx.schoolId]
    );
    if (!p.rowCount) return res.status(404).json({ ok: false, error: "prompt_not_found" });

    const promptText = String(p.rows[0].prompt_text || "").trim();
    const notes = String(p.rows[0].notes || "").trim();
    const languageRaw =
      p.rows[0].language === null || p.rows[0].language === undefined
        ? ""
        : String(p.rows[0].language || "").trim();
    const language = languageRaw || null;

    if (!promptText) return res.status(400).json({ ok: false, error: "empty_prompt_text" });

    // Cache check (unless forced)
    if (!force) {
      const existing = await pool.query(
        `SELECT report_text, created_at, updated_at, model, temperature, max_output_tokens
           FROM ai_reports
          WHERE submission_id = $1
            AND prompt_id = $2
          LIMIT 1`,
        [submissionId, promptId]
      );

      if (existing.rowCount) {
        return res.json({
          ok: true,
          report_text: existing.rows[0].report_text,
          source: "cache",
          prompt_language: language,
          forced: false,
          meta: {
            created_at: existing.rows[0].created_at,
            updated_at: existing.rows[0].updated_at,
            model: existing.rows[0].model,
            temperature: existing.rows[0].temperature,
            max_output_tokens: existing.rows[0].max_output_tokens,
          },
        });
      }
    }

    // Variables available to template (safe defaults)
    const vars = {
      question: row.question || "",
      transcript: row.transcript_clean || row.transcript || "",
      student: row.student_name || row.student_email || row.student_id || "",

      wpm: row.wpm ?? "",

      mss_fluency: row.mss_fluency ?? "",
      mss_grammar: row.mss_grammar ?? "",
      mss_pron: row.mss_pron ?? "",
      mss_vocab: row.mss_vocab ?? "",
      mss_cefr: row.mss_cefr ?? "",
      mss_toefl: row.mss_toefl ?? "",
      mss_ielts: row.mss_ielts ?? "",
      mss_pte: row.mss_pte ?? "",

      vox_score: row.vox_score ?? "",
    };

    // Render template with vars
    const renderedPromptText = String(renderPromptTemplate(promptText, vars) || "").trim();
    if (!renderedPromptText) return res.status(400).json({ ok: false, error: "rendered_prompt_empty" });

    // Append notes + language to rendered prompt
    const parts = [renderedPromptText];
    if (notes) parts.push(`\n\n---\nNotes / Guidance:\n${notes}\n`);
    if (language) parts.push(`\n\n---\nOutput language:\n${language}\n`);
    const finalPrompt = parts.join("");

    const promptHash = sha256(finalPrompt);

    // Generate via OpenAI
    const ai = await openAiGenerateReport({
      promptText: finalPrompt,
      language,
      model: "gpt-4o-mini",
      temperature: 0.4,
      max_output_tokens: 900,
    });

    const reportText = String(ai?.text || "").trim();

    await pool.query(
      `INSERT INTO ai_reports
         (submission_id, prompt_id, prompt_hash, model, temperature, max_output_tokens, report_text)
       VALUES
         ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (submission_id, prompt_id)
       DO UPDATE SET
         report_text = EXCLUDED.report_text,
         prompt_hash = EXCLUDED.prompt_hash,
         model = EXCLUDED.model,
         temperature = EXCLUDED.temperature,
         max_output_tokens = EXCLUDED.max_output_tokens,
         updated_at = NOW()`,
      [submissionId, promptId, promptHash, ai.model, ai.temperature, ai.max_output_tokens, reportText]
    );

    return res.json({
      ok: true,
      report_text: reportText,
      source: "openai",
      prompt_language: language,
      forced: !!force,
      meta: {
        model: ai.model,
        temperature: ai.temperature,
        max_output_tokens: ai.max_output_tokens,
      },
    });
  })
);

// ------------------------------------------------------------
// DELETE /api/admin/reports/:slug/:submission_id/:prompt_id
// - delete cached report for that submission/prompt
// - scope enforced via submissions.school_id + ctx.schoolId
// ADMIN OR TEACHER_ADMIN
// ------------------------------------------------------------
adminRouter.delete(
  "/reports/:slug/:submission_id/:prompt_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.params.submission_id || 0);
    const promptId = Number(req.params.prompt_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "bad_prompt_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Scope via submissions.school_id
    const sc = await pool.query(
      `SELECT school_id
         FROM submissions
        WHERE id = $1
          AND deleted_at IS NULL
        LIMIT 1`,
      [submissionId]
    );
    if (!sc.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const subSchoolId = Number(sc.rows[0].school_id);
    if (subSchoolId !== ctx.schoolId) {
      return res.status(403).json({ ok: false, error: "school_scope_mismatch" });
    }

    const del = await pool.query(
      `DELETE FROM ai_reports
        WHERE submission_id = $1
          AND prompt_id = $2`,
      [submissionId, promptId]
    );

    return res.json({ ok: true, deleted: true, rowCount: del.rowCount || 0 });
  })
);

// ============================================================
// //line 11000
// ============================================================

// ============================================================
// End BLOCK 23
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 24
// AI PROMPT SUGGEST + SUGGEST-SETTINGS (Set & Forget)
// ============================================================

// ---------------------------------------------------------------------
// POST /api/admin/ai-prompts/:slug/suggest
// - actor JWT (admin OR teacher_admin)
// - school scope enforced via requireSchoolCtxFromActor()
// - uses ai_prompt_preamble per-school defaults (getOrCreateSuggestSettings)
// ---------------------------------------------------------------------
adminRouter.post(
  "/ai-prompts/:slug/suggest",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // 1) Load per-school defaults
    const ss = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    // 2) Accept request overrides
    const language =
      req.body?.language != null ? String(req.body.language).trim()
      : req.body?.default_language != null ? String(req.body.default_language).trim()
      : String(ss.default_language || "").trim();

    const notes =
      req.body?.notes != null ? String(req.body.notes).trim()
      : req.body?.default_notes != null ? String(req.body.default_notes).trim()
      : String(ss.default_notes || "").trim();

    const selectedMetrics =
      req.body?.selected_metrics ??
      req.body?.selectedMetrics ??
      req.body?.metrics ??
      req.body?.default_selected_metrics ??
      req.body?.default_metrics ??
      ss.default_selected_metrics ??
      [];

    const metaPrompt = buildSuggestedPromptTemplate({
      preamble: ss.preamble,
      language,
      notes,
      selectedMetrics,
    });

    // 3) Generate suggestion via OpenAI
    const ai = await openAiGenerateReport({
      promptText: metaPrompt,
      model: "gpt-4o-mini",
      temperature: 0.3,
      max_output_tokens: 900,
    });

    return res.json({
      ok: true,
      slug: ctx.slug,
      schoolId: ctx.schoolId,
      prompt_text: ai.text,
      suggested_prompt_text: ai.text,
      model: ai.model,
    });
  })
);

// ---------------------------------------------------------------------
// GET /api/admin/ai-prompts/:slug/suggest-settings
// - actor JWT (admin OR teacher_admin)
// - returns per-school suggest settings (ai_prompt_preamble)
// ---------------------------------------------------------------------
adminRouter.get(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const s = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    return res.json({
      ok: true,
      id: s.id,
      preamble_prompt_id: s.id, // keep FE stable (legacy name)
      preamble: s.preamble,
      default_language: s.default_language,
      default_notes: s.default_notes,
      default_selected_metrics: Array.isArray(s.default_selected_metrics) ? s.default_selected_metrics : [],
      exists: !!s.exists,
    });
  })
);

// ---------------------------------------------------------------------
// PUT /api/admin/ai-prompts/:slug/suggest-settings
// body: { preamble, default_language, default_notes, default_selected_metrics }
// also accepts: default_metrics (FE transition key)
// - actor JWT (admin OR teacher_admin)  [recommended for your current QA]
// ---------------------------------------------------------------------
adminRouter.put(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Fingerprint log so you can confirm this handler is responding
    console.log("[SUGGEST-SETTINGS v3] PUT", req.originalUrl, "schoolId=", ctx.schoolId, "actorType=", ctx.actorType);

    // Required
    const preamble = (req.body?.preamble != null) ? String(req.body.preamble) : null;
    if (preamble == null) return res.status(400).json({ ok: false, error: "missing_preamble" });

    // Optional
    const default_language = (req.body?.default_language != null) ? String(req.body.default_language) : "";
    const default_notes = (req.body?.default_notes != null) ? String(req.body.default_notes) : "";

    // Accept either key during transition
    const default_selected_metrics = Array.isArray(req.body?.default_selected_metrics)
      ? req.body.default_selected_metrics
      : (Array.isArray(req.body?.default_metrics) ? req.body.default_metrics : []);

    const saved = await upsertSuggestSettings({
      schoolId: ctx.schoolId,
      preamble,
      default_language,
      default_notes,
      default_selected_metrics,
    });

    return res.json({
      ok: true,
      id: saved.id,
      preamble_prompt_id: saved.id, // keep FE stable
      preamble: saved.preamble,
      default_language: saved.default_language,
      default_notes: saved.default_notes,
      default_selected_metrics: Array.isArray(saved.default_selected_metrics) ? saved.default_selected_metrics : [],
    });
  })
);

// ============================================================
// //line 11500
// ============================================================

// ============================================================
// End BLOCK 24
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 24
// AI PROMPT SUGGEST + SUGGEST-SETTINGS (Set & Forget)
// ============================================================

// ---------------------------------------------------------------------
// POST /api/admin/ai-prompts/:slug/suggest
// - actor JWT (admin OR teacher_admin)
// - school scope enforced via requireSchoolCtxFromActor()
// - uses ai_prompt_preamble per-school defaults (getOrCreateSuggestSettings)
// ---------------------------------------------------------------------
adminRouter.post(
  "/ai-prompts/:slug/suggest",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // 1) Load per-school defaults
    const ss = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    // 2) Accept request overrides
    const language =
      req.body?.language != null ? String(req.body.language).trim()
      : req.body?.default_language != null ? String(req.body.default_language).trim()
      : String(ss.default_language || "").trim();

    const notes =
      req.body?.notes != null ? String(req.body.notes).trim()
      : req.body?.default_notes != null ? String(req.body.default_notes).trim()
      : String(ss.default_notes || "").trim();

    const selectedMetrics =
      req.body?.selected_metrics ??
      req.body?.selectedMetrics ??
      req.body?.metrics ??
      req.body?.default_selected_metrics ??
      req.body?.default_metrics ??
      ss.default_selected_metrics ??
      [];

    const metaPrompt = buildSuggestedPromptTemplate({
      preamble: ss.preamble,
      language,
      notes,
      selectedMetrics,
    });

    // 3) Generate suggestion via OpenAI
    const ai = await openAiGenerateReport({
      promptText: metaPrompt,
      model: "gpt-4o-mini",
      temperature: 0.3,
      max_output_tokens: 900,
    });

    return res.json({
      ok: true,
      slug: ctx.slug,
      schoolId: ctx.schoolId,
      prompt_text: ai.text,
      suggested_prompt_text: ai.text,
      model: ai.model,
    });
  })
);

// ---------------------------------------------------------------------
// GET /api/admin/ai-prompts/:slug/suggest-settings
// - actor JWT (admin OR teacher_admin)
// - returns per-school suggest settings (ai_prompt_preamble)
// ---------------------------------------------------------------------
adminRouter.get(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const s = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    return res.json({
      ok: true,
      id: s.id,
      preamble_prompt_id: s.id, // keep FE stable (legacy name)
      preamble: s.preamble,
      default_language: s.default_language,
      default_notes: s.default_notes,
      default_selected_metrics: Array.isArray(s.default_selected_metrics) ? s.default_selected_metrics : [],
      exists: !!s.exists,
    });
  })
);

// ---------------------------------------------------------------------
// PUT /api/admin/ai-prompts/:slug/suggest-settings
// body: { preamble, default_language, default_notes, default_selected_metrics }
// also accepts: default_metrics (FE transition key)
// - actor JWT (admin OR teacher_admin)  [recommended for your current QA]
// ---------------------------------------------------------------------
adminRouter.put(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Fingerprint log so you can confirm this handler is responding
    console.log("[SUGGEST-SETTINGS v3] PUT", req.originalUrl, "schoolId=", ctx.schoolId, "actorType=", ctx.actorType);

    // Required
    const preamble = (req.body?.preamble != null) ? String(req.body.preamble) : null;
    if (preamble == null) return res.status(400).json({ ok: false, error: "missing_preamble" });

    // Optional
    const default_language = (req.body?.default_language != null) ? String(req.body.default_language) : "";
    const default_notes = (req.body?.default_notes != null) ? String(req.body.default_notes) : "";

    // Accept either key during transition
    const default_selected_metrics = Array.isArray(req.body?.default_selected_metrics)
      ? req.body.default_selected_metrics
      : (Array.isArray(req.body?.default_metrics) ? req.body.default_metrics : []);

    const saved = await upsertSuggestSettings({
      schoolId: ctx.schoolId,
      preamble,
      default_language,
      default_notes,
      default_selected_metrics,
    });

    return res.json({
      ok: true,
      id: saved.id,
      preamble_prompt_id: saved.id, // keep FE stable
      preamble: saved.preamble,
      default_language: saved.default_language,
      default_notes: saved.default_notes,
      default_selected_metrics: Array.isArray(saved.default_selected_metrics) ? saved.default_selected_metrics : [],
    });
  })
);

// ============================================================
// //line 11500
// ============================================================

// ============================================================
// End BLOCK 24
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 28
// AI REPORTS — delete + list (cache management)
// ============================================================

// ---------------------------------------------------------------------
// List AI reports for a submission (optional helper endpoint)
// GET /api/admin/reports/list/:slug/:submission_id
// Returns all cached reports for that submission in this school
// ---------------------------------------------------------------------
adminRouter.get(
  "/reports/list/:slug/:submission_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.params.submission_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Verify submission belongs to school
    const sub = await pool.query(
      `SELECT id
       FROM submissions
       WHERE id = $1 AND school_id = $2 AND deleted_at IS NULL
       LIMIT 1`,
      [submissionId, ctx.schoolId]
    );
    if (!sub.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    // List cached AI reports (joined to prompt name for UI)
    const r = await pool.query(
      `SELECT ar.submission_id,
              ar.prompt_id,
              ap.name AS prompt_name,
              ar.model,
              ar.temperature,
              ar.max_output_tokens,
              ar.created_at,
              ar.updated_at
       FROM ai_reports ar
       JOIN ai_prompts ap ON ap.id = ar.prompt_id
       WHERE ar.submission_id = $1
         AND ap.school_id = $2
       ORDER BY COALESCE(ar.updated_at, ar.created_at) DESC, ar.prompt_id DESC`,
      [submissionId, ctx.schoolId]
    );

    return res.json({ ok: true, reports: r.rows });
  })
);

// ---------------------------------------------------------------------
// Delete a cached AI report (hard delete)
// DELETE /api/admin/reports/:slug/:submission_id/:prompt_id
//
// Notes:
// - This is intended to support the "Delete this report" button.
// - We hard-delete the cached report row so the next generate call re-runs.
// - Scope: prompt must belong to school; submission must belong to school.
// ---------------------------------------------------------------------
adminRouter.delete(
  "/reports/:slug/:submission_id/:prompt_id",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.params.submission_id || 0);
    const promptId = Number(req.params.prompt_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "bad_prompt_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Verify submission belongs to school (and not deleted)
    const sub = await pool.query(
      `SELECT id
       FROM submissions
       WHERE id = $1 AND school_id = $2 AND deleted_at IS NULL
       LIMIT 1`,
      [submissionId, ctx.schoolId]
    );
    if (!sub.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    // Verify prompt belongs to school
    const p = await pool.query(
      `SELECT id
       FROM ai_prompts
       WHERE id = $1 AND school_id = $2
       LIMIT 1`,
      [promptId, ctx.schoolId]
    );
    if (!p.rowCount) return res.status(404).json({ ok: false, error: "prompt_not_found" });

    // Delete cached report row (if exists)
    const del = await pool.query(
      `DELETE FROM ai_reports
       WHERE submission_id = $1 AND prompt_id = $2
       RETURNING submission_id, prompt_id`,
      [submissionId, promptId]
    );

    if (!del.rowCount) {
      // Idempotent delete: not an error; report already not cached.
      return res.json({ ok: true, deleted: false, reason: "not_found" });
    }

    return res.json({ ok: true, deleted: true, submission_id: submissionId, prompt_id: promptId });
  })
);

// ============================================================
// //line 13000
// ============================================================

// ============================================================
// End BLOCK 28
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 29
// AI REPORTS — existing + generate (cache + OpenAI + UPSERT)
// Supports admin + teacher_admin (actor JWT)
// ============================================================

// ---------------------------------------------------------------------
// AI Reports - existing (cache check)
// GET /api/admin/reports/existing/:slug?submission_id=123&ai_prompt_id=456
//
// Scope rules:
// - slug -> schoolId via requireSchoolCtxFromActor()
// - submission must belong to school + not deleted
// - prompt must belong to school
// ---------------------------------------------------------------------
adminRouter.get(
  "/reports/existing/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.query.submission_id || 0);
    const promptId = Number(req.query.ai_prompt_id || 0);

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "missing_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "missing_ai_prompt_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Verify submission belongs to school
    const sc = await pool.query(
      `SELECT id, school_id
       FROM submissions
       WHERE id = $1 AND school_id = $2 AND deleted_at IS NULL
       LIMIT 1`,
      [submissionId, ctx.schoolId]
    );
    if (!sc.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    // Verify prompt belongs to school (and get current active flag)
    const pc = await pool.query(
      `SELECT id, is_active
       FROM ai_prompts
       WHERE id = $1 AND school_id = $2
       LIMIT 1`,
      [promptId, ctx.schoolId]
    );
    if (!pc.rowCount) return res.status(404).json({ ok: false, error: "prompt_not_found" });

    const r = await pool.query(
      `SELECT report_text, created_at, updated_at, model, temperature, max_output_tokens
       FROM ai_reports
       WHERE submission_id = $1 AND prompt_id = $2
       LIMIT 1`,
      [submissionId, promptId]
    );

    if (!r.rowCount) return res.json({ ok: true, exists: false });

    return res.json({
      ok: true,
      exists: true,
      report_text: r.rows[0].report_text,
      meta: {
        created_at: r.rows[0].created_at,
        updated_at: r.rows[0].updated_at,
        model: r.rows[0].model,
        temperature: r.rows[0].temperature,
        max_output_tokens: r.rows[0].max_output_tokens,
      },
      source: "cache",
      prompt_is_active: pc.rows[0].is_active === true,
    });
  })
);

// ---------------------------------------------------------------------
// AI Reports - generate (cache + OpenAI + store)
// POST /api/admin/reports/generate/:slug
// body: { submission_id, ai_prompt_id, force?: true }
//
// Notes:
// - if force=true -> bypass cache and re-generate (UPSERT overwrites)
// - prompt must belong to school AND be active=true (policy)
// - submission must belong to school AND not deleted
// ---------------------------------------------------------------------
adminRouter.post(
  "/reports/generate/:slug",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    const submissionId = Number(req.body?.submission_id || 0);
    const promptId = Number(req.body?.ai_prompt_id || 0);
    const force = req.body?.force === true;

    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });
    if (!submissionId) return res.status(400).json({ ok: false, error: "bad_submission_id" });
    if (!promptId) return res.status(400).json({ ok: false, error: "bad_ai_prompt_id" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Prompt must belong to school + be active
    const p = await pool.query(
      `SELECT id, prompt_text, notes, language, is_active
       FROM ai_prompts
       WHERE id = $1 AND school_id = $2
       LIMIT 1`,
      [promptId, ctx.schoolId]
    );
    if (!p.rowCount) return res.status(404).json({ ok: false, error: "prompt_not_found" });
    if (p.rows[0].is_active !== true) return res.status(409).json({ ok: false, error: "prompt_inactive" });

    const promptText = String(p.rows[0].prompt_text || "").trim();
    const notes = String(p.rows[0].notes || "").trim();
    const languageRaw = (p.rows[0].language == null) ? "" : String(p.rows[0].language || "").trim();
    const language = languageRaw || null;

    if (!promptText) return res.status(400).json({ ok: false, error: "empty_prompt_text" });

    // Submission must belong to school, not deleted
    const sub = await pool.query(
      `SELECT id, school_id, question, transcript, transcript_clean,
              student_name, student_email, student_id,
              wpm, mss_fluency, mss_grammar, mss_pron, mss_vocab,
              mss_cefr, mss_toefl, mss_ielts, mss_pte,
              vox_score
       FROM submissions
       WHERE id = $1 AND school_id = $2 AND deleted_at IS NULL
       LIMIT 1`,
      [submissionId, ctx.schoolId]
    );
    if (!sub.rowCount) return res.status(404).json({ ok: false, error: "submission_not_found" });

    const row = sub.rows[0];

    // Variables available to template
    const vars = {
      question: row.question || "",
      transcript: row.transcript_clean || row.transcript || "",
      student: row.student_name || row.student_email || row.student_id || "",

      wpm: row.wpm ?? "",

      mss_fluency: row.mss_fluency ?? "",
      mss_grammar: row.mss_grammar ?? "",
      mss_pron: row.mss_pron ?? "",
      mss_vocab: row.mss_vocab ?? "",
      mss_cefr: row.mss_cefr ?? "",
      mss_toefl: row.mss_toefl ?? "",
      mss_ielts: row.mss_ielts ?? "",
      mss_pte: row.mss_pte ?? "",

      vox_score: row.vox_score ?? "",
    };

    // Render template with vars
    const renderedPromptText = String(renderPromptTemplate(promptText, vars) || "").trim();
    if (!renderedPromptText) {
      return res.status(400).json({ ok: false, error: "rendered_prompt_empty" });
    }

    // Append notes + language
    const parts = [renderedPromptText];
    if (notes) parts.push(`\n\n---\nNotes / Guidance:\n${notes}\n`);
    if (language) parts.push(`\n\n---\nOutput language:\n${language}\n`);
    const finalPrompt = parts.join("");

    const promptHash = sha256(finalPrompt);

    // Cache check (unless forced)
    if (!force) {
      const existing = await pool.query(
        `SELECT report_text, created_at, updated_at, model, temperature, max_output_tokens
         FROM ai_reports
         WHERE submission_id = $1 AND prompt_id = $2
         LIMIT 1`,
        [submissionId, promptId]
      );

      if (existing.rowCount) {
        return res.json({
          ok: true,
          report_text: existing.rows[0].report_text,
          source: "cache",
          prompt_language: language,
          forced: false,
          meta: {
            created_at: existing.rows[0].created_at,
            updated_at: existing.rows[0].updated_at,
            model: existing.rows[0].model,
            temperature: existing.rows[0].temperature,
            max_output_tokens: existing.rows[0].max_output_tokens,
          },
        });
      }
    }

    // Generate via OpenAI
    const ai = await openAiGenerateReport({
      promptText: finalPrompt,
      language,
      model: "gpt-4o-mini",
      temperature: 0.4,
      max_output_tokens: 900,
    });

    const reportText = String(ai?.text || "").trim();

    await pool.query(
      `INSERT INTO ai_reports (submission_id, prompt_id, prompt_hash, model, temperature, max_output_tokens, report_text)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (submission_id, prompt_id)
       DO UPDATE SET
         report_text = EXCLUDED.report_text,
         prompt_hash = EXCLUDED.prompt_hash,
         model = EXCLUDED.model,
         temperature = EXCLUDED.temperature,
         max_output_tokens = EXCLUDED.max_output_tokens,
         updated_at = NOW()`,
      [submissionId, promptId, promptHash, ai.model, ai.temperature, ai.max_output_tokens, reportText]
    );

    return res.json({
      ok: true,
      report_text: reportText,
      source: "openai",
      prompt_language: language,
      forced: !!force,
      meta: {
        model: ai.model,
        temperature: ai.temperature,
        max_output_tokens: ai.max_output_tokens,
      },
    });
  })
);

// ============================================================
// //line 13500
// ============================================================

// ============================================================
// End BLOCK 29
// ============================================================
// ============================================================
// SERVER REGEN — BLOCK 30
// AI PROMPT SUGGEST (generate) + SUGGEST-SETTINGS (per-school defaults)
// Supports admin + teacher_admin (actor JWT)
// ============================================================
//
// Why this block matters:
// - Your trapped diag shows 401 on:
//   POST /api/admin/ai-prompts/:slug/suggest
//   because the route is still using requireAdminAuth (admin-only).
// - Fix: move these endpoints under adminRouter and gate with
//   requireAdminOrTeacherAdmin + requireSchoolCtxFromActor(ctx).
//
// Policy:
// - teacher_admin is allowed for suggest + suggest-settings.
// - Slug/school scope must match token unless superadmin.
//
// Assumptions:
// - You already have helpers in scope:
//   requireActorAuth, requireAdminOrTeacherAdmin, requireSchoolCtxFromActor
//   getOrCreateSuggestSettings, upsertSuggestSettings
//   buildSuggestedPromptTemplate, openAiGenerateReport
// ============================================================

// ---------------------------------------------------------------------
// POST /api/admin/ai-prompts/:slug/suggest
// - Generates a suggested prompt using the per-school preamble + defaults.
// - Accepts overrides (language/notes/selected_metrics etc).
// Body (accepted keys):
//   - language OR default_language
//   - notes OR default_notes
//   - selected_metrics OR selectedMetrics OR metrics
//   - default_selected_metrics OR default_metrics
// ---------------------------------------------------------------------
adminRouter.post(
  "/ai-prompts/:slug/suggest",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // 1) Load per-school defaults (creates row if missing)
    const ss = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    // 2) Accept request overrides (fallback to stored defaults)
    const language =
      (req.body?.language != null) ? String(req.body.language).trim()
      : (req.body?.default_language != null) ? String(req.body.default_language).trim()
      : String(ss?.default_language || "").trim();

    const notes =
      (req.body?.notes != null) ? String(req.body.notes).trim()
      : (req.body?.default_notes != null) ? String(req.body.default_notes).trim()
      : String(ss?.default_notes || "").trim();

    const selectedMetrics =
      (req.body?.selected_metrics != null) ? req.body.selected_metrics
      : (req.body?.selectedMetrics != null) ? req.body.selectedMetrics
      : (req.body?.metrics != null) ? req.body.metrics
      : (req.body?.default_selected_metrics != null) ? req.body.default_selected_metrics
      : (req.body?.default_metrics != null) ? req.body.default_metrics
      : (ss?.default_selected_metrics != null) ? ss.default_selected_metrics
      : [];

    const selectedMetricsArr = Array.isArray(selectedMetrics) ? selectedMetrics : [];

    const metaPrompt = buildSuggestedPromptTemplate({
      preamble: String(ss?.preamble || "").trim(),
      language: String(language || "").trim(),
      notes: String(notes || "").trim(),
      selectedMetrics: selectedMetricsArr,
    });

    // 3) Generate suggestion via OpenAI
    const ai = await openAiGenerateReport({
      promptText: metaPrompt,
      model: "gpt-4o-mini",
      temperature: 0.3,
      max_output_tokens: 900,
    });

    const out = String(ai?.text || "").trim();

    return res.json({
      ok: true,
      slug: ctx.slug,
      schoolId: ctx.schoolId,
      prompt_text: out,
      suggested_prompt_text: out,
      model: ai?.model || "gpt-4o-mini",
    });
  })
);

// ---------------------------------------------------------------------
// GET /api/admin/ai-prompts/:slug/suggest-settings
// - Returns per-school defaults (creates row if missing)
// ---------------------------------------------------------------------
adminRouter.get(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const s = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    return res.json({
      ok: true,
      id: s.id,
      preamble_prompt_id: s.id, // FE legacy stability
      preamble: s.preamble,
      default_language: s.default_language,
      default_notes: s.default_notes,
      default_selected_metrics: Array.isArray(s.default_selected_metrics) ? s.default_selected_metrics : [],
      exists: !!s.exists,
    });
  })
);

// ---------------------------------------------------------------------
// PUT /api/admin/ai-prompts/:slug/suggest-settings
// Body: { preamble, default_language, default_notes, default_selected_metrics }
// Also accepts: default_metrics (FE transition key)
// ---------------------------------------------------------------------
adminRouter.put(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // fingerprint to confirm which handler is responding
    console.log("[SUGGEST-SETTINGS v3] PUT", req.originalUrl, "schoolId=", ctx.schoolId);

    // Required
    const preamble = (req.body?.preamble != null) ? String(req.body.preamble) : null;
    if (preamble == null) return res.status(400).json({ ok: false, error: "missing_preamble" });

    // Optional
    const default_language = (req.body?.default_language != null) ? String(req.body.default_language) : "";
    const default_notes = (req.body?.default_notes != null) ? String(req.body.default_notes) : "";

    // Accept either key during transition
    const default_selected_metrics = Array.isArray(req.body?.default_selected_metrics)
      ? req.body.default_selected_metrics
      : (Array.isArray(req.body?.default_metrics) ? req.body.default_metrics : []);

    const saved = await upsertSuggestSettings({
      schoolId: ctx.schoolId,
      preamble: String(preamble),
      default_language: String(default_language),
      default_notes: String(default_notes),
      default_selected_metrics: Array.isArray(default_selected_metrics) ? default_selected_metrics : [],
    });

    return res.json({
      ok: true,
      id: saved.id,
      preamble_prompt_id: saved.id, // keep FE stable
      preamble: saved.preamble,
      default_language: saved.default_language,
      default_notes: saved.default_notes,
      default_selected_metrics: Array.isArray(saved.default_selected_metrics) ? saved.default_selected_metrics : [],
    });
  })
);

// ============================================================
// //line 14000
// ============================================================

// ============================================================
// End BLOCK 30
// ============================================================
// ============================================================================
// BLOCK 31 — continue from: adminRouter.put("/ai-prompts/:slug/reorder"...)
// ============================================================================

// NOTE: This block assumes you already have these in scope from prior blocks:
// - adminRouter (express.Router())
// - pool (pg Pool)
// - asyncHandler(fn)
// - requireAdminOrTeacherAdmin (middleware)
// - requireSchoolCtxFromActor(req,res,slug) helper

adminRouter.put(
  "/ai-prompts/:slug/reorder",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const order = Array.isArray(req.body?.order) ? req.body.order : [];

    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      for (const item of order) {
        const id = Number(item?.id || 0);
        const so = item?.sort_order == null ? null : Number(item.sort_order);
        if (!id) continue;

        await client.query(
          `UPDATE ai_prompts
              SET sort_order = $1,
                  updated_at = NOW()
            WHERE id = $2
              AND school_id = $3`,
          [so, id, ctx.schoolId]
        );
      }

      await client.query("COMMIT");
      return res.json({ ok: true });
    } catch (e) {
      try {
        await client.query("ROLLBACK");
      } catch (_) {}
      console.error("PUT /admin/ai-prompts/:slug/reorder failed:", e);
      return res.status(500).json({ ok: false, error: "reorder_failed" });
    } finally {
      client.release();
    }
  })
);

// ---------------------------------------------------------------------
// AI Prompt Suggest Settings (per-school)
// Stored in ai_prompt_preamble (or equivalent helper-backed table)
// ---------------------------------------------------------------------
//
// GET  /admin/ai-prompts/:slug/suggest-settings
// PUT  /admin/ai-prompts/:slug/suggest-settings
//
// Notes:
// - These must allow admin OR teacher_admin (teacher_admin can manage prompts)
// - Scope is enforced by requireSchoolCtxFromActor()
// - We keep FE compatibility keys: preamble_prompt_id, default_metrics fallback
//

adminRouter.get(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    const s = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    return res.json({
      ok: true,
      id: s.id,
      preamble_prompt_id: s.id, // legacy FE stability
      preamble: s.preamble,
      default_language: s.default_language,
      default_notes: s.default_notes,
      default_selected_metrics: Array.isArray(s.default_selected_metrics) ? s.default_selected_metrics : [],
      exists: !!s.exists,
    });
  })
);

adminRouter.put(
  "/ai-prompts/:slug/suggest-settings",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // Required
    const preamble = req.body?.preamble != null ? String(req.body.preamble) : null;
    if (preamble == null) return res.status(400).json({ ok: false, error: "missing_preamble" });

    // Optional
    const default_language = req.body?.default_language != null ? String(req.body.default_language) : "";
    const default_notes = req.body?.default_notes != null ? String(req.body.default_notes) : "";

    // Accept either key during transition (FE may send default_metrics)
    const default_selected_metrics = Array.isArray(req.body?.default_selected_metrics)
      ? req.body.default_selected_metrics
      : (Array.isArray(req.body?.default_metrics) ? req.body.default_metrics : []);

    const saved = await upsertSuggestSettings({
      schoolId: ctx.schoolId,
      preamble,
      default_language,
      default_notes,
      default_selected_metrics,
    });

    return res.json({
      ok: true,
      id: saved.id,
      preamble_prompt_id: saved.id, // legacy FE stability
      preamble: saved.preamble,
      default_language: saved.default_language,
      default_notes: saved.default_notes,
      default_selected_metrics: Array.isArray(saved.default_selected_metrics) ? saved.default_selected_metrics : [],
    });
  })
);

// ---------------------------------------------------------------------
// POST /admin/ai-prompts/:slug/suggest
// Generates a “meta prompt” using suggest settings + request overrides,
// then calls OpenAI and returns suggested_prompt_text.
//
// IMPORTANT: must allow teacher_admin (your current failing endpoint).
// ---------------------------------------------------------------------
adminRouter.post(
  "/ai-prompts/:slug/suggest",
  requireAdminOrTeacherAdmin,
  asyncHandler(async (req, res) => {
    const slug = String(req.params.slug || "").trim();
    if (!slug) return res.status(400).json({ ok: false, error: "missing_slug" });

    const ctx = await requireSchoolCtxFromActor(req, res, slug);
    if (!ctx) return;

    // 1) Load per-school defaults
    const ss = await getOrCreateSuggestSettings({ schoolId: ctx.schoolId });

    // 2) Accept request overrides (fallback to defaults)
    const language =
      req.body?.language != null ? String(req.body.language).trim() :
      req.body?.default_language != null ? String(req.body.default_language).trim() :
      String(ss.default_language || "").trim();

    const notes =
      req.body?.notes != null ? String(req.body.notes).trim() :
      req.body?.default_notes != null ? String(req.body.default_notes).trim() :
      String(ss.default_notes || "").trim();

    const selectedMetrics =
      req.body?.selected_metrics ??
      req.body?.selectedMetrics ??
      req.body?.metrics ??
      req.body?.default_selected_metrics ??
      req.body?.default_metrics ??
      ss.default_selected_metrics ??
      [];

    const metaPrompt = buildSuggestedPromptTemplate({
      preamble: ss.preamble,
      language,
      notes,
      selectedMetrics,
    });

    const ai = await openAiGenerateReport({
      promptText: metaPrompt,
      model: "gpt-4o-mini",
      temperature: 0.3,
      max_output_tokens: 900,
    });

    return res.json({
      ok: true,
      slug: ctx.slug,
      schoolId: ctx.schoolId,
      prompt_text: ai.text,
      suggested_prompt_text: ai.text,
      model: ai.model,
    });
  })
);

// ============================================================================
// End BLOCK 31
// ============================================================================
// ============================================================================
// FINAL FOOTER: router mounting, 404, error handler, server start
// ============================================================================


// ---------------------------
// 404 (after all routes)
// ---------------------------
app.use((req, res) => {
  return res.status(404).json({
    ok: false,
    error: "not_found",
    method: req.method,
    path: req.originalUrl,
  });
});

// ---------------------------
// Central error handler (last)
// ---------------------------
app.use((err, req, res, next) => {
  const status = Number(err?.status || err?.statusCode || 500) || 500;

  console.error("❌ Unhandled error:", {
    status,
    method: req.method,
    path: req.originalUrl,
    message: String(err?.message || err || ""),
    stack: err?.stack,
  });

  return res.status(status).json({
    ok: false,
    error: status === 500 ? "server_error" : String(err?.message || "error"),
  });
});

// ---------------------------
// Start server
// ---------------------------

app.listen(PORT, () => console.log(`✅ Server listening on ${PORT}`));